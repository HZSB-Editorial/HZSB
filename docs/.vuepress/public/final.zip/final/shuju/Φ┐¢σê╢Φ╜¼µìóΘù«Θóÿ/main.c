#include<stdio.h>
#define Stack_Size 50
typedef struct{
    int elem[Stack_Size];
    int top;
}SeqStack;

void InitStack(SeqStack * L){
    L->top = -1;
}

int PushStack(SeqStack * L,int e){
    if(L->top == Stack_Size - 1){
        return 0;
    }
    else{
        L->top++;
        L->elem[L->top] = e;
        return 0;
    }
    return 0;
}

int PopStack(SeqStack * L,int * e){
    if(L->top == -1){
        return 0;
    }
    else{
        *e = L->elem[L->top];
        L->top--;
        return 0;
    }
    return 0;
}

void Metric(SeqStack * L,int oper,int base){
    while(oper != 0){
        PushStack(L,oper%base);
        oper = oper/base;
    }
    while(L->top != -1){
        int temp;
        PopStack(L,&temp);
        if(base <= 10){
            printf("%d",temp);
        }
        else{
            if(temp < 10){
                printf("%d",temp);
            }
            else{
                char a ='A'+(temp - 10);
                printf("%c",a);
            }
        }
    }
}
 int main(){
     SeqStack L;
     InitStack(&L);
     int oper,base;
     scanf("%d %d",&oper,&base);
     Metric(&L,oper,base);
     return 0;
 }

