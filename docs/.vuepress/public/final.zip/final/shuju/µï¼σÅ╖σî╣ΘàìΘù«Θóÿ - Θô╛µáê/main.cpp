#include<bits/stdc++.h>
using namespace std;
typedef struct node{
	char data;
	struct node *next;
}LinkStackNode;
typedef LinkStackNode *LinkStack;
void InitStack(LinkStack &S)
{
	S=(LinkStack)malloc(sizeof(LinkStackNode));
	S->next=NULL;
}
void push(LinkStack &S,char x)
{
	LinkStack temp;
	temp=(LinkStack)malloc(sizeof(LinkStackNode));
	temp->data=x;
	temp->next=S->next;
	S->next=temp;
}
char pop(LinkStack &S)
{
	char x;
	LinkStack temp;
	temp=S->next;
	if(temp==NULL)
		return false;
	S->next=temp->next;
	x=temp->data;
	free(temp);
	return x;
}
int main()
{
	int i=1;
	char c,str[100];
	LinkStack S;
	InitStack(S);
	while((c=getchar())!='#')
	{
		str[i]=c;
		i++;
	}
	for(int j=1;j<i;j++)
	{
		if(str[j]=='['||str[j]=='{'||str[j]=='(')
			push(S,str[j]);
		else
		{
			if(S->next==NULL)
			{
				printf("0");
				return 0;
			}
			c=pop(S);
			if(str[j]==']'&&c!='[')
			{
				printf("0");
				return 0;
			}
			if(str[j]=='}'&&c!='{')
			{
				printf("0");
				return 0;
			}
			if(str[j]==')'&&c!='(')
			{
				printf("0");
				return 0;
			}
		}
	}
	if(S->next==NULL)
		printf("1");
	else
		printf("0");
	return 0;
}

