#include <stdio.h>
#include <stdlib.h>
typedef struct tree{
int data;
struct tree *lchild;
struct tree *rchild;
}T;
typedef struct str{
int d[100];
int len;
}S;
void creat_t(S *d1,S *d2,T **y,int root,int left,int right)
{
    if(left<=right)
    {
        int i;
        (*y)=(T*)malloc(sizeof(T));
        (*y)->data=d1->d[root];
        (*y)->lchild=NULL;
        (*y)->rchild=NULL;
        for(i=left;i<=right;i++)
        {
            if(d2->d[i]==d1->d[root])
                break;
        }
        creat_t(d1,d2,&((*y)->lchild),root+1,left,i-1);
        creat_t(d1,d2,&((*y)->rchild),root+i-left+1,i+1,right);
    }
}
int tag[100];
int v=0;
void tag_p(int x)
{
    tag[v]=x;
    v+=1;
}
void judge(T*y)
{
    if(y!=NULL)
    {
        judge(y->lchild);
        T*p=y->rchild;
        T*q=y->lchild;
        if(p!=NULL)
        {
            while(p->lchild!=NULL)
            {
                p=p->lchild;
            }
        }
        if(q!=NULL)
        {
            while(q->rchild!=NULL)
            {
                q=q->rchild;
            }
        }
        if(p==NULL&&q==NULL)
            return;
        else if(p==NULL&&q!=NULL)
        {
            if(q->data>y->data)
            {
                tag_p(0);
                return;
            }
        }
        else if(p!=NULL&&q==NULL)
        {
            if(p->data<y->data)
            {
                tag_p(0);
                return;
            }
        }
        else
        {
            if(p->data<y->data||q->data>y->data)
            {
                tag_p(0);
                return;
            }
        }
        judge(y->rchild);
    }
}
int main(void)
{
    int r,t=0;
    S d1,d2;
    T *p;
    while(1)
    {
        scanf("%d",&r);
        if(r!=0)
        {
            d1.d[t]=r;
            t+=1;
        }
        else
            break;
    }
    d1.len=t;
    t=0;
    while(1)
    {
        scanf("%d",&r);
        if(r!=0)
        {
            d2.d[t]=r;
            t+=1;
        }
        else
            break;
    }
    d2.len=t;
    creat_t(&d1,&d2,&p,0,0,t-1);
    for(t=0;t<10;t++)
        tag[t]=1;
    judge(p);
    for(t=0;t<v;t++)
    {
        if(tag[t]==0)
        {
            printf("false");
            return 0;
        }
    }
    printf("true");
    return 0;
}


