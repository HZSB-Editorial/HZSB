#include <stdio.h>
#include <stdlib.h>
#define Max 100
typedef int ElemType;
typedef struct{
      ElemType data[Max];
    int length;
}SqList;

void display(SqList *L){
    int i;
    for(i=0;i<L->length;i++)
    printf("%d ",L->data[i]);
    printf("\n");
}
void a(SqList *A){
    int left=0,right=A->length;
    int a,b,c;
    while(left<right)
    {a=A->data[left];
     b=A->data[right];
     if(a%2==1) left++;
     else if(b%2==0)right--;
        else{
        c=A->data[left];
     A->data[left]=A->data[right];
        A->data[right]=c;
        left++;right--;
     }
    }

}
int main()
{
    int i;

    SqList *A = (SqList*)malloc(sizeof(SqList));
    A->length=0;
     for(i=0;;i++)
    {
        scanf("%d",&A->data[i]);
        if(A->data[i]==0)
            break;
    }
 A->length=i;
   a(A);
    display(A);
    return 0;
}

