
#define MAX 100
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<malloc.h>
#include<stdbool.h>
typedef struct BiTNode
{
	int data;
	struct BiTNode* lchild;
	struct BiTNode* rchild;
}BiTNode,*BiTree;
BiTNode* Init()
{
	BiTNode* T;
	T = (BiTNode*)malloc(sizeof(BiTNode));
	T->lchild = NULL;
	T->rchild = NULL;
	return T;
}
BiTNode* Creat(char pre[],char in[],int pl,int pr,int inleft,int inright)
{
	BiTNode* T;
	T=Init();
	int i, k;
	if (pl > pr || inleft > inright)//��������
		return NULL;
	for (k = 0;;k++)
	{
		if (pre[pl] == in[k])
		{
			break;
		}
	}
	T->data = in[k];
	//�������������� k-inleft=��������������=x-pl��xΪ���������ֽ�����һ �����x
	T->lchild = Creat(pre, in, pl + 1, pl + k - inleft, inleft, k - 1);
	T->rchild = Creat(pre, in, pl + k - inleft + 1,pr,k + 1, inright);
	return T;
}
int isregular(BiTree T)
{
	BiTNode* ptr = T;
	int flag = 1;
	int left, right;
	if (ptr ==NULL)return 1;
		if ((ptr->lchild == NULL && ptr->rchild != NULL) || (ptr->lchild != NULL && ptr->rchild == NULL))
		{
			flag=0;
			return flag;
		}
		left=isregular(T->lchild);
		right=isregular(T->rchild);
		return left&&right;
}
int main()
{
	BiTree T;
	T=Init();
	int i = 0;
	char pre[MAX];
	char in[MAX];
	scanf("%s", pre);
	scanf("%s", in);
	//�������г���
	while (pre[i])i++;
	T = Creat(pre, in, 0, i - 1, 0, i - 1);
	if (isregular(T)==1)
	{
		printf("Yes");
	}
	else
	{
		printf("No");
	}
}

