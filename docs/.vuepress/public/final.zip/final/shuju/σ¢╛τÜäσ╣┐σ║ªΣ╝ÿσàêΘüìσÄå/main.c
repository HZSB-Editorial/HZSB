#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h> // ���� bool ����
#define MAX_SIZE 100 // ��󶥵�����
typedef struct node {
    int data;
    struct node *next;
} Node;
typedef struct graph {
    int n; // ��������
    int vertex[MAX_SIZE]; // ��������
    Node *adjList[MAX_SIZE]; // �ڽӱ�����
} Graph;
typedef struct queue {
    int data[MAX_SIZE];
    int head;
    int tail;
} Queue;
void initGraph(Graph *g);
void createGraph(Graph *g);
void addEdge(Graph *g, int src, int dest);
void bfs(Graph *g, int start);
void initQueue(Queue *q);
void enqueue(Queue *q, int data);
int dequeue(Queue *q);
bool isQueueEmpty(Queue *q);
int main()
{
    Graph g;
    initGraph(&g);
    createGraph(&g);
    bfs(&g, 0);
    return 0;
}
// ��ʼ��ͼ
void initGraph(Graph *g)
{
    int i;
    g->n = 0;
    for (i = 0; i < MAX_SIZE; i++) {
        g->vertex[i] = 0;
        g->adjList[i] = NULL;
    }
}
// ����ͼ
void createGraph(Graph *g)
{
    int i, j;
    scanf("%d", &g->n);
    for (i = 0; i < g->n; i++) {
        scanf("%d", &g->vertex[i]);
    }
    for (i = 0; i < g->n; i++) {
        for (j = 0; j < g->n; j++) {
            int weight;
            scanf("%d", &weight);
            if (weight == 1) {
                addEdge(g, i, j);
            }
        }
    }
}
// ���ӱ�
void addEdge(Graph *g, int src, int dest)
{
    // �½��ڵ�
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = dest;
    newNode->next = NULL;
    // ���ڵ�����ڽӱ���ͷ�ڵ�
    newNode->next = g->adjList[src];
    g->adjList[src] = newNode;
}
// ������������㷨
void bfs(Graph *g, int start)
{
    int visited[MAX_SIZE];
    int i;
    Queue q;
    initQueue(&q);
    // ��ʼ�����ж���ķ���״̬Ϊfalse
    for (i = 0; i < MAX_SIZE; i++) {
        visited[i] = false;
    }
    visited[start] = true;
    enqueue(&q, start);
    while (!isQueueEmpty(&q)) {
        int cur = dequeue(&q);
        printf("%d ", g->vertex[cur]);
        Node *tmp = g->adjList[cur];
        while (tmp) {
            if (!visited[tmp->data]) {
                visited[tmp->data] = true;
                enqueue(&q, tmp->data);
            }
            tmp = tmp->next;
        }
    }
}
// ��ʼ������
void initQueue(Queue *q)
{
    q->head = 0;
    q->tail = 0;
}
// ���
void enqueue(Queue *q, int data)
{
    q->data[q->tail] = data;
    q->tail++;
}
// ����
int dequeue(Queue *q)
{
    int data = q->data[q->head];
    q->head++;
    return data;
}
// �ж϶����Ƿ�Ϊ��
bool isQueueEmpty(Queue *q)
{
    if (q->head == q->tail) {
        return true;
    } else {
        return false;
    }}

