#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXV = 110;
const int INF = 0x3fffffff;

int n, st, G[MAXV][MAXV];
int d[MAXV];
bool vis[MAXV] = {false};

void Dijkstra(int s) {
    fill(d, d + MAXV, INF);
    d[s] = 0;
    for (int i = 0; i < n; i++) {
        int u = -1, min = INF;
        for (int j = 0; j < n; j++) {
            if (vis[j] == false && d[j] < min) { //�ҵ�δ���ʽ����d[]��С��
                u = j;
                min = d[j];
            }
        }
        if (u == -1) return;
        vis[u] = true; //���uΪ�ѷ���
        for (int v = 0; v < n; v++) {
            //���vδ������u�ܵ���v
            if (vis[v] == false && G[u][v] != 0) {
                if (d[u] + G[u][v] < d[v]) {
                    d[v] = d[u] + G[u][v];
                }
            }
        }
    }
}


int main() {
    fill(G[0], G[0] + MAXV * MAXV, 0);
    scanf("%d%d", &n, &st);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &G[i][j]);
        }
    }
    Dijkstra(st);
    for (int i = 0; i < n; i++) {
        if (i != st) {
            if (d[i] != INF) {
                printf("%d ", d[i]);
            } else {
                printf("-1 ");
            }
        }
    }
    printf("\n");
    return 0;
}


