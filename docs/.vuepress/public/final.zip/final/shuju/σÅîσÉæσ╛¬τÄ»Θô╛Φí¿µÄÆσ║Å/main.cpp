#include <iostream>

using namespace std;
typedef struct Node
{
    int data;
    Node*prior,*next;


}Node,*LinkList;
void createlist(Node *head)
{
    Node*a=head;
   int num;
    Node*s;

  while (cin>>num)
  {
      if(num==0)
        break;
      else
      {
          s= new Node;
          s->data=num;
          a->next=s;
          s->prior=a;
          s->next=head;
          head->prior=s;
          a=s;
      }
  }
}
void Sort(Node *head)
{   Node *L=head;
    Node*p,*q,*r;

    p=L->next;q=p->next;r=q->next;
    while(q!=L)
    {
        while((p!=L)&&(p->data>q->data))
                p=p->prior;
        q->prior->next=r;
        r->prior=q->prior;
        q->next=p->next;
        q->prior=p;
        p->next->prior=q;
        p->next=q;
        q=r;
        p=q->prior;
        r=r->next;
    }
}
void print(Node *head)
{ Node*L=head->next;
    while (L!=head)
    {
        cout<<L->data<<" ";
        L=L->next;
    }

}
int main()
{  Node * head=new Node;
   head->next=head;
   head->prior=head;
   createlist(head);
   Sort(head);
   print(head);

    return 0;
}

