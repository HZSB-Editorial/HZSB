
#define MAX 100
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<malloc.h>
#include<stdbool.h>
typedef struct ArcNode
{
	struct ArcNode* nextarc;
	int adjvex;
	int weight;
}ArcNode;
typedef struct
{
	ArcNode* firstarc;
	int data;
}VexNode;
typedef struct
{
	VexNode vertex[MAX];
	int vexnum, arcnum;
}AdjList;
typedef struct
{
	int lowcost;
	int adjvex;
}closedge[MAX];
void Creat_List(AdjList* g)
{
	int n;
	scanf("%d", &n);
	g->vexnum = n;
	int i, j;
	int x;
	ArcNode* ptr, * r;
	//��g��ʼ��
	for (i = 0;i < g->vexnum;i++)
		g->vertex[i].firstarc = NULL;
	for(i=0;i<g->vexnum;i++)
		for (j = 0;j < g->vexnum;j++)
		{
			scanf("%d", &x);
			if (x != 0)
			{
				r = g->vertex[i].firstarc;
				ptr = (ArcNode*)malloc(sizeof(ArcNode));
				ptr->nextarc = NULL;
				ptr->adjvex = j;
				ptr->weight = x;
				//β�巨����
				if (g->vertex[i].firstarc == NULL)
				{
					g->vertex[i].firstarc = ptr;
				}
				else
				{
					while (r->nextarc!=NULL)
					{
						r = r->nextarc;
					}
					r->nextarc = ptr;
				}
			}
		}
}
int  Minum(closedge* closed,int n)
{
	int i;
	int min =999, s1;
	for (i = 0;i < n;i++)
	{
		if (closed[i]->lowcost!= 0 && closed[i]->lowcost < min)
		{
			min = closed[i]->lowcost;
			s1 = i;
		}
	}
	return s1;

}
void prime(AdjList g,int u)
{
	closedge closed1;
	closedge* closed = &closed1;
	closed[u]->lowcost=0;
	int i;

	for (i = 0;i < g.vexnum;i++)
	{
		if (i != u)
		{
			closed[i]->lowcost =9999;
			closed[i]->adjvex = u;
		}
	}
	//closed��ʼ��
      ArcNode *ptr = g.vertex[u].firstarc;

			while (ptr != NULL)
			{
					closed[ptr->adjvex]->lowcost = ptr->weight;
				ptr = ptr->nextarc;
			}
	int e;
	int v;
	int sum = 0;
	for (e = 1;e <= g.vexnum-1;e++)
	{
		v=Minum(closed, g.vexnum);
		u = closed[v]->adjvex;
		sum += closed[v]->lowcost;
		//����closed
		ArcNode* ptr = g.vertex[v].firstarc;
		closed[v]->lowcost = 0;
			while (ptr != NULL)
			{
				if (ptr->weight != 0 && ptr->weight < closed[ptr->adjvex]->lowcost)
				{
					closed[ptr->adjvex]->lowcost = ptr->weight;
					closed[ptr->adjvex]->adjvex = v;
				}
				ptr= ptr->nextarc;
			}
	}
	printf("%d", sum);
}
int main()
{
	AdjList g;
	Creat_List(&g);
	prime(g, 0);
	return 0;
}

