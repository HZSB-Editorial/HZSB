#include <stdio.h>

#define INF 65535

struct huffman{
	int w;
	int parent,lchild,rchild;
}HT[1001];

int n;

void createHT()
{

	int i,j;
	//��ʼ��
	for(i=0;i<2*n-1;i++)
	 HT[i].parent=HT[i].lchild=HT[i].rchild=-1;

	for(i=0;i<n;i++)
	  scanf("%d",&HT[i].w);

	/*ѡ����С������
	  ɾ����С�����ˡ�*/
	int a,b;
	int a1,b1;
    for(i=0;i<n-1;i++)
    {
    	a1=b1=INF;
    	for(j=0;j<n+i;j++)
    	{
    		 if(HT[j].parent==-1&&HT[j].w<a1)
    		{
    			b=a;
    			a=j;
    			b1=a1;
    			a1=HT[j].w;
			}
			else if(HT[j].parent==-1&&HT[j].w<b1)
			{
				b=j;
				b1=HT[j].w;
			}
		}

		HT[n+i].w=HT[a].w+HT[b].w;
		HT[n+i].lchild=a;
		HT[n+i].rchild=b;
		HT[a].parent=HT[b].parent=n+i;
	}
}

int main()
{
	while(scanf("%d",&n)!=EOF)
	{
		int i,sum=0;

		createHT();
		for(i=n;i<2*n-1;i++)
		 sum+=HT[i].w;

		printf("%d\n",sum);
	}
	return 0;
}

