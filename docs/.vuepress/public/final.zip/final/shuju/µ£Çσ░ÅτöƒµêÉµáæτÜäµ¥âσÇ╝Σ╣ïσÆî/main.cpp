#include<iostream>
#define N 50
#define Max 999999
using namespace std;

int R[N][N];
typedef struct
{
    int adjvex;
    int loweight;
    int flag;
}Closedge;

int Min(Closedge * MTree, int limit)
{
    int min = 99999;
    int i = 0;
    int res = 0;
    for(i = 1; i <= limit; i ++)
    {
        if(MTree[i].loweight < min && MTree[i].flag == 1)
        {
            min = MTree[i].loweight;
            res = i;
        }
    }
    return res;
}

void Prim(int limit)
{
    int sum = 0;
    Closedge MTree[limit + 1];
    int i = 0;
    for(i = 1; i <= limit; i ++) //��ʼ��
    {
        if(i != 1)
            MTree[i].adjvex = 1;
        MTree[i].flag = 1;
        MTree[i].loweight = R[1][i];
    }
    for(i = 2; i <= limit; i ++)
    {
        int MinId = Min(MTree, limit);
        cout<<MTree[MinId].adjvex<<'-'<<MinId<<':'<<MTree[MinId].loweight<<endl;
        sum += MTree[MinId].loweight;
        MTree[MinId].flag = 0;
        int j = 0;
        for(j = 2; j <= limit; j ++)
        {
            if(R[MinId][j] < MTree[j].loweight)
            {
                MTree[j].loweight = R[MinId][j];
                MTree[j].adjvex = MinId;
            }
        }
    }
    cout<<sum;
}

int main()
{
    int NodeNum;
    int RelationNum;
    cin>>NodeNum>>RelationNum;
    int i = 0;
    int j = 0;
    for(i = 1; i <= NodeNum; i++)
    {
        for(j = 1; j <= NodeNum; j ++)
        {
            R[i][j] = Max;
        }
    }
    while(RelationNum --)
    {
        int i, j, k;
        cin>>i>>j>>k;
        R[i][j] = k;
        R[j][i] = k;
    }
    Prim(NodeNum);
    return 0;
}


