#include<stdio.h>
#include<malloc.h>
#define STACK 100
#define STACKINCRMENT 10

typedef char ElementType;
typedef struct SqStack{
	ElementType *base;
	ElementType *top;
	int stacksize;
}SqStack;

void InitStack(SqStack *S){
	S->base=(ElementType*)malloc(STACK*sizeof(ElementType));
	if(!S->base) printf("����洢�ռ�ʧ��");
	S->top=S->base;
	S->stacksize=STACK;
	//return true;
}
void Push(SqStack *S,ElementType e){
	if(S->top-S->base>=S->stacksize){
		S->base=(ElementType*)realloc(S->base,(S->stacksize+STACKINCRMENT)*sizeof(ElementType));
		if(!S->base) printf("�ռ䲻��");
		S->top=S->base+S->stacksize;
		S->stacksize+=STACKINCRMENT;
	}
	*S->top++ = e;
}
ElementType Pop(SqStack *S){
	ElementType e;
	if(S->top!=S->base) {
		e= *--S->top;
		return e;
	}
}
int main(){
	SqStack S;
	ElementType e,p;
	int flag=0,length=0;
	InitStack(&S);
	scanf("%c",&e);
	while(e!='&'&&flag==0){
		Push(&S,e);
		length++;
		scanf("%c",&e);;
	}
	if(e=='&') flag=1;
	if(flag==1){
		scanf("%c",&e);
		while(e!='@'&&S.top!=S.base){
			p=Pop(&S);
			if(e!=p) {
				printf("no");
				return 0;
			}
			else scanf("%c",&e);;
		}

	}
	printf("%d",length);
}

