#include<iostream>
#define N 50
#include<stack>
#include<stdlib.h>
using namespace std;

typedef struct node
{
    int NodeId;
    int weight;
    int edgeId;
    struct node * next;
}ArcNode; //�ڽӽ��ṹ��

typedef struct
{
    int in;
    int out;
    int flag;
    int vertex;
    ArcNode * firstedge;
}ALGraph; //�ڽӱ��ṹ��

ALGraph G[N];
int Relation[N][N];
int VE[N];
int VL[N];
int EE[N];
typedef struct
{
    int Weight;
    int node1;
    int node2;
}point;
point EL[N];
int el[N];
int count = -1;

void MaxPathLen(int limit)
{
    int i = 0;
    stack<ALGraph*> S;

    //��������������������������VE
    for(i = 0; i < limit; i ++)
    {
        if(G[i].in == 0)
        {
            S.push(&G[i]);
            G[i].flag = 0;
        }
    }
    while(!S.empty())
    {
        ALGraph * temp = S.top();
        S.pop();
        ArcNode * p = temp->firstedge;
        while(p != NULL) //�����Ľڵ�����ڽڵ����ȼ�һ�����VE
        {
            G[p->NodeId].in --;
            if(VE[temp->vertex] + p->weight > VE[p->NodeId])
            {
                VE[p->NodeId] = VE[temp->vertex] + p->weight;
                //cout<<p->NodeId<<" "<<VE[p->NodeId]<<endl;
            }
            p = p->next;
        }
        for(i = 0; i < limit; i ++)
        {
            if(G[i].in == 0 && G[i].flag == 1)
            {
                S.push(&G[i]);
                G[i].flag = 0;
            }
        }
    }
    for(i = 0; i < limit; i ++)
    {
        G[i].flag = 1; //����ǳ�ʼ��
    }
    int max = -1;
    int maxid = 0;
    for(i = 0; i < limit; i ++)
    {
        if(VE[i] > max)
        {
            max = VE[i];
            maxid = i;
        }
    }
    VL[maxid] = max;

    //�ó������������������������VL
    for(i = 0; i < limit; i ++)
    {
        if(G[i].out == 0)
        {
            S.push(&G[i]);
            G[i].flag = 0;
        }
    }
    while(!S.empty())
    {
        ALGraph * temp = S.top();
        S.pop();
        for(i = 0; i < limit; i ++)
        {
            if(Relation[temp->vertex][i] == 1)
            {
                G[i].out --;
                Relation[temp->vertex][i] = 0;
                ArcNode * pos = G[i].firstedge;
                while(pos->NodeId != temp->vertex) pos = pos->next;
                if(VL[i] == 0)
                {
                    VL[i] = VL[temp->vertex] - pos->weight;
                }
                if(VL[temp->vertex] - pos->weight < VL[i] )
                {
                    VL[i] = VL[temp->vertex] - pos->weight;
                    //cout<<temp->vertex<<" "<<VL[temp->vertex]<<" "<<pos->weight<<endl;
                }
            }
        }
        for(i = 0; i < limit; i ++)
        {
            if(G[i].out == 0 && G[i].flag == 1)
            {
                S.push(&G[i]);
                G[i].flag = 0;
            }
        }
    }

    //����EE[N],EL[N]
    for(i = 0; i <= count; i ++)
    {
        int e = EE[i];
        int l = EL[i].node2;
        EE[i] = VE[e];
        el[i] = VL[l] - EL[i].Weight;
    }
    cout<<max<<endl;
    for(i = 0; i <= count; i ++)
    {
        if(EE[i] == el[i])
            cout<<EL[i].node1<<" "<<EL[i].node2<<endl;
    }
}

int main()
{
    int NodeNum;
    int EdgeNum;
    cin>>NodeNum>>EdgeNum;
    int i, j;
    for(i = 0; i < NodeNum; i ++)
    {
        VE[i] = 0;
        VL[i] = 0;
    }
    for(i = 0; i < EdgeNum; i ++)
    {
        EE[i] = 0;
        el[i] = 0;
        EL[i].Weight = 0;
        EL[i].node1 = 0;
        EL[i].node2 = 0;
    }
    for(i = 0; i < NodeNum; i ++) //���ĳ�ʼ��
    {
        G[i].in = 0;
        G[i].out = 0;
        G[i].flag = 1;
        G[i].vertex = i;
        G[i].firstedge = NULL;
    }
    for(i = 0; i < NodeNum; i ++)
    {
        for(j = 0; j < NodeNum; j ++)
        {
            Relation[i][j] = 0;
        }
    }
    i = EdgeNum;
    while(i --) //�������
    {
        int node1;
        int node2;
        int w;
        cin>>node1>>node2>>w;
        Relation[node2][node1] = 1;
        ArcNode * temp = (ArcNode *)malloc(sizeof(ArcNode));
        temp->NodeId = node2;
        temp->weight = w;
        temp->next = NULL;
        count ++;
        EE[count] = node1;
        EL[count].node1 = node1;
        EL[count].node2 = node2;
        EL[count].Weight = w;
        temp->edgeId = count;
        G[node1].out ++;
        G[node2].in ++;
        ArcNode * pos = G[node1].firstedge;
        if(pos == NULL)
        {
            G[node1].firstedge = temp;
        }
        else
        {
            while(1)
            {
                if(pos->next == NULL) break;
                else
                    pos = pos->next;
            }
            pos->next = temp;
        }
    }
    MaxPathLen(NodeNum);

    return 0;
}


