#include<bits/stdc++.h>

using namespace std;


 void print(int a[],int len)
{
    for( int i = 0 ;i < len ; i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
void adjustheap(int a[] , int i , int len )
{
    int temp = a[ i ];
    for(int k = 2 * i + 1;k < len ;k = 2 * k + 1)
    {
        if( k != len - 1 && a[ k ] < a[k + 1])
        {
            k++;
        }
        if(a[ k ]>temp)
        {
            a[ i ] =a [ k ];
            i = k;
        }
        else break;
    }
    a[ i ] = temp;
}
void heapsort(int a[] , int len)
{   int i ,j;
    if(len < 2)
    {   print(a,len);
        return ;
    }
    for(i = len / 2 - 1 ;i >= 0;i-- )
    {
        adjustheap( a , i ,len );
    }
     print(a,len);
    for( j = len - 1;j > 0;j--)
    {
       int tmp = a[ 0 ];
       a[ 0 ] = a[ j ];
       a[ j ] = tmp;
       adjustheap( a, 0 ,j );
        print(a,len);
    }
}
int main()
{
    int a[100] ,len = 0;

    while(1)
    {
        cin>>a[ len ];
        if(a[ len ] == 0)
        {
            //cout<<len<<endl;
            break;
        }
        len++;
    }
    heapsort(a,len);
   // print(a,len);
}

