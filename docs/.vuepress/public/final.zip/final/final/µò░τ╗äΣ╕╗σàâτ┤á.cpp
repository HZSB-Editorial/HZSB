#include <iostream>
#define Maxsize 1000
using namespace std;

int a[Maxsize],len;

void Input()
{
    int i=0;
    while(1)
    {
        cin>>a[i];
        if(a[i]==0) break;
        i++;
    }
    len=i;
}

void Majority()
{
    int cur=a[0],Count=1;
    for(int i=1;i<len;i++)
    {
        if(a[i]==cur) Count++;
        else
        {
            if(Count!=0) Count--;
            else
            {
                cur=a[i];
                Count=1;
            }
        }
    }
    if(Count!=0)
    {
    	int sum=0;
    	for(int i=0;i<len;i++)
    	if(a[i]==cur)
    	sum++;
    	if(sum>len/2) cout<<cur;
    	else cout<<"-1";
    }
    else
        cout<<"-1";
}
int main()
{
    Input();
    Majority();
    return 0;
}

/*【问题描述】这是一道2013年考研真题，已知一个整数序列A长度为N，其中若存在a，且a的个数大于N/2，则称a为A的主元素

例如：3 5 5 3 5 7 5 5，其主元素为5

又如：3 5 5 3 5 1 5 7，其中没有主元素。

假设元素保存在一个一维数组中，请设计一个尽可能高效的算法，找出主元素。若存在主元素则输出该元素否则输出

要求时间复杂度为O(N)，请注意穷举法时间复杂度是O(N^2)，排序再遍历查找的时间复杂度是O(N*logN+N)

【输入形式】

一个整数数组，以0作为结束输入

【输出形式】

主元素，若没有则输出-1

【样例输入】

3 5 5 3 5 7 5 5 0

【样例输出】

5

【样例说明】长度为8，共有5个‘5’

*/