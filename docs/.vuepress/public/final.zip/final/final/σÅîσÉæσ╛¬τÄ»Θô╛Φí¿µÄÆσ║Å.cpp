#include <iostream>
using namespace std;

typedef struct DNode
{
    int data;
    struct DNode *prior,*next;
}DNode,*DoubleList;
void InitList(DoubleList &L)
{
    L=new DNode;
    (*L).next=L;
    (*L).prior=L;
}
void create(DoubleList L)
{
    DNode *r,*s;
    int c;
    while(1)
    {
        cin>>c;
        if(c==0) break;
            s=new DNode;
            r=L->next;
            s->data=c;
            while(r->next!=L&&s->data>r->data)
            {
                r=r->next;
            }
            if(s->data<r->data)
            {
                s->prior=r->prior;
                r->prior->next=s;
                s->next=r;
                r->prior=s;
            }
            else{
               r->next=s;
               s->prior=r;
               s->next=L;
               L->prior=s;
            }
    }
}
void shuchu(DoubleList L)
{
    DNode *p;
    p=L;
    while(p->next!=L)
    {
        p=p->next;
        cout<<p->data<<" ";
    }
}

int main()
{
    DoubleList L;
    InitList(L);
    create(L);
    shuchu(L);
    return 0;
}

/*【问题描述】实现不带头结点的双向循环链表的创建，然后实现该双向循环链表上数据的排序。（方法自定）
【输入形式】随机的数据
【输出形式】排序后的数据
【样例输入】5 7 2 8 1 3 4 9 6 0
【样例输出】1 2 3 4 5 6 7 8 9

【提示】0代表数据输入的结束*/

