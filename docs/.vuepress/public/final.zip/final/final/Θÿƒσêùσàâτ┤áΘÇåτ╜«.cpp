#include <iostream>
#include <stack>
#include <queue>
using namespace std;

int main() {
    int n;
    cin >> n;
    queue<int> q;
    stack<int> s;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        q.push(x);
    }
    while (!q.empty()) {
        s.push(q.front());
        q.pop();
    }
    while (!s.empty()) {
        q.push(s.top());
        s.pop();
    }
    while (!q.empty()) {
        cout << q.front() << " ";
        q.pop();
    }
    return 0;
}



/*【问题描述】已知Q是一个非空队列，S是一个空栈。仅使用少量工作变量以及对队列和栈的基本操作，编写一个算法，将队列Q中的所有元素逆置。需采用链式队列与栈（顺序或链式），否则不能得分。

【输入形式】输入的第一行为队列元素个数，第二行为队列从首至尾的元素

【输出形式】输出队列的逆置

【样例输入】

3

1 2 3

【样例输出】

3 2 1

*/
