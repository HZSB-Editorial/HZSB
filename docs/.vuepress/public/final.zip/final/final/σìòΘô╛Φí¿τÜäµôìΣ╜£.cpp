#include <iostream>
using namespace std;
struct Node
{
	int data;
	Node* next;
};
void initList(Node* &head)
{
	head = new Node;
	head->next = NULL;
}
void CreateFromHead(Node* head)
{
	
	int data;
	cin >> data;
	while (data != 0)
	{
		Node* p = new Node;
		p->data = data;
		p->next = head->next;
		head->next = p;
		cin >> data;
	}
}
void Print(Node* head)
{
	while (head->next != NULL)
	{
		head = head->next;
		cout << head->data<<" ";
	}
	cout << endl;
}
void DelList(Node* head)
{
	head = head->next;
	Node* p = head->next;
	while (p != NULL)
	{
		if (head->data == p->data)
		{
			head->next = p->next;
			p = p->next;
		}
		else
		{
			head = head->next;
			p = p->next;
		}
	}
}
int main()
{
	Node* head;
	initList(head);
	CreateFromHead(head);
	Print(head);
	DelList(head);
	Print(head);
	return 0;
}
/*【问题描述】请根据输入的逆序数据采用头插法创建一个单链表，然后删除相同的数据，仅保留一个。

【输入形式】逆序的数据，数据0代表输入结束

【输出形式】创建成功的原始单链表的数据，以及删除某些元素后的单链表的数据，其中相同数据仅保留一个

【样例输入】

9 9 8 8 7 6 5 5 4 0

【样例输出】

4 5 5 6 7 8 8 9 9

4 5 6 7 8 9
 */