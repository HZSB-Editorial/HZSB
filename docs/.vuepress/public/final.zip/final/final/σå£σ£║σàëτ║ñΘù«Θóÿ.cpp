#include <iostream>
using namespace std;
struct graph
{
	int vernum;
	int data[30][30];
};

void Prim(graph g, int shortest[], int path[])
{
	
	for (int j = 2; j <= g.vernum; j++)
	{
		int min = 9999;
		int k = 2;
		for (int i = 2; i <= g.vernum; i++)
		{
			if (shortest[i] < min && path[i] == 0)
			{
				min = shortest[i];
				k = i;
			}
		}
		path[k] = min;
		for (int m = 2; m <= g.vernum; m++)
		{
			if (g.data[k][m] < shortest[m] && path[m] == 0)
			{
				shortest[m] = g.data[k][m];
			}
		}

	}
}
int main()
{
	int path[100] = { 0 };
	int shortest[100];
	graph g;
	cin >> g.vernum;
	for (int i = 1; i <= g.vernum; i++)
	{
		for (int j = 1; j <= g.vernum; j++)
		{
			cin >> g.data[i][j];
			if (g.data[i][j] == 0)
			{
				g.data[i][j] = 9999;
			}
		}
	}
	for (int i = 2; i <= g.vernum; i++)
	{
		shortest[i] = g.data[1][i];
	}
	Prim(g, shortest, path);
	int sum = 0;
	for (int i = 2; i <= g.vernum; i++)
	{
		sum = sum + path[i];
	}
	cout << sum;
	return 0;
}

/*【问题描述】农夫约翰被选为镇长了！他的竞选承诺之一是将互联网连接到该镇的所有农场。农场主约翰为他的农场订购了高速连接设备，并将与其他农场主共享他的连接。为了将成本降到最低，他想铺设最少数量的光纤，将他的农场连接到所有其他农场。下面给出了连接每对农场需要多少光纤的列表，你必须找到将它们连接在一起所需的最小光纤量。每个农场必须连接到其他某个农场，以便数据包可以从任何一个农场传输到其他农场。
【输入说明】第一行是农场的数量n，后面的n*n行，表示从一个农场到另一个农场的距离，对角线为0表示农场自身到自身，该值没有意义。例如第二行的数字4 9 21，分别表示第1个农场到第2个农场的距离是4，第1个农场到第3个农场的距离是9，第1个农场到第4个农场的距离是21
【输出说明】输出一个整数，表示连接整个农场所需要的最小光纤长度之和
【样例输入1】
4
0 4 9 21
4 0 8 17
9 8 0 16
21 17 16 0
【样例输出1】
28
【样例输入2】
6
0 6 1 5 0 0
6 0 5 0 3 0
1 5 0 5 6 4
5 0 5 0 0 2
0 3 6 0 0 6
0 0 4 2 6 0
【样例输出2】
15
【样例输入3】
3
0 3 3
3 0 2
3 2 0
【样例输出3】
5
 */