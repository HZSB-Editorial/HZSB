#include<iostream>
#define N 50
#define MAX 9999
using namespace std;

int nodenum;
int num;
int r[N][N];
int lowpath[N];
int before[N];
bool tag[N];

void dijikstra()
{
    int i;
    for(i=0;i<nodenum;i++)
    {
        lowpath[i]=r[num][i];
        if(i==num)
        {
            before[i]=-1;
            tag[i]=false;
        }
        else{
            before[i]=num;
            tag[i]=true;
        }
    }
    int cnt=nodenum-1;
    while(cnt--)
    {
        int minw=MAX;
        int id=0;
        for(i=0;i<nodenum;i++)
        {
            if(lowpath[i]<minw &&tag[i]==true)
            {
                minw=lowpath[i];
                id=i;
            }
        }
        tag[id]=false;
        for(i=0;i<nodenum;i++)
        {
            if(i==id || i==num)continue;
            else if(r[id][i]+lowpath[id]<lowpath[i])
            {
                lowpath[i]=r[id][i]+lowpath[id];
                before[i]=id;
            }
        }
    }
    for(i=0;i<nodenum;i++)
    {
        if(i==num)continue;
        else if(lowpath[i]==MAX) cout<<-1<<" ";
        else cout<<lowpath[i]<<" ";
    }
}

int main()
{
    cin>>nodenum>>num;
    int i,j;
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            int n;
            cin>>n;
            if(n==0)
                r[i][j]=MAX;
            else
                r[i][j]=n;
        }
    }
    dijikstra();
    return 0;
}

/*【输入形式】

输入的第一行包含2个正整数n和s，表示图中共有n个顶点，且源点为s。其中n不超过50，s小于n。

以后的n行中每行有n个用空格隔开的整数。对于第i行的第j个整数，如果大于0，则表示第i个顶点有指向第j个顶点的有向边，且权值为对应的整数值；如果这个整数为0，则表示没有i指向j的有向边。当i和j相等的时候，保证对应的整数为0。

【输出形式】

只有一行，共有n-1个整数，表示源点至其它每一个顶点的最短路径长度。如果不存在从源点至相应顶点的路径，输出-1。

请注意行尾输出换行。

【样例输入】

4 1  //这里的1表示第2个顶点，0-1-2-3共计4个顶点，下图为有向图的邻接矩阵。
0 3 0 1
0 0 4 0
2 0 0 0
0 0 1 0

【样例输出】

6 4 7 */
