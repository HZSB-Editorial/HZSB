#include <iostream>
#include <cstring>
using namespace std;

const int MAXSIZE = 100;

class Stack {
public:
    Stack() { top = -1; }
    bool isEmpty() const { return top == -1; }
    bool isFull() const { return top == MAXSIZE-1; }
    void push(char ch) { 
        if (isFull()) return;
        top++;
        s[top] = ch;
    }
    char pop() { 
        if (isEmpty()) return '\0';
        char ch = s[top];
        top--;
        return ch;
    }
private:
    char s[MAXSIZE];
    int top;
};
string convert_base(int decimal, int base) {
    const char* digits = "0123456789ABCDEF";
    Stack rem_stack;
    while (decimal > 0) {
        int rem = decimal % base;
        rem_stack.push(digits[rem]);
        decimal = decimal / base;
    }
    string new_digits = "";
    while (!rem_stack.isEmpty()) {
        new_digits += rem_stack.pop();
    }
    return new_digits;
}

int main() {
    int decimal, base;
    cin >> decimal >> base;
    string result = convert_base(decimal, base);
    cout << result << endl;
    return 0;
}

/*【问题描述】根据课堂讲授，请用“顺序栈”解决进制转换问题，不采用顺序栈，不给分。
【输入形式】十进制数据和待转换的进制
【输出形式】转换后的数据
【样例输入1】1348 8
【样例输出1】2504
【样例输入2】2608 16
【样例输出2】A30
 */
