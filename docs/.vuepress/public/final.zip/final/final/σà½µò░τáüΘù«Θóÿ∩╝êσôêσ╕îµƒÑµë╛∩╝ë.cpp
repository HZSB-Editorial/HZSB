#include <iostream>
#include <queue>
#include <cstring>
using namespace std;

// 定义棋盘状态结构体
struct State {
    int board[3][3]; // 棋盘上的数字
    int step; // 移动步数
};

// 定义目标状态
int goal[3][3];

// 定义哈希表大小
const int HASH_SIZE = 100007;

// 定义哈希表结点结构体
struct Node {
    State state; // 棋盘状态
    Node* next; // 链表指针
};

// 定义哈希表数组
Node* hashTable[HASH_SIZE];

// 判断两个状态是否相等
bool isEqual(State& a, State& b) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (a.board[i][j] != b.board[i][j]) {
                return false;
            }
        }
    }
    return true;
}

// 计算一个状态的哈希值
int hashValue(State& s) {
    int value = 0;
    int base = 1;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            value += s.board[i][j] * base;
            base *= 10;
        }
    }
    return value % HASH_SIZE;
}

// 判断一个状态是否在哈希表中
bool isInHash(State& s) {
    int h = hashValue(s); // 计算哈希值
    Node* p = hashTable[h]; // 获取链表头指针
    while (p) { // 遍历链表
        if (isEqual(p->state, s)) { // 如果找到相等的状态，返回true
            return true;
        }
        p = p->next; // 移动指针
    }
    return false; // 没有找到相等的状态，返回false
}

// 将一个状态插入到哈希表中
void insertHash(State& s) {
    int h = hashValue(s); // 计算哈希值
    Node* p = new Node; // 创建新结点
    p->state = s; // 复制状态
    p->next = hashTable[h]; // 插入到链表头部
    hashTable[h] = p; // 更新链表头指针
}

// 找到空格的位置，返回行号和列号
void findZero(State& s, int& x, int& y) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (s.board[i][j] == 0) {
                x = i;
                y = j;
                return;
            }
        }
    }
}

// 交换两个位置的数字
void swap(int& a, int& b) {
    int temp = a;
    a = b;
    b = temp;
}

// 扩展当前状态的下一步可能状态，并将它们加入到队列中
void expand(State& cur, queue<State>& q) {
    int x, y; // 空格的位置
    findZero(cur, x, y); // 找到空格的位置
    // 定义四个方向的偏移量
    int dx[4] = {-1, 1, 0, 0};
    int dy[4] = {0, 0, -1, 1};
    for (int i = 0; i < 4; i++) { // 遍历四个方向
        int nx = x + dx[i]; // 计算新的行号
        int ny = y + dy[i]; // 计算新的列号
        if (nx >= 0 && nx < 3 && ny >= 0 && ny < 3) { // 如果新的位置在棋盘内
            State next = cur; // 复制当前状态
            swap(next.board[x][y], next.board[nx][ny]); // 交换空格和相邻的数字
            next.step++; // 增加移动步数
            if (!isInHash(next)) { // 如果新的状态不在哈希表中
                insertHash(next); // 将新的状态插入到哈希表中
                q.push(next); // 将新的状态加入到队列中
            }
        }
    }
}

int main() {
    State start; // 定义初始状态

    // 从标准输入读取初始状态
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> start.board[i][j];
        }
    }
    start.step = 0; // 初始移动步数为0

    // 从标准输入读取目标状态
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            cin >> goal[i][j];
        }
    }

    // 定义目标状态结构体
    State goalState;
    // 将goal数组复制给目标状态结构体
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            goalState.board[i][j] = goal[i][j];
        }
    }


    // 定义队列
    queue<State> q;

    // 将初始状态加入到队列和哈希表中
    q.push(start);
    insertHash(start);

    // 定义是否找到目标状态的标志
    bool found = false;

    // 进行广度优先搜索
    while (!q.empty()) { // 当队列不为空时
        State cur = q.front(); // 取出队首元素
        q.pop(); // 弹出队首元素
        if (isEqual(cur, goalState)) { // 如果当前状态等于目标状态
            found = true; // 设置找到目标状态的标志为true
            cout << cur.step << endl; // 输出移动步数
            break; // 跳出循环
        }
        expand(cur, q); // 扩展当前状态的下一步可能状态，并将它们加入到队列中
    }


    if (!found) { // 如果没有找到目标状态
        cout << -1 << endl; // 输出-1表示无解
    }

    return 0;
}

/*【问题描述】

在3×3的棋盘上，摆有八个棋子，每个棋子上标有1至8的某一数字。棋盘中留有一个空格，空格用0来表示。空格周围的棋子可以移到空格中。要求解的问题是：给出一种初始布局（初始状态）和目标布局，找到一种最少步骤的移动方法，实现从初始布局到目标布局的转变。

【输入形式】

输入初始状态，一行九个数字，空格用0表示

【输出形式】

只有一行，该行只有一个数字，表示从初始状态到目标状态需要的最少移动次数（测试数据中无特殊无法到达目标状态数据）

【样例输入】

2 6 4 1 3 7 0 5 8

8 1 5 7 3 6 4 0 2

【样例输出】

31
【说明】

虽然有很多种解法，但本次作业必须采用到哈希查找技术*/
