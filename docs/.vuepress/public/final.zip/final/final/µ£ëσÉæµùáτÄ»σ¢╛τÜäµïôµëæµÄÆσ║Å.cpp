#include<iostream>
#include<stdlib.h>
#include<stack>
#define M 50
using namespace std;
typedef struct node
{
    int data;
    struct node*next;
}arcnode;
typedef struct
{
    int in;
    int vertex;
    int instack;
    arcnode *firstedge;
}Mgraph;

Mgraph g[M];
int name[M];

void toposort(int limit)
{
    stack<Mgraph*>s;
    int num=0;
    int i;
    for(i=0;i<limit;i++)
    {
        if(g[i].in==0)
        {
            s.push(&g[i]);
            g[i].instack=0;
        }
    }
    while(!s.empty())
    {
        Mgraph *po=s.top();
        s.pop();
        num++;
        name[num]=po->vertex;
        arcnode*p=po->firstedge;
        while(p!=NULL)
        {
            int n=p->data;
            g[n].in--;
            p=p->next;
        }
        for(i=0;i<limit;i++)
        {
            if(g[i].in==0&&g[i].instack==1)
            {
                s.push(&g[i]);
                g[i].instack=0;
            }
        }
    }
    if(num==limit)
    {
        for(i=1;i<=limit;i++)
        {
            cout<<name[i]<<" ";
        }
    }
    else{cout<<"ERROR";}
}

int main()
{
    int nodenum;
    cin>>nodenum;
    int i,j;
    for(i=0;i<nodenum;i++)
    {
        g[i].in=0;
        g[i].vertex=i;
        g[i].instack=1;
        g[i].firstedge=NULL;
    }
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            int num;
            cin>>num;
            if(num==0) continue;
            else{
                arcnode*temp=new arcnode;
                temp->data=j;
                temp->next=NULL;
                arcnode *po=g[i].firstedge;
            while(1)
            {
                if(po==NULL)break;
                else if(po->next==NULL)break;
                else {po=po->next;}
            }
            if(po==NULL)
            {
                g[i].firstedge=temp;
            }
            else{po->next=temp;}
            g[j].in++;
            }
        }
    }
    toposort(nodenum);
    return 0;
}


/*【输入形式】

输入的第一行包含一个正整数n，表示图中共有n个顶点。其中n不超过50。

以后的n行中每行有n个用空格隔开的整数0或1，对于第i行的第j个整数，如果为1，则表示第i个顶点有指向第j个顶点的有向边，0表示没有i指向j的有向边。当i和j相等的时候，保证对应的整数为0。

【输出形式】

如果读入的有向图含有回路，请输出“ERROR”，不包括引号。

如果读入的有向图不含有回路，请按照题目描述中的算法依次输出图的拓扑有序序列，每个整数后输出一个空格。

请注意行尾输出换行。

【样例输入】

4
0 1 0 0
0 0 1 0
0 0 0 0
0 0 1 0
【样例输出】

3 0 1 2

【说明】请注意采用邻接表存储结构时，链表创建需采用尾插法，以保证后续结点从小到大排列。

在本题中，需要严格的按照题目描述中的算法进行拓扑排序，并在排序的过程中将顶点依次储存下来，直到最终能够判定有向图中不包含回路之后，才能够进行输出。

另外，为了避免重复检测入度为零的顶点，可以通过一个栈结构维护当前处理过程中入度为零的顶点。*/