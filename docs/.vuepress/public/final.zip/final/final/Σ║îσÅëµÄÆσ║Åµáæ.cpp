#include <iostream>
using namespace std;

struct BSTNode {
    int data;
    BSTNode* left;
    BSTNode* right;
    BSTNode(int x) : data(x), left(NULL), right(NULL) {} //���Ĺ��캯��
};

BSTNode* createBST() {
    int x;
    cin >> x;
    if (x == 0) return NULL;
    BSTNode* root = new BSTNode(x);
    while (cin >> x) {
        if (x == 0) break;
        BSTNode* p = root;
        while (true) {
            if (x < p->data) {
                if (p->left == NULL) {
                    p->left = new BSTNode(x);
                    break;
                } else {
                    p = p->left;
                }
            } else {
                if (p->right == NULL) {
                    p->right = new BSTNode(x);
                    break;
                } else {
                    p = p->right;
                }
            }
        }
    }
    return root;
}

BSTNode* deleteBST(BSTNode* root, int x) {
    if (root == NULL) return NULL;
    if (x < root->data) {
        root->left = deleteBST(root->left, x);
    } else if (x > root->data) {
    } else {
        if (root->left == NULL && root->right == NULL) {
            delete root;
            return NULL;
        } else if (root->left != NULL && root->right == NULL) {
            BSTNode* left = root->left;
            delete root;
            return left;
        } else if (root->left == NULL && root->right != NULL) {
            BSTNode* right = root->right;
            delete root;
            return right;
        } else {
            BSTNode* p = root->left;
            while (p->right != NULL) {
                p = p->right;
            }
            root->data = p->data;
            root->left = deleteBST(root->left, p->data);
            return root;
        }
    }
    return root;
}

int levelBST(BSTNode* root, int y) {
    int level = 1;
    BSTNode* p = root;
    while (p != NULL) {
        if (y < p->data) {
            p = p->left;
            level++;
        } else if (y > p->data) {
            p = p->right;
            level++;
        } else {
            return level;
        }
    }
    return -1;
}

void printPreorder(BSTNode* root) {
    if (root == NULL) { //�����ǰΪ�գ����ӡ#
        cout << "# ";
        return;
    }
    cout << root->data << " ";
    printPreorder(root->left);
    printPreorder(root->right);
}

void printInorder(BSTNode* root) {
    if (root == NULL) return;
    printInorder(root->left);
    cout << root->data << " ";
    printInorder(root->right);
}

int main() {
    BSTNode* root = createBST();
    int x, y;
    cin >> x >> y;
    printPreorder(root);
    cout << endl;
    root = deleteBST(root, x);
    printInorder(root);
    cout << endl;
    cout << levelBST(root, y);
}


/*【问题描述】

请根据输入的数据创建一棵二叉排序树。然后执行相应操作。

1 删除某一值为x的结点

2 求指定结点y在二叉排序树中的层数

【输入形式】

结点数据，以0代表结束输入。

待删除的x，待求层数的y

【输出形式】

创建好的二叉排序树的拓展的前序遍历结果

删除后的二叉排序树的中序遍历结果

y所在的层数

【样例输入】

29 39 15 25 28 10 11 2 0

10

11

【样例输出】

29 15 10 2 # # 11 # # 25 # 28 # # 39 # #

2 11 15 25 28 29 39

4

【样例说明】

若待删除的结点包含左右子树，则以其左子树的最右结点代替它。

*/