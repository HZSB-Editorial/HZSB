#include<stdio.h>
#include<stdlib.h>
typedef struct Node{
    int data;
    struct Node* next;
}Linklist,*Link;
void InitLink(Link* L){
    *L = (Linklist*)malloc(sizeof(Linklist));
    (*L)->next = NULL;
}
void CreatLink(Linklist* L){
    while(1){
        int num = 0;
        scanf("%d",&num);
        if(num == 0){
            break;
        }
        else{
            Linklist* p = NULL;
            p = (Linklist*)malloc(sizeof(Linklist));
            p->data = num;
            if(L->next == NULL){
                L->next = p;
                p->next = NULL;
            }
            else{
                Linklist* n = L;
                Linklist* m = L->next;
                if(p->data <= m->data){
                    L->next = p;
                    p->next = m;
                }
                else{
                    while(m->next != NULL && m->data < p->data){
                        n = n->next;
                        m = m->next;
                    }
                    if(m->data > p->data){
                        n->next = p;
                        p->next = m;
                    }
                    else{
                        m->next = p;
                        p->next = NULL;
                    }
                }

            }
        }
    }
}
void display(Linklist* L){
    Linklist* p = L->next;
    while(p != NULL){
        printf("%d ",p->data);
        p = p->next;
    }
}
int main(){
    Linklist* L = NULL;
    InitLink(&L);
    CreatLink(L);
    display(L);
    return 0;
}

/*【问题描述】用单链表存储数据，实现对结点整体的从小到大的排序。

【注意】可采用翻转课堂上讲解的插入、冒泡排序中的一种，或者采用选择排序。每组成员一共需要实现其中的两种排序：插入和选择排序、或者冒泡和选择排序。

【输入形式】待排序的数据，以0作为结束。

【输出形式】排序后的数据

【样例输入】2 4 3 1 5 0

【样例输出】1 2 3 4 5*/
