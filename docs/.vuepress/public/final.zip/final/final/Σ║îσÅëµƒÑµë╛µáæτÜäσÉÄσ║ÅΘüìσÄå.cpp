#include <iostream>
#include <vector>
using namespace std;

bool verify_sequence_of_bst(vector<int>& sequence, int left, int right) {
    if (left >= right) {
        return true;
    }
    int root = sequence[right];  
    int i = left;
    while (i < right && sequence[i] < root) {
        i++;
    }
    for (int j = i; j < right; j++) {
        if (sequence[j] < root) {
            return false;
        }
    }
    bool left_bst = verify_sequence_of_bst(sequence, left, i - 1);
    bool right_bst = verify_sequence_of_bst(sequence, i, right - 1);
    return left_bst && right_bst;
}

int main() {
    vector<int> sequence;
    int num;
    while (cin >> num) {
        sequence.push_back(num);
    }
    bool is_bst = verify_sequence_of_bst(sequence, 0, sequence.size() - 1);
    if (is_bst) {
        cout << "true" << endl;
    } else {
        cout << "false" << endl;
    }
    return 0;
}


/*【问题描述】输入一个整数数组，判断该数组是不是某二叉查找树(折半查找树)的后序遍历的结果。如果是返回true，否则返回false。
【输入形式】输入任意长度的数组，数字之间空格分开
【输出形式】true 或者 false
【样例输入】输入5 7 6 9 11 10 8
【样例输出】true
【样例说明】由于这一整数序列是如下树的后序遍历结果：

          8
       /      \
      6      10
    /   \     /   \
   5   7     9     11

因此返回true。

【评分标准】暴力求解法不得分。

【提示】后序遍历的最后一个结点一定是根结点，那么前面的数据就可以划分为比根小的、比根大的。依此类推下去。
 */