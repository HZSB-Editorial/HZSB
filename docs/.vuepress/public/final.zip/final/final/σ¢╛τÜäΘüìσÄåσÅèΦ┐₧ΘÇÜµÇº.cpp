#include <iostream>
#include <queue>
#include <vector>

using namespace std;

const int MAXN = 100;
int n;
vector<int> adj_list[MAXN];
bool visited[MAXN];

// BFS
void bfs(int node) {
    queue<int> q;
    q.push(node);
    visited[node] = true;
    while (!q.empty()) {
        int cur_node = q.front();
        q.pop();
        for (int i = 0; i < adj_list[cur_node].size(); i++) {
            int next_node = adj_list[cur_node][i];
            if (!visited[next_node]) {
                visited[next_node] = true;
                q.push(next_node);
            }
        }
    }
}

int main() {
    cin >> n;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int num;
            cin >> num;
            if (num == 1) {
                adj_list[i].push_back(j);
                adj_list[j].push_back(i);
            }
        }
    }
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            bfs(i);
            count++;
        }
    }
    cout << count << endl;

    return 0;
}

/*
 【问题描述】
 根据输入的图的邻接矩阵A，判断此图的连通分量的个数。请使用邻接矩阵的存储结构创建图的存储，并采用BFS优先遍历算法实现，否则不得分。
【输入形式】
 第一行为图的结点个数n，之后的n行为邻接矩阵的内容，每行n个数表示。其中A[i][j]=1表示两个结点邻接，而A[i][j]=0表示两个结点无邻接关系。
【输出形式】
 输出此图连通分量的个数。
【样例输入】
 5
 0 1 1 0 0
 1 0 1 0 0
 1 1 0 0 0
 0 0 0 0 1
 0 0 0 1 0
【样例输出】
 2
【样例说明】
 邻接矩阵中对角线上的元素都用0表示。(单个独立结点，即与其它结点都没有边连接，也算一个连通分量)
 */
