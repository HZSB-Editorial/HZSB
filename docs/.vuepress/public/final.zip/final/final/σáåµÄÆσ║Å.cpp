#include<iostream>
using namespace std;
int a[30];
int last=0;

void change(int pos,int edge=last)
{
    while(1)
    {
        if(2*pos+2<=edge)
        {
            if(a[pos]>a[pos*2+1]&&a[pos]>a[pos*2+2])
                break;
            if(a[pos*2+1]<a[pos*2+2])
            {
                swap(a[pos],a[pos*2+2]);
                pos=pos*2+2;
                continue;
            }
            else{
                swap(a[pos],a[pos*2+1]);
                pos=pos*2+1;
                continue;
            }
        }
        else if(2*pos+1<=edge)
        {
            if(a[pos]<a[pos*2+1])
            {
                swap(a[pos],a[pos*2+1]);
                pos=pos*2+1;
                continue;
            }
        }
        if(2*pos+2>edge) break;
    }
}

void heapsort()
{
    int i=0;
    for(i=(last-1)/2;i>=0;i--)
    {
        if(i*2+2<=last)
        {
            if(a[i]<a[i*2+1]||a[i]<a[i*2+2])
            {
                if(a[i*2+1]<a[i*2+2])
                {
                    swap(a[i],a[i*2+2]);
                    change(i*2+2);
                }
                else{
                    swap(a[i],a[i*2+1]);
                    change(i*2+1);
                }
            }
        }
        else if(i*2+1<=last)
        {
            if(a[i]<a[i*2+1])
            {
                swap(a[i],a[i*2+1]);
                change(i*2+1);
            }
        }
    }
    for(i=0;i<=last;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;

    for(i=last;i>0;i--)
    {
        swap(a[i],a[0]);
        change(0,i-1);
        int j;
        for(j=0;j<=last;j++)
        {
            cout<<a[j]<<" ";
        }
        cout<<endl;
    }
}

int main()
{
    int i=0;
    for(i=0;;i++)
    {
        cin>>a[i];
        if(a[i]==0)
            break;
    }
    last=i-1;
    heapsort();
    return 0;
}
/*【问题描述】请用堆排序的方法对一组数据进行排序，并给出建堆以及每一趟堆排序的结果。
【输入形式】一组数据，以0作为输入的结束。
【输出形式】建大根堆的结果，以及每一趟堆排序的结果。
【样例输入】

8 3 6 1 68 12 0

【样例输出】

68 8 12 1 3 6
12 8 6 1 3 68
8 3 6 1 12 68
6 3 1 8 12 68
3 1 6 8 12 68
1 3 6 8 12 68

【样例输入】

12 9 26 11 38 52 99 27 66 15 32 0

【样例输出】

99 66 52 27 38 12 26 9 11 15 32
66 38 52 27 32 12 26 9 11 15 99
52 38 26 27 32 12 15 9 11 66 99
38 32 26 27 11 12 15 9 52 66 99
32 27 26 9 11 12 15 38 52 66 99
27 15 26 9 11 12 32 38 52 66 99
26 15 12 9 11 27 32 38 52 66 99
15 11 12 9 26 27 32 38 52 66 99
12 11 9 15 26 27 32 38 52 66 99
11 9 12 15 26 27 32 38 52 66 99
9 11 12 15 26 27 32 38 52 66 99
 */
