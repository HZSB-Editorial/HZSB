#include <iostream>
using namespace std;
#define MaxSize 50 
struct ArcNode
{
ArcNode* nextArc;
int vertex; 
};

struct VertexNode 
{
int data;
ArcNode* firstArc;
};

struct Queue 
{
int data[MaxSize];
int front;
int rear;
};

void initQueue(Queue& que) 
{
que.front = que.rear = 0;
}

void EnterQueue(Queue& que, int x) 
{
que.data[que.rear] = x;
que.rear = (que.rear + 1) % MaxSize;
}

void DelQueue(Queue& que, int* x) 
{
*x = que.data[que.front];
que.front = (que.front + 1) % MaxSize;
}

bool isEmpty(Queue que) 
{
if (que.front == que.rear)
{
return true;
}
else
{
return false;
}
}

void BFS(VertexNode v[], Queue& que, int visit[], int x) 
{
EnterQueue(que, v[x].data);
while (!isEmpty(que))
{
int temp;
DelQueue(que, &temp);
cout << temp << " ";
visit[temp] = 1;
ArcNode* p = v[temp].firstArc;
while (p != NULL)
{
if (visit[p->vertex] == 0) 
{
EnterQueue(que, p->vertex);
visit[p->vertex] = 1;
}
p = p->nextArc;
}
}
}

int main()
{
VertexNode vertex[10];
int n;
cin >> n;
for (int i = 1; i <= n; i++)
{
cin >> vertex[i].data;
vertex[i].firstArc = NULL;
}
int matrix[100][100]; 
for (int i = 1; i <= n; i++)
{
for (int j = 1; j <= n; j++)
{
cin >> matrix[i][j];
}
}
for (int i = 1; i <= n; i++)
{
for (int j = 1; j <= n; j++)
{
if (matrix[i][j] == 1)
{
ArcNode* p = new ArcNode;
p->vertex = j; 
p->nextArc = NULL;
if (vertex[i].firstArc == NULL)
{
vertex[i].firstArc = p;
}
else
{
p->nextArc = vertex[i].firstArc;
vertex[i].firstArc = p;
}
}
}
}
Queue q;
initQueue(q);
int visit[1000] = { 0 };
BFS(vertex, q, visit, 1);
return 0;
}


/*
 【问题描述】根据输入信息创建图，采用邻接表的形式存储该图，并用广度优先遍历算法遍历该图，输出遍历序列。


【输入形式】

第一行为图的结点个数n，第二行为图的顶点数据，之后的n行为邻接矩阵的内容，每行n个数表示。其中A[i][j]=1表示两个结点邻接，而A[i][j]=0表示两个结点无邻接关系。
【输出形式】
图的广度优先遍历序列

【样例输入】
 5

1 2 3 4 5
 0 1 1 0 0
 1 0 1 1 0
 1 1 0 0 0
 0 1 0 0 1
 0 0 0 1 0

【输出形式】

1 2 3 4 5
【样例输入】

4

1 2 3 4

0 1 1 0

0 0 0 0

0 0 0 1

1 0 0 0

【样例输出】

1 2 3 4
【样例说明】

邻接矩阵中对角线上的元素都用0表示。

【评分标准】

输入时的邻接矩阵只是用来表示顶点之间的关系，而存储时一定要用邻接表存储，否则不得分。

由于遍历序列与图的存储有关，遍历序列不唯一，只需要得到其中一种序列便得分。
 */