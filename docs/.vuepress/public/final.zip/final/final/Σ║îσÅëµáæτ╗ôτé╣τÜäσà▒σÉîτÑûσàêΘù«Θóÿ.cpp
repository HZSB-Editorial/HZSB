#include<iostream>
#include<cstring>
using namespace std;

typedef struct Node
{
	char data;
	struct Node* LChild;
	struct Node* RChild;
}BiTNode,*BiTree;




void Create(BiTree* root, string Pre, string In, int PreLeft, int PreRight, int InLeft, int InRight)
{
	if (InLeft > InRight)
	{
		*root = NULL;
	}
	else
	{
		*root = new BiTNode;
		(*root)->data = Pre[PreLeft];
		int MidR = 0;
		while (In[MidR] != Pre[PreLeft])
		{
			MidR++;
		}
		Create(&(*root)->LChild, Pre, In, PreLeft + 1, PreLeft + MidR - InLeft, InLeft, MidR - 1);
		Create(&(*root)->RChild, Pre, In, PreLeft + MidR - InLeft + 1, PreRight, MidR + 1, InRight);
	}
}


void PreOrder(BiTree root)
{
	if (root != NULL)
	{
		cout << root->data;
		PreOrder(root->LChild);
		PreOrder(root->RChild);
	}
	else
		return;
}


BiTree Search(BiTree root, BiTree p, BiTree q)
{
	if (root == NULL)
		return NULL;
	if (root->data == p->data || root->data == q->data)
		return root;
	BiTree left = Search(root->LChild, p, q);
	BiTree right = Search(root->RChild, p, q);
	if (!left && !right)
		return NULL;
	else if (!left && right)
		return right;
	else if (left && !right)
		return left;
	else
		return root;
}





int main()
{
	
	
	string Pre;
	string In;
	cin >> Pre;
	cin >> In;
	BiTree root = NULL;
	int len = Pre.length();
	Create(&root, Pre, In, 0, len - 1, 0, len - 1);
	BiTree p = new BiTNode;
	BiTree q = new BiTNode;
	cout << endl;
	string r;
	cin >> r;
	p->data = r[0];
	q->data = r[1];
	BiTree result = Search(root, p, q);
	if (result == NULL || result->data == root->data)
		cout << "NULL";
	else

		cout << result->data;

	return 0;
}

/*【问题描述】假设二叉树采用二叉链表方式存储，root指向根结点，p所指结点和q所指结点为二叉树中的两个不同结点，且互不成为根到该结点的路径上的点，编程求解距离它们最近的共同祖先。

【输入形式】二叉树的前序和中序遍历序列，用以创建该二叉树的链式存储结构；以及二叉树的两个结点数据 x 和 y

【输出形式】结点数据值为 x 和结点数据值为 y 的最近的共同祖先，若没有共同祖先则输出NULL，请注意一个结点本身不能成为另一个结点的共同祖先。

【样例输入】

GABDCEF

BDAEFCG

DF

【样例输出】

A*/