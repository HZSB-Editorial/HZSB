#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char a[105];
char b[105];
char next[105];
int h1, h2;

void get_Next()
{
        int i;
        int h = strlen(a);
        next[0] = -1;
        int j = -1;
        for(i = 1; i < h; i++)
        {
            while(j != -1 && a[i] != a[j+1])
            {
                j = next[j];
            }
            if(a[i] == a[j+1])
            {
                j++;
            }
            if(j == -1 || a[i+1] != a[j+1])
            {
                next[i] = j;
            }
            else
            {
                next[i] = next[j];
            }

        }
}

int KMP()
{
    int i;
    int j = -1;
    get_Next();
    for(i = 0; i < h2; i++)
    {
        while(j != -1 && b[i] != a[j+1])
        {
            j = next[j];
        }
        if(b[i] == a[j+1])
        {
            j++;
        }
        if(j == h1-1)
        {
            return i+1-h1;
        }
    }
    return -1;

}

int main()
{
    int  i, j, x;
        scanf("%s %s", b, a);
        h1 = strlen(a);
        h2 = strlen(b);
        x = KMP();
        printf("%d\n", x+1);

    return 0;
}

/*
 【问题描述】KMP算法是字符串模式匹配算法中较为高效的算法之一，其在某次子串匹配母串失败时并未回溯母串的指针而是将子串的指针移动到相应的位置。

【输入形式】1组字符串，每组字符串占一行。每行包含由空格分隔的两个字符串，字符串仅由英文小写字母组成且长度不大于100。

【输出形式】每组数据输出1行，输出后一个字符串在前一个字符串中的位置，如果不匹配，则输出0。

【样例输入】

thisisalongstring isa

【样例输出】

5

【提示】表示字符串的数据结构可以是字符数组或用串类实现。KMP算法调用很简单，但难的是理解算法的思想。掌握算法的思想才能说是掌握算法。
 */

