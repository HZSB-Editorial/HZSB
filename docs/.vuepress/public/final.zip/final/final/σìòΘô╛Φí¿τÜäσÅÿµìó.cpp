#include <iostream>
using namespace std;
typedef struct node
{

    int data;
    struct node *next;
}Node,*LinkList;

void Create(LinkList &head)
{
    int n;
    Node *r;
    head=new Node();
    head->next=NULL;
    r=head;
    Node *p;
    while(1)
    {
        cin>>n;if(n==0)break;
        p=new Node();
        p->data=n;
        p->next=NULL;
        r->next=p;
        r=p;
    }
}
void show(LinkList head)
{
    while(head->next!=NULL)
    {
        cout<<head->next->data<<" ";
        head=head->next;
    }
}
void change(LinkList head)
{ 
    node *head2,*p1=head->next,*p2=head->next->next;
    if(p2==NULL||p2->next==NULL){show(head);return;}
    while(p2!=NULL&&p2->next!=NULL)
    {
        p1=p1->next;
        p2=p2->next->next;
    }
    head2=p1->next;
    p1->next=NULL;
    p2=head2->next;
    if(p2!=NULL)
        p1=p2->next;
    else p1=NULL;
    head2->next=NULL;
    while(p2!=NULL)
    {
        p2->next=head2;
        head2=p2;
        p2=p1;if(p2==NULL)break;
        p1=p1->next;
    }
    p1=head->next;
    p2=head2->next;
    while(head2!=NULL)
    {
        head2->next=p1->next;
        p1->next=head2;
        p1=head2->next;
        head2=p2;
        if(p2!=NULL)p2=p2->next;
    }
        show(head);
}
int main()
{
    LinkList head;
    Create(head);
    change(head);
    return 0;
}

/*【问题描述】设线性表L={a1,a2,a3,...,an-2,an-1,an}采用带头结点的单链表保存，请设计一个空间复杂度为O（1）且时间上尽可能高效的算法，重新排列L中的各结点，得到线性表L'={a1,an,a2,an-1,a3,an-2,...)。【2019统考真题】

【样例输入1】1 2 3 4 5 0

【样例输出1】1 5 2 4 3

【样例输入2】1 2 3 4 5 6 0

【样例输出2】1 6 2 5 3 4

【提示】0代表输入结束*/
