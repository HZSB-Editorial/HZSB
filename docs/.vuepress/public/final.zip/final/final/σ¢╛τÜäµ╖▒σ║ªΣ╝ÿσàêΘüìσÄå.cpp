#include <iostream>
using namespace std;
const int MAXN = 10; 
int n;

struct ArcNode
{
int adjvex;
ArcNode* nextArc;
};

struct VertexNode 
{
int data;
ArcNode* firstArc;
};

int loc(int x, VertexNode g[], int n)
{
for (int i = 1; i <= n; i++)
{
if (g[i].data == x)
{
return i;
}
}
return 0;
}

void depthFirstSearch(VertexNode g[], int v, int visit[]) 
{
for (ArcNode* x = g[loc(v,g,n)].firstArc; x != NULL; x = x->nextArc) 
{
    if (visit[x->adjvex] == 0)
    {
        cout << g[x->adjvex].data<<" "; 
        visit[x->adjvex] = 1;
        depthFirstSearch(g, g[x->adjvex].data, visit);
    }
}
}

int main()
{
cin >> n;
int j, k;
VertexNode vertex[MAXN]; 
for (int i = 1; i <= n; i++)
{
cin>>vertex[i].data;
vertex[i].firstArc = NULL;
}
cin >> j >> k;
while (j != -1 && k != -1)
{
ArcNode* p = new ArcNode;
p->adjvex = k;
p->nextArc = NULL;
if (vertex[loc(j,vertex,n)].firstArc == NULL)
{
vertex[loc(j, vertex, n)].firstArc = p;
}
else
{
p->nextArc = vertex[loc(j, vertex, n)].firstArc;
vertex[loc(j, vertex, n)].firstArc = p;
}
cin >> j >> k;
}
int visit[MAXN] = { 0 }; 
cout << vertex[1].data<<" ";
visit[vertex[1].data] = 1;
depthFirstSearch(vertex, vertex[1].data, visit);
return 0;
}

/*
 问题描述】根据输入信息创建图，采用邻接表的形式存储该图 (要求每个边链表中 都是按照邻接顶点的编号由小到大的顺序链接存储的)，并用深度优先遍历算法遍历该图，输出从编号最小顶点开始的遍历序列。各顶点的数据类型为int型。



【提示】构建邻接表的算法可参考教材算法7.2。如图7.11，相比之下邻接表数据结构更简单，顶点结点中只需要域data, firstarc(对应于十字链表中的firstout)，弧结点中只有域adjvex(对应于十字链表中的headvex) 和nextarc(对应于十字链表中的tlink)。


【输入形式】仿照算法7.2的输入：

第1行输入图的结点个数n。第2行是图的各顶点数据。

之后的若干行(有向图为e行, 无向图为2e行) 依次输入各条边的弧尾、弧头的顶点编号。注意：因为算法7.2是按头插法建边链表的，所以要使得到的每个边链表中 都是按照邻接顶点的编号由小到大的顺序链接存储，就必须输入各边的顺序 首先是按照弧尾编号由小到大的顺序，并且输入弧尾相同的各边时 按照弧头顶点编号由大到小的顺序输入这些边，具体见样例输入。

最后一行输入-1和-1表示输入结束。
【输出形式】
图的深度优先遍历序列, 要求从编号最小顶点开始遍历, 输出各数据间用1个空格分隔.

【样例输入】
5

1(空格)2(空格)3(空格)4(空格)5

1(空格)3

1(空格)2

2(空格)4

2(空格)3

2(空格)1

3(空格)2

3(空格)1

4(空格)5

4(空格)2

5(空格)4

-1(空格)-1

【样例输出】

1(空格)2(空格)3(空格)4(空格)5(空格)

【评分标准】

存储时一定要用邻接表存储，否则不得分
 */
