
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<malloc.h>
#include<stdbool.h>
#define MAX 1000
typedef struct
{
	int data[MAX];
	int top;
}SeqStack;
void InitSeq(SeqStack* s)
{
	s->top = -1;
}
void push(SeqStack* s,int x)
{
	if (s->top == MAX)return 0;
	else
		s->data[++s->top] = x;
}
void pop(SeqStack* s, int* x)
{
	*x=s->data[s->top];
	if (s->top >= 0)
		s->top--;
	else
	{
		printf("??????");
		return 0;
	}
}
int isSeq(SeqStack s, int temp[], int p[],int n)
{
	int i;
	int x;
	int count = 0;
    for (i = 0;i < n;i++)
	{
		push(&s, temp[i]);
		while (s.data[s.top] == p[count]&&count<n)
		{
			count++;
			pop(&s, &x);
		}
	}
	if (s.top == -1)
		return count;
	else
		return 0;
}
int main()
{
	SeqStack s;
	InitSeq(&s);
	int n;
	int arr[MAX], arr1[MAX];
	scanf("%d", &n);
	int i;
	for (i = 0;i < n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for (i = 0;i < n;i++)
	{
		scanf("%d", &arr1[i]);
	}
	printf("%d",isSeq(s, arr, arr1, n));
}

/*
 * 【问题描述】给出一个堆栈的输入序列，试判断一个序列是否能够由这个堆栈输出。如果能，返回总的出栈次数，如果不能，返回0。序列的输入及输出都是从左往右。（输入输出序列皆为整数且没有重复的数字，如果一个数字在输入序列中没有出现，那么其在输出序列中也不会出现）
【输入形式】第一行为输入序列的长度，然后为输入序列的数字；第二行为输出序列的数字。输入数据以空格隔开。
【输出形式】如果是一个出栈序列，则返回总的出栈次数， 否则返回0
【样例输入】

5 1 2 3 4 5
1 2 3 4 5

【样例输出】5
【样例说明】第一行输入的第一个数字是序列的长度，1 2 3 4 5 输入序列，以空格隔开，输出的总的出栈次数。
 */

