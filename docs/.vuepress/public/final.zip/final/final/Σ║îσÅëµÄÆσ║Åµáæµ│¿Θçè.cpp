#include <iostream>
using namespace std;

// 定义二叉搜索树结点结构体
struct BSTNode {
    int data; // 结点数据
    BSTNode* left; // 左子树指针
    BSTNode* right; // 右子树指针
    BSTNode(int x) : data(x), left(NULL), right(NULL) {} // 构造函数
};

// 创建二叉搜索树
BSTNode* createBST() {
    int x; // 输入的数据
    cin >> x; // 读取第一个数据
    if (x == 0) return NULL; // 如果为0，返回空树
    BSTNode* root = new BSTNode(x); // 创建根节点
    while (cin >> x) { // 循环读取数据
        if (x == 0) break; // 如果为0，结束输入
        BSTNode* p = root; // 从根节点开始查找插入位置
        while (true) {
            if (x < p->data) { // 如果小于当前节点，向左子树查找
                if (p->left == NULL) { // 如果左子树为空，插入新节点
                    p->left = new BSTNode(x);
                    break;
                } else { // 如果左子树不为空，继续查找
                    p = p->left;
                }
            } else { // 如果大于等于当前节点，向右子树查找
                if (p->right == NULL) { // 如果右子树为空，插入新节点
                    p->right = new BSTNode(x);
                    break;
                } else { // 如果右子树不为空，继续查找
                    p = p->right;
                }
            }
        }
    }
    return root; // 返回创建好的二叉搜索树的根节点
}

// 删除二叉搜索树中的某个结点
BSTNode* deleteBST(BSTNode* root, int x) {
    if (root == NULL) return NULL; // 如果树为空，直接返回空指针
    if (x < root->data) { // 如果要删除的值小于当前节点，递归删除左子树中的结点，并更新左子树指针
        root->left = deleteBST(root->left, x);
    } else if (x > root->data) { // 如果要删除的值大于当前节点，递归删除右子树中的结点，并更新右子树指针
        root->right = deleteBST(root->right, x);
    } else { // 如果要删除的值等于当前节点，分四种情况处理
        if (root->left == NULL && root->right == NULL) { // 如果当前节点是叶子节点，直接删除并返回空指针
            delete root;
            return NULL;
        } else if (root->left != NULL && root->right == NULL) { // 如果当前节点只有左子树，删除当前节点并返回左子树指针
            BSTNode* left = root->left;
            delete root;
            return left;
        } else if (root->left == NULL && root->right != NULL) { // 如果当前节点只有右子树，删除当前节点并返回右子树指针
            BSTNode* right = root->right;
            delete root;
            return right;
        } else { // 如果当前节点既有左子树又有右子树，找到左子树中的最大值（或右子树中的最小值）替换当前节点，并递归删除左子树（或右子树）中的该值
            BSTNode* p = root->left; // 找到左子树中的最大值
            while (p->right != NULL) {
                p = p->right;
            }
            root->data = p->data; // 替换当前节点的值
            root->left = deleteBST(root->left, p->data); // 递归删除左子树中的该值，并更新左子树指针
            return root; // 返回更新后的当前节点
        }
    }
    return root; // 返回更新后的当前节点
}

// 查找二叉搜索树中某个值的层次
int levelBST(BSTNode* root, int y) {
    int level = 1; // 初始化层次为1
    BSTNode* p = root; // 从根节点开始查找
    while (p != NULL) { // 当未找到目标值且未到达叶子节点时循环
        if (y < p->data) { // 如果目标值小于当前节点，向左子树查找，并层次加1
            p = p->left;
            level++;
        } else if (y > p->data) { // 如果目标值大于当前节点，向右子树查找，并层次加1
            p = p->right;
            level++;
        } else { // 如果目标值等于当前节点，返回层次
            return level;
        }
    }
    return -1; // 如果未找到目标值，返回-1
}

// 前序遍历二叉搜索树并打印结点数据
void printPreorder(BSTNode* root) {
    if (root == NULL) { // 如果当前为空，打印#
        cout << "# ";
        return;
    }
    cout << root->data << " "; // 打印当前结点数据
    printPreorder(root->left);  // 递归打印左子树
    printPreorder(root->right);  // 递归打印右子树
}

// 中序遍历二叉搜索树并打印结点数据
void printInorder(BSTNode* root) {
    if (root == NULL) return; // 如果当前为空，直接返回
    printInorder(root->left);  // 递归打印左子树
    cout << root->data << " ";  // 打印当前结点数据
    printInorder(root->right);  // 递归打印右子树
}

// 主函数
int main() {
    BSTNode* root = createBST();  // 创建二叉搜索树
    int x, y;  // 输入要删除的值和要查找的值
    cin >> x >> y;
    printPreorder(root);  // 前序遍历并打印二叉搜索树
    cout << endl;
    root = deleteBST(root, x);  // 删除二叉搜索树中的某个结点
    printInorder(root);  // 中序遍历并打印二叉搜索树
    cout << endl;
    cout << levelBST(root, y);  // 查找二叉搜索树中某个值的层次
}
