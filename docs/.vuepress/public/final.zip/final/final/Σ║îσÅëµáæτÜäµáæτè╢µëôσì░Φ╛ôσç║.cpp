#include <iostream>
#include <cstring> 
using namespace std;
typedef struct Node
{
char data; 
Node* lChild;
Node* rChild;
}BiTNode, *BiTree;


void show(BiTree bt, int nLayer);
void createBiTree(BiTree* bt);

int main()
{
BiTree bt ;
createBiTree(&bt); 
show(bt,1);
return 0;
}
void show(BiTree bt, int nLayer)
{
if (bt == NULL)
{
return;
}
show(bt->rChild, nLayer + 1);
for (int i = 0; i < nLayer; i++)
{
cout <<" ";
}
cout << bt->data << endl;
show(bt->lChild, nLayer + 1);
}
void createBiTree(BiTree* bt) 
{
char ch;
cin >> ch; 
if (ch == '.')
{
*bt = NULL;
}
else
{
*bt = new BiTNode;
(*bt)->data = ch;
createBiTree(&((*bt)->lChild));
createBiTree(&((*bt)->rChild));
}
}

/*【问题描述】

        给出一个按照“扩展遍历序列”的扩展先序遍历序列字符串，'.' 代表空的子节点，大写字母代表节点内容。请通过这个字符串建立二叉树，并参考教材算法6.10，对该树进行树状打印输出。

【输入形式】

        输入只有1行 (以回车结束)，包含一个字符串S，用来建立二叉树。保证S为合法的二叉树扩展先序遍历字符串，节点内容只有大写字母，且S的长度不超过80。

【输出形式】

        该树竖向的树状输出。

【样例输入】

AB.D..CE.F...(回车)

【样例输出】注意以下样例输出中(空格)位置, 实际是输出1个空格符.

(空格)(空格)C

(空格)(空格)(空格)(空格)F

(空格)(空格)(空格)E

(空格)A

(空格)(空格)(空格)D

(空格)(空格)B
 */