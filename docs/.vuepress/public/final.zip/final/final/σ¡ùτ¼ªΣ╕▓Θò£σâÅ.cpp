#include <stdio.h>
#include <stdlib.h>
#define Stack_Size 100000

typedef struct
{
	char elem[Stack_Size];
	int top;
	int base;
}SeqStack;
void InitStack(SeqStack *S)
{
	S->top=-1;
	S->base=0;
}
int push(SeqStack *s,char x)
{
    if(s->top==Stack_Size-1)
        return 0;
    else
	{
	    s->top++;
	    s->elem[s->top]=x;
	    return 0;
	}
}
int pop(SeqStack *s,char *e)
{
    if(s->top==Stack_Size-1)
        return 0;
    else
	{
	    *e=s->elem[s->top];
	    s->top--;
	    return 0;
	}
}
int main()
{
    SeqStack s;
	InitStack(&s);
	char ch,n,e=0;
	while(n!='&')
	{
	    scanf("%c",&n);
	    if(n=='&')
            break;
 		push(&s,n);
	}
	int c=s.top+1;
	do{
        ch=getchar();
        pop(&s,&e);
        if(ch!=e)
        {
            printf("no");
            exit(0);
        }
	}while(ch!='@'&&s.top>=0);
	ch=getchar();
	if(ch=='@'&&s.top==-1)
        printf("%d",c);
    return 0;
}

/*【问题描述】试写一个算法，识别依次读入的一个以“@”为结束符的字符序列是否为形如 “序列1&序列2”  模式的字符序列。其中序列1和序列2都不含字符 “&”，且序列2是序列1的逆序列。例如，“ a+b&b+a ”是属该模式的字符序列，而 “1+3&3-1”则不是。

【输入形式】
 以@为结尾的一串字符

【输出形式】
 若符合模式则输出字符串长度，否则输出no

【样例输入】
 a+b&b+a@

【样例输出】
 3

【注意】本题务必使用顺序栈或者链式栈的一种来实现，否则不给分。*/

