#include <iostream>
#include <stack>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

int priority(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    return 0;
}

double calculate(double a, double b, char op) {
    if (op == '+') return a + b;
    if (op == '-') return a - b;
    if (op == '*') return a * b;
    if (op == '/') return a / b;
    return 0;
}

int main() {
    string expr;
    while (getline(cin, expr)) {
        stack<char> op_stack;
        stack<double> num_stack;
        int len = expr.size();
        for (int i = 0; i < len; i++) {
            if (isdigit(expr[i])) {
                double num = 0;
                while (i < len && (isdigit(expr[i]) || expr[i] == '.')) {
                    if (expr[i] == '.') {
                        i++;
                        double frac = 0.1;
                        while (i < len && isdigit(expr[i])) {
                            num += (expr[i] - '0') * frac;
                            frac *= 0.1;
                            i++;
                        }
                        break;
                    }
                    num = num * 10 + expr[i] - '0';
                    i++;
                }
                num_stack.push(num);
                i--;
            } else if (expr[i] == '(') {
                op_stack.push(expr[i]);
            } else if (expr[i] == ')') {
                while (op_stack.top() != '(') {
                    char op = op_stack.top();
                    op_stack.pop();
                    double num2 = num_stack.top();
                    num_stack.pop();
                    double num1 = num_stack.top();
                    num_stack.pop();
                    num_stack.push(calculate(num1, num2, op));
                }
                op_stack.pop();
            } else if (expr[i] == '#') {
                while (!op_stack.empty()) {
                    char op = op_stack.top();
                    op_stack.pop();
                    double num2 = num_stack.top();
                    num_stack.pop();
                    double num1 = num_stack.top();
                    num_stack.pop();
                    num_stack.push(calculate(num1, num2, op));
                }
                printf("%.2f\n", num_stack.top());
                num_stack.pop();
                break;
            } else if (expr[i] == '+' || expr[i] == '-' || expr[i] == '*' || expr[i] == '/') {
                while (!op_stack.empty() && op_stack.top() != '(' && priority(op_stack.top()) >= priority(expr[i])) {
                    char op = op_stack.top();
                    op_stack.pop();
                    double num2 = num_stack.top();
                    num_stack.pop();
                    double num1 = num_stack.top();
                    num_stack.pop();
                    num_stack.push(calculate(num1, num2, op));
                }
                op_stack.push(expr[i]);
            }
        }
    }
    return 0;
}
/*【问题描述】栈的应用，给定一个以“#”作为结束符的算式，求出算式的结果

【输入形式】以“#”结尾的表达式，运算数为正整数。每个表达式占一行。

【输出形式】输出表达式运算的结果。

【样例输入1】4+2.53*3-10/5#

【样例输出1】9.59

【样例输入2】3*(7.91-2)#

【样例输出2】17.73

【样例输入3】2.4*3.6/2#

【样例输出3】4.32

【注意】分别运用C和C++语言如何处理表达式中带小数的数据，输出数据请保留2位小数。

*/

