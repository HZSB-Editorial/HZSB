#include <stdio.h>
#include <stdlib.h>
typedef struct Node
{
    float num;
    int cifang;
    int g;
    struct Node *next;
}Node,*LinkList;
void InitList(LinkList *L)
{
    *L=(LinkList)malloc(sizeof(Node));
    (*L)->next=NULL;
}
void create(LinkList L)
{
    Node *r,*s;
    int w,c,i;
    float n;
    scanf("%d",&w);
    L->g=w;
    r=L;
    for(i=0;i<w;i++)
    {
        scanf("%f",&n);
        scanf("%d",&c);
            s=(Node*)malloc(sizeof(Node));
            s->num=n;
            s->cifang=c;
            r->next=s;
            r=s;
    }
        r->next=NULL;
}
void shuchu(LinkList L)
{
    Node *p;
    p=L;
    while(p->next!=NULL)
    {
        p=p->next;
        printf("%.1f ",p->num);
        printf("%d ",p->cifang);
    }
}
void paixu(LinkList L)
{
    Node *p,*q,*r;
    int flag=0;
    while(1)
    {
    r=p=L->next;
    q=p->next;
    while(q->cifang<=p->cifang&&flag!=1)
    {
        p=p->next;
        q=q->next;
        if(q->next==NULL)
            flag=1;
    }
    if(flag==1&&q->cifang<=p->cifang)
     break;
    if(flag==0)
    p->next=q->next;
    else p->next=NULL;
    if(q->cifang>r->cifang)
    {
        L->next=q;
        q->next=r;
    }
    else{
    while(q->cifang<=r->next->cifang)
    {
        r=r->next;
    }
    q->next=r->next;
    r->next=q;
    }
    }
}
void xiangjia(LinkList L1,LinkList L2)
{
    int flag=0;
	Node *p,*q,*r;
	float sum;
	p=L1->next;
	q=L2->next;
	r=L1;
	while(p!=NULL&&q!=NULL){
		if(p->cifang<q->cifang){
			r=p;
			p=p->next;
		}
		else if(p->cifang==q->cifang){
			sum=p->num+q->num;
			if(sum!=0){
				if(flag==0){
				    p->num=sum;
				    r=p;
				    p=p->next;
				    q=q->next;
			    }
			    if(flag!=0){
			        q->num=sum;
				    r=q;
				    q=q->next;
				    p=p->next;
				}
			}
			else{
				p=p->next;
				r->next=p;
				q=q->next;
			}
		}
		else{
			r->next=q;
			r=q;
			q=q->next;
			flag++;
		}
	}
	if(p==NULL)
	r->next=q;
	else
	r->next=p;
}
void zhengli(LinkList L)
{
    Node *p,*q;
    p=L->next;
    q=p->next;
    if(p->num==0)
    {
        L->next=q;
    }
    while(q->next!=NULL)
    {
        if(q->num==0)
        {
            p->next=q->next;
        }
        else {
            p=p->next;
            q=q->next;
        }
    }
    if(q->num==0)
        p->next=NULL;
}
int main()
{
    LinkList L1,L2;
    InitList(&L1);
    InitList(&L2);
    create(L1);
    create(L2);
    xiangjia(L1,L2);
    paixu(L1);
    zhengli(L1);
    int g,i;
    Node *p;
    p=L1;
    scanf("%d",&g);
    for(i=0;i<g&&p->next!=NULL;i++)
    {
        p=p->next;
    }
    printf("%.1f ",p->num);
    printf("%d\n",p->cifang);
    return 0;
}

/*【问题描述】编写一个程序用单链表存储多项式，并实现两个一元多项式A与B相加的函数。A，B刚开始是无序的，A与B之和按降序排列。例如：
                        多项式A:  1.2X^0  2.5X^1  3.2X^3  -2.5X^5
                        多项式B:  -1.2X^0  2.5X^1  3.2X^3   2.5X^5   5.4X^10
                        多项式A与B之和：5.4X^10  6.4X^3  5X^1
【输入形式】第一行第一个数据n代表多项式的总项数，后面的2*n个数据，每一对代表对应的某一项的系数和指数，第二行类似，第三行的数据x要查询第几项
【输出形式】多项式中某一项的系数与指数，系数保留一位小数

【输入样例】
4 1.2 0 2.5 1 3.2 3 -2.5 5
5 -1.2 0 2.5 1 3.2 3 2.5 5 5.4 10
2

【输出样例】

6.4 3

【样例说明】
第一个多项式的系数与指数对，以空格隔开
第二个多项式的系数与指数对，以空格隔开
输出第２项的系数与指数，系数与指数间用空格隔开，系数保留一位小数

【评分标准】必须用链表实现
 */
