#include<iostream>
using namespace std;

void ShellSort(int a[], int ick, int limit)
{
    int i, j;
    for(i = ick; i < limit; i ++)
    {
        int temp = a[i];
        for(j = i - ick; j >= 0 && temp < a[j]; j -= ick)
        {
            a[j + ick] = a[j];
        }
        a[j + ick] = temp;
    }
    for(i = 0; i < limit; i ++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
int main()
{
    int a[50];
    int cnt = 0;
    for(cnt = 0; ;cnt ++)
    {
        cin>>a[cnt];
        if(a[cnt] == 0) break;
    }
    int ick[10];
    int i = 0;
    while(cin>>ick[i])
    {
        i ++;
    }
    int j = 0;
    while(1)
    {
        ShellSort(a, ick[j], cnt); 
        j ++;
        if(j == i) break;
    }
    return 0;
}

/*【问题描述】给出一组数据，请用希尔排序将其按照从小到大的顺序排列好。

【输入形式】原始数据，以0作为输入的结束；第二行是增量的值，都只有3个。

【输出形式】每一趟增量排序后的结果

【样例输入】

8 3 6 1 68 12 19 3 1 0

5 3 1

【样例输出】

8 3 3 1 68 12 19 6 1
1 3 1 8 6 3 19 68 12
1 1 3 3 6 8 12 19 68

【样例输入】

5 3 9 8 2 4 1 7 10 6 0
4 2 1
【样例输出】

2 3 1 7 5 4 9 8 10 6
1 3 2 4 5 6 9 7 10 8
1 2 3 4 5 6 7 8 9 10*/