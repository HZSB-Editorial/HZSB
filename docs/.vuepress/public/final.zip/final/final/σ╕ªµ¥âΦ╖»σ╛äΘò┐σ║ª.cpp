#include <iostream>
using namespace std;
typedef struct
{
int weight, lChild, rChild, parent; 
}HTNode, *HuffmanTree;

void select(int& s1, int& s2, int n, HuffmanTree HT);

int main()
{
int n;
cin >> n;
HuffmanTree HT= new HTNode[20];
for (int i = 1; i <= 2 * n - 1; i++)
{
HT[i].lChild = 0;
HT[i].rChild = 0;
HT[i].parent = 0;
}
for (int i = 1; i <= n; i++)
{
cin>>HT[i].weight;
}
for (int i = n + 1; i <= 2 * n - 1; i++)
{
int s1, s2;
select(s1, s2, i-1, HT);
HT[i].weight = HT[s1].weight + HT[s2].weight;
HT[s1].parent = i;
HT[s2].parent = i;
}
int sum = 0;
for (int i = 1; i <= n; i++)
{
int f = i;
int counter = 0;
while (HT[f].parent != 0)
{
f = HT[f].parent;
counter++;
}
sum = sum + HT[i].weight * counter;
}
cout << sum;
}
void select(int& s1, int& s2, int n, HuffmanTree HT) 
{
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0)
{
s1 = i;
break;
}
}
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0 && HT[i].weight <= HT[s1].weight)
{
s1 = i;
}
}
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0 && i != s1)
{
s2 = i;
break;
}
}
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0 && i != s1 && HT[i].weight <= HT[s2].weight)
{
s2 = i;
}
}
}

/*【问题描述】 输入一串正整数，正整数之间用空格键分开，请建立一棵哈夫曼树，以输入的数字作为叶子节点，求这棵哈夫曼树的带权路径长度。

【输入形式】 首先输入正整数的个数n，然后是对应的n个正整数，正整数个数不超过10个

【输出形式】 输出创建的哈夫曼树的带权路径总长度

【样例输入】

5

4 5 6 7 8

【样例输出】

69
 */
