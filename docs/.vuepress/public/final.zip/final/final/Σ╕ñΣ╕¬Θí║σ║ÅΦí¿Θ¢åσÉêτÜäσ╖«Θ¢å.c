#include<stdio.h>
#define Maxsize 200
#define Elemtype int
typedef struct{
    Elemtype elem[Maxsize];
    int last;
}SeqList;

void InitList(SeqList * L){
    L->last = -1; 
}

void Input(SeqList * L){
    int i = -1;
    while(1){
        Elemtype num;
        scanf("%d",&num);
        if(num != 0){
            i++;
            L->elem[i] = num;
            L->last++;
        }
        else break;
    }
}

void Output(SeqList * L){
    int i;
    for(i = 0; i <= L->last; i++){ 
        printf("%d ",L->elem[i]);
    }
    printf("\n");
}

void Difset(SeqList * La,SeqList * Lb,SeqList * Lc){
    int i,j,k;
    k = -1;
    for(i = 0; i <= La->last; i++){
        int flag = 0;
        for(j = 0; j <= Lb->last; j++){
            if(La->elem[i] == Lb->elem[j]){
                flag = 1;
                break;
            }
            if(La->elem[i] != Lb->elem[j]){
                continue;
            }
        }
        if(!flag){
            k++;
            Lc->elem[k] = La->elem[i];
            Lc->last++;
        }
    }
}
int main(){
    SeqList La,Lb,Lc;
    InitList(&La);
    InitList(&Lb);
    InitList(&Lc);
    Input(&La);
    Input(&Lb);
    Difset(&La,&Lb,&Lc);
    Output(&Lc);
    return 0;
}

/*【问题描述】两个顺序表集合的差集
【样例输入】

25 33 57 60 48 9 13 0

12 50 23 60 4 34 25 13 0
【样例输出】

33 57 48 9

【注意】0代表输入的结束；可以用C++风格实现，也可以用C风格实现，两种风格大家均需掌握*/