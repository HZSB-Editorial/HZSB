#include<iostream>
#define N 50
using namespace std;
int dist[N][N];
int path[N][N];
int nodenum;
void floyd()
{
    int i,j,k;
    for(k=0;k<nodenum;k++)
    {
        for(i=0;i<nodenum;i++)
        {
            for(j=0;j<nodenum;j++)
            {
                if(i==j||k==i||k==j)
                    continue;
                if(dist[i][j]>dist[i][k]+dist[k][j])
                {
                    dist[i][j]=dist[i][k]+dist[k][j];
                    path[i][j]=path[i][k];
                }
            }
        }
    }
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            cout<<"from "<<i<<" to "<<j<<": dist = ";
            if(dist[i][j]==9999)
            cout<<0;
            else
                cout<<dist[i][j];
            cout<<" path:";
            int t=path[i][j];
            cout<<i<<" ";
            if(t==j)
            {
                if(i!=j)
                    cout<<j;
            }
            else
            {
                cout<<path[i][j]<<" ";
                while(t!=j)
                {
                    cout<<path[t][j]<<" ";
                    t=path[t][j];
                }
            }
            cout<<endl;
        }
    }
}
int main()
{
    cin>>nodenum;
    int i,j;
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            cin>>dist[i][j];
            path[i][j]=j;
        }
    }
    floyd();
    return 0;
}


/*【输入形式】

顶点个数n，以及n*n的邻接矩阵，其中不可达使用9999代替

【输出形式】

每两个顶点之间的最短路径和经过的顶点

注意：顶点自身到自身的dist值为0，path则为该顶点的编号

【样例输入】

4

9999 4 11 9999

6 9999 2 9999

1 9999 9999 1

9999 3 9999 9999

【样例输出】

from 0 to 0: dist = 0 path:0
from 0 to 1: dist = 4 path:0 1
from 0 to 2: dist = 6 path:0 1 2
from 0 to 3: dist = 7 path:0 1 2 3
from 1 to 0: dist = 3 path:1 2 0
from 1 to 1: dist = 0 path:1
from 1 to 2: dist = 2 path:1 2
from 1 to 3: dist = 3 path:1 2 3
from 2 to 0: dist = 1 path:2 0
from 2 to 1: dist = 4 path:2 3 1
from 2 to 2: dist = 0 path:2
from 2 to 3: dist = 1 path:2 3
from 3 to 0: dist = 6 path:3 1 2 0
from 3 to 1: dist = 3 path:3 1
from 3 to 2: dist = 5 path:3 1 2
from 3 to 3: dist = 0 path:3
 */