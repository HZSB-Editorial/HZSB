#include<iostream>
#include<cstring>
#define Leave 1000
#define Node 2 * Leave - 1
using namespace std;

typedef struct
{
	int Weight;
	int Parent;
	int LChild;
	int RChild;
}HfNode, HuffmanTree[Node + 1];


void UTF(HuffmanTree ht, int limit, int RR)
{
	int num[100];
	int count = 0;
	int p = ht[RR].Parent;
	while (p != 0)
	{
		if (RR == ht[p].LChild)
			num[count++] = 0;
		
		else if (RR == ht[p].RChild)
			num[count++] = 1;
		RR = p;
		p = ht[RR].Parent;
	}
	while (count--)
		cout << num[count];
}

void Code(HuffmanTree ht, int limit)
{
	char code[100];
	cin >> code;
	int pos = 0;
	int next = limit;
	while (code[pos] != '\0')
	{
		if (code[pos] == '0')
			next = ht[next].LChild;
		else if (code[pos] == '1')
			next = ht[next].RChild;
		if (ht[next].LChild == 0 && ht[next].RChild == 0)
		{
			char r = 'a';
			r = r + next - 1;
			cout << r;
			next = limit;
		}
		pos++;
	}
}


void Search(HuffmanTree ht, int limit, int* r1, int* r2)
{
	*r1 = *r2 = 0;
	int min1, min2;
	min1 = min2 = 9999;
	int i;
	for (i = 1; i <= limit; i++)
	{
		if (ht[i].Parent != 0)
			continue;
		if (ht[i].Weight < min1)
		{
			min2 = min1;
			*r2 = *r1;
			min1 = ht[i].Weight;
			*r1 = i;
		}
		else if (ht[i].Weight < min2)
		{
			min2 = ht[i].Weight;
			*r2 = i;
		}
	}
}
void Create(HuffmanTree ht, int W[100], int leave)
{
	int i = 0;
	for (i = 1; i <= Leave; i++)
	{
		ht[i].Weight = W[i];
		ht[i].LChild = 0;
		ht[i].RChild = 0;
		ht[i].Parent = 0;
	}

	int RR = 2 * leave - 1;
	for (i = leave + 1; i <= RR; i++)
	{
		ht[i].Weight = 0;
		ht[i].Parent = 0;
		ht[i].LChild = 0;
		ht[i].RChild = 0;
	}

	for (i = leave + 1; i <= RR; i++)
	{
		int r1, r2;
		r1 = r2 = 0;
		Search(ht, i - 1, &r1 ,& r2);
		
		ht[i].Weight = ht[r1].Weight + ht[r2].Weight;
		ht[i].LChild = r1;
		ht[i].RChild = r2;
		ht[r1].Parent = i;
		ht[r2].Parent = i;
	}
}

int main()
{
	
	
	int leave;
	cin >> leave;
	int W[Leave + 1];
	int i;
	for (i = 1; i < leave + 1; i++)
	{
		cin >> W[i];
	}
	HuffmanTree ht;
	Create(ht,W,leave);
	for (i = 1; i <= leave; i++)
	{
		UTF(ht,2*leave-1,i);
		cout << endl;
	}
	char R[20];
	cin >> R;
	for (i = 0; R[i] != '\0'; i++)
	{
		int shift = R[i] - 97 + 1;
		UTF(ht,2*leave-1,shift);
	}
	cout << endl;
	Code(ht, 2 * leave - 1);

	return 0;
}

/*【问题描述】读入n个字符所对应的权值，自底向上构造一棵哈夫曼树，自顶向下生成每一个字符对应的哈夫曼编码，并依次输出。另，求解某字符串的哈夫曼编码，求解某01序列的译码。

【输入形式】输入的第一行包含一个正整数n，表示共有n个字符需要编码。其中n不超过100。第二行中有n个用空格隔开的正整数，分别表示n个字符的权值，依次按照abcd...的默认顺序给出。然后是某字符串和某01序列。

【输出形式】前n行，每行一个字符串，表示对应字符的哈夫曼编码。然后是某字符串的哈夫曼编码，某01序列的译码。

【注意】保证每次左子树比右子树的权值小；如出现相同权值的，则先出现的在左子树，即下标小的在左子树。

【样例输入】

8
5 29 7 8 14 23 3 11

aabchg

00011110111111001

【样例输出】

0001
10
1110
1111
110
01
0000
001

000100011011100010000

acdef
 */