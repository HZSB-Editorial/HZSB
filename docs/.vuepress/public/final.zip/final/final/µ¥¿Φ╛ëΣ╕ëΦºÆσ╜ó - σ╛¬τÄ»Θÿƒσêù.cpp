#include <iostream>
#include <iomanip>
using namespace std;

const int MAXN = 100;
int q[MAXN];
int front = 0, rear = 0;

void initQueue() {
    front = rear = 0;
}

bool isQueueEmpty() {
    return front == rear;
}

void enQueue(int x) {
    q[rear] = x;
    rear = (rear + 1) % MAXN;
}

int deQueue() {
    int x = q[front];
    front = (front + 1) % MAXN;
    return x;
}

int main() {
    int n;
    cin >> n;

    enQueue(1);

    for (int i = 1; i <= n; ++i) {
        int last = 0;
        initQueue();
        for (int j = 1; j <= i; ++j) {
            int x = deQueue();
            cout << left << setw(3) << x ;
            int next = x + last;
            last = x;
            enQueue(next);
        }
        cout << endl;
        enQueue(1);
    }

    return 0;
}

/*【问题描述】参考教材P103例3.6，完成杨辉三角形的打印，请用循环队列实现（利用之前已实现的循环队列数据结构的代码）。不采用“循环队列”，不给分。

【输出要求】用 cout << setw(3) << x 这样来使每个数据输出都占3列；需包含<iomanip>

【样例输入】

4
【样例输出】

1

1 1

1 2 1

1 3 3 1*/