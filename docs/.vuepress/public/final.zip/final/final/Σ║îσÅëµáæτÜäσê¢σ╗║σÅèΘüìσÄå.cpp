#include<iostream>
#include<stack>
#include<cstdlib>
#include<cstring>
using namespace std;

typedef struct Node
{
	char data;
	struct Node* LChild;
	struct Node* RChild;
}BiTNode,*BiTree;


void CreateBT(BiTree* root)
{
	char r;

	cin >> r;
	if (r != '#')
	{
		*root = new BiTNode;
		(*root)->data = r;
		CreateBT(&(*root)->LChild);
		CreateBT(&(*root)->RChild);
	}
	else
		*root = NULL;
}

void PreOrder(BiTree root)
{
	if (root != NULL)
	{
		cout << root->data << " ";
		PreOrder(root->LChild);
		PreOrder(root->RChild);
	}
	else
		return;

}

void InOrder(BiTree root)
{
	if (root == NULL)
	{
		return;
	}

	else
	{
		InOrder(root->LChild);
		cout << root->data << " ";
		InOrder(root->RChild);
	}

}

void PostOrder(BiTree root)
{
	if (root != NULL)
	{
		PostOrder(root->LChild);
		PostOrder(root->RChild);
		cout << root->data << " ";
	}
	else
		return;
	
}

void Pre(BiTree root)
{
	stack<BiTree>R;
	while (root != NULL)
	{
		cout << root->data << " ";
		R.push(root);
		if (root->LChild != NULL)
		{
			root = root->LChild;
		}
		else if (!R.empty())
		{
			while (!R.empty())
			{
				root = R.top();
				R.pop();
				root = root->RChild;
				if (root != NULL)
					break;
			}
		}
		else
			root = NULL;
	}
}

void Post(BiTree root)
{
	stack<BiTree>R;
	BiTree p = root;
	BiTree q = NULL;
	while (p != NULL || !R.empty())
	{
		while (p != NULL)
		{
			R.push(p);
			p = p->LChild;
		}
		BiTree r = R.top();
		if (r->RChild == NULL || r->RChild == q)
		{
			cout << r->data << " ";
			R.pop();
			q = r;
		}
		else
			p = r->RChild;
	}
}





void In(BiTree root)
{
	stack<BiTree>R;
	while (root != NULL)
	{
		R.push(root);
		if (root->LChild != NULL)
		{
			root = root->LChild;
		}
		else if (!R.empty())
		{
			while (!R.empty())
			{
				root = R.top();
				R.pop();
				cout << root->data << " ";
				root = root->RChild;
				if (root != NULL)
					break;
			}
		}
		else
			root = NULL;
	}
}




int main()
{
	BiTree root = NULL;
	CreateBT(&root);

	PreOrder(root);
	cout << endl;
	InOrder(root);
	cout << endl;
	PostOrder(root);
	cout << endl;

	Pre(root);
	cout << endl;
	In(root);
	cout << endl;
	Post(root);
	cout << endl;
	return 0;
}

/*【问题描述】

        给出一个按照先序遍历得出的字符串，'#' 代表空的子节点，大写字母代表节点内容。请通过这个字符串建立二叉树，并分别采用“递归”和“非递归”的先序、中序、后序遍历的算法分别输出每一个非空节点。

【输入形式】

        输入只有一行，包含一个字符串S，用来建立二叉树。保证S为合法的二叉树先序遍历字符串，节点内容只有大写字母，且S的长度不超过100。

【输出形式】

        共有6行，每一行包含一串字符，表示分别按递归和非递归的先序、中序、后序遍历得出的节点内容，每个字母后输出一个空格。请注意行尾输出换行。

【样例输入】

ABC##DE#G##F###

【样例输出】

A B C D E G F

C B E G D F A

C G E F D B A

A B C D E G F

C B E G D F A

C G E F D B A
 */