#include <iostream>
using namespace std;

// 定义链表节点
struct Node {
    int data;
    Node* next;
};

// 尾插法创建链表
Node* createLinkedList() {
    Node* head = new Node();  // 创建头结点
    Node* tail = head;  // 尾指针指向头结点，初始时链表为空

    int num;
    cin >> num;

    while (num != 0) {
        // 创建新节点
        Node* newNode = new Node();
        newNode->data = num;
        newNode->next = NULL;

        // 将新节点插入到链表尾部
        tail->next = newNode;
        tail = newNode;

        cin >> num;
    }

    return head;
}

void traverseLinkedList(Node* head) {
    Node* current = head->next;  // 从头结点的下一个节点开始遍历

    while (current != NULL) {
        cout << current->data << " ";
        current = current->next;
    }
    cout << endl;
}

int main() {
    Node* head = createLinkedList();
    traverseLinkedList(head);

    // 释放链表内存
    Node* current = head;
    while (current != NULL) {
        Node* temp = current;
        current = current->next;
        delete temp;
    }

    return 0;
}
/*随机输入一些数据，请采用尾插法创建一个带头结点的单链表，将数据存入，然后顺序遍历该单链表并输出数据，以查看是否创建成功。

输入：6 3 5 2 9 0

输出：6 3 5 2 9

备注：0代表输入结束

*/