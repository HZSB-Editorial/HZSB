#include <iostream>
using namespace std;
#include <string>
struct Node
{
	char data;
	Node* LChild, * RChild;
};
void CreateBiTree(Node *&root,string pre, string in, int preL, int preR, int inL, int inR)
{
	if (preL>preR)
	{
		root = NULL;
	}
	else
	{
		root = new Node;
		root->data = pre[preL];
		int mid = inL;
		while (in[mid] != pre[preL])
		{
			mid++;
		}
		CreateBiTree(root->LChild, pre, in, preL + 1, preL + mid - inL, inL, mid - 1);
		CreateBiTree(root->RChild, pre, in, preL + mid - inL + 1, preR, mid + 1, inR);
	}
}
bool Traverse(Node* root)
{
	if ((root->LChild == NULL && root->RChild != NULL) || (root->LChild != NULL && root->RChild == NULL))
	{
		return false;
	}
	else if (root->LChild == NULL && root->RChild == NULL)
	{
		return true;
	}
	else
	{
		return Traverse(root->LChild) && Traverse(root->RChild);
	}
}
int main()
{
	string  pre, in;
	cin >> pre;
	cin >> in;
	int n = pre.length();
	Node* root;
	CreateBiTree(root, pre, in, 0, n - 1, 0, n - 1);
	if (Traverse(root))
	{
		cout << "Yes";
	}
	else
	{
		cout << "No";
	}
	return 0;
}


/*【问题描述】设二叉树按二叉链表存放，写算法判别一棵二叉树是否是一棵正则二叉树。正则二叉树是指在二叉树中不存在子树个数为1的结点。
【输入说明】二叉树的前序和中序遍历序列，以此构造二叉树的链式存储
【输出说明】若该二叉树是一棵正则二叉树，则输出Yes，否则输出No
【样例输入】
ABHDCEFG
HBDAEFCG
【样例输出】
No
 */