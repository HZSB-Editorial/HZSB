#include<iostream>
#include<cstring>
#include<stdlib.h>
using namespace std;

typedef struct Node
{
	char data;
	struct Node* LChild;
	struct Node* RChild;
}BiTNode,*BiTree;





void Create(BiTree* root, string Post, string In, int PostLeft, int PostRight, int InLeft, int InRight)
{
	if (PostLeft > PostRight)
	{
		*root = NULL;
	}
	else
	{
		*root = new BiTNode;
	
		(*root)->data = Post[PostRight];

		int MidR = 0;
		while (In[MidR] != Post[PostRight])
		{
			MidR++;
		}


		Create(&((*root)->LChild), Post, In, PostLeft, PostLeft + MidR - InLeft - 1, InLeft, MidR - 1);
		Create(&((*root)->RChild), Post, In, PostLeft + MidR - InLeft, PostRight - 1, MidR + 1, InRight);
	}
}

void PreOrder(BiTree root);


int main()
{
	string Post;
	string In;
	cin >> In;
	cin >> Post;
	int len = In.length();
	BiTree root = NULL;
	Create(&root, Post, In, 0, len - 1, 0, len - 1);
	PreOrder(root);
	return 0;
}
void PreOrder(BiTree root)
{
	if (root != NULL)
	{
		cout << root->data;
		PreOrder(root->LChild);
		PreOrder(root->RChild);
	}
	else
		return;
}

/*【问题描述】 根据一棵二叉树的中序遍历序列和后序遍历序列，求这棵树的前序遍历序列。

【输入形式】 一棵树的中序遍历序列和该树后序遍历序列。输入序列中仅含有小写字母，且没有重复的字母

【输出形式】 一棵树的前序遍历序列

【样例输入】
dbeafcg

debfgca

【样例输出】

abdecfg

*/