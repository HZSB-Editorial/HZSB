#include<iostream>
#define N 50
#define Max 999999
using namespace std;

int R[N][N];
typedef struct
{
    int adjvex;
    int loweight;
    int flag;
}Closedge;

int Min(Closedge * MTree, int limit)
{
    int min = 99999;
    int i = 0;
    int res = 0;
    for(i = 1; i <= limit; i ++)
    {
        if(MTree[i].loweight < min && MTree[i].flag == 1)
        {
            min = MTree[i].loweight;
            res = i;
        }
    }
    return res;
}

void Prim(int limit)
{
    int sum = 0;
    Closedge MTree[limit + 1];
    int i = 0;
    for(i = 1; i <= limit; i ++) //��ʼ��
    {
        if(i != 1)
            MTree[i].adjvex = 1;
        MTree[i].flag = 1;
        MTree[i].loweight = R[1][i];
    }
    for(i = 2; i <= limit; i ++)
    {
        int MinId = Min(MTree, limit);
        cout<<MTree[MinId].adjvex<<'-'<<MinId<<':'<<MTree[MinId].loweight<<endl;
        sum += MTree[MinId].loweight;
        MTree[MinId].flag = 0;
        int j = 0;
        for(j = 2; j <= limit; j ++)
        {
            if(R[MinId][j] < MTree[j].loweight)
            {
                MTree[j].loweight = R[MinId][j];
                MTree[j].adjvex = MinId;
            }
        }
    }
    cout<<sum;
}

int main()
{
    int NodeNum;
    int RelationNum;
    cin>>NodeNum>>RelationNum;
    int i = 0;
    int j = 0;
    for(i = 1; i <= NodeNum; i++)
    {
        for(j = 1; j <= NodeNum; j ++)
        {
            R[i][j] = Max;
        }
    }
    while(RelationNum --)
    {
        int i, j, k;
        cin>>i>>j>>k;
        R[i][j] = k;
        R[j][i] = k;
    }
    Prim(NodeNum);
    return 0;
}

/*
【问题描述】
 已知含有n个顶点的带权连通无向图，采用邻接矩阵存储，邻接矩阵以三元组的形式给出，只给出不包括主对角线元素在内的下三角形部分的元素，且不包括不相邻的顶点对。请采用Prim算法，求该连通图从1号顶点出发的最小生成树的权值之和。
【输入形式】
 第一行给出结点个数n和三元组的个数count，以下每行给出一个三元组，数之间用空格隔开。（注意这里顶点的序号是从1到n，而不是0到n-1，程序里要小心！）
【输出形式】
 求解的最小生成树的各条边、边的权值之和
【样例输入】
 5 8
 2 1 7
 3 1 6
 3 2 8
 4 1 9
 4 2 4
 4 3 6
 5 2 4
 5 4 2
【样例输出】

1-3:6
3-4:6
4-5:2
4-2:4
18

【样例说明】
 权值是正整数，可能很大，但不需要考虑整型溢出问题
 */
