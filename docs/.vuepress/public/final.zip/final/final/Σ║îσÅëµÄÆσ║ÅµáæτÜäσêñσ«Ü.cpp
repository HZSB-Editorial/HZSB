#include<iostream>
#include<stdlib.h>
#define N 50
using namespace std;

typedef struct Node
{
    int data;
    struct Node * LChild;
    struct Node * RChild;
}BtNode, * BiTree;

BiTree root = NULL;
bool res = true;
int r[N];
int count = 0;

void CreatBiTree(BiTree * root, int PreOrder[20], int InOrder[20], int PreLeft, int PreRight, int InLeft, int InRight)
{
    if(InLeft > InRight) *root = NULL;
    else
    {
        *root = (BtNode*)malloc(sizeof(BtNode));
        (*root)->data = PreOrder[PreLeft];
        int i = 0;
        int mid = 0;
        for(i = InRight; i >= InLeft; i --)
        {
            if(InOrder[i] == PreOrder[PreLeft])
            {
                int j, k;
                bool flag = true;
                for(j = PreLeft + i - InLeft; j > PreLeft; j --)
                {
                    for(k = InLeft; k < i; k ++)
                    {
                        if(PreOrder[j] == InOrder[k]) break;
                    }
                    if(k == i)
                    {
                        flag = false;
                        break;
                    }
                }
                if(flag)
                {
                    mid = i;
                    break;
                }
                else continue;
            }
        }
        for(i = mid - 1; i >= InLeft; i --)
        {
            if(InOrder[i] == InOrder[mid])
            {
                res = false;
                break;
            }
        }
        CreatBiTree(&((*root)->LChild), PreOrder, InOrder, PreLeft + 1, PreLeft + mid - InLeft, InLeft, mid - 1);
        CreatBiTree(&((*root)->RChild), PreOrder, InOrder, PreLeft + mid - InLeft + 1, PreRight, mid + 1, InRight);
    }
}

void Order(BtNode * ptr)
{
    if(ptr == NULL)
        return ;
    else
    {
        Order(ptr->LChild);
        r[count ++] = ptr->data;
        Order(ptr->RChild);
    }
}
int main()
{
    int PreOrder[20];
    int InOrder[20];
    int cnt = 0;
    int i = 0;
    for(i = 0; ; i ++)
    {
        cin>>PreOrder[i];
        if(PreOrder[i] == 0) break;
        cnt ++; 
    }
    for(i = 0; ; i ++)
    {
        cin>>InOrder[i];
        if(InOrder[i] == 0) break;
    }
    CreatBiTree(&root, PreOrder, InOrder, 0, cnt - 1, 0, cnt - 1);
    //if(!res) cout<<"false"<<endl;
    //else
    {
        Order(root);
        for(i = 0; i < count; i ++)
        {
            if(r[i] < r[i-1])
            {
                break;
            }
        }
        if(i < count ) cout<<"false";
        else cout<<"true";
    }
    return 0;
}


/*问题描述】课后作业第6题。试写一个判别给定二叉树是否为二叉排序树的算法。以前序遍历序列和中序遍历序列给出该二叉树的结点，并创建该二叉树。然后再进行判断。请注意，树中结点关键字可能相同。

【样例输入1】

6 4 5 8 6 9 0

4 5 6 6 8 9 0
【样例输出1】

true

【样例输入2】

6 4 7 8 0

4 7 6 8 0
【样例输出2】

false

【提示】若直接根据给定的中序是否有序来进行判断，此种判断方法不得分。务必先创建二叉树的链式存储，再对其进行判断。*/