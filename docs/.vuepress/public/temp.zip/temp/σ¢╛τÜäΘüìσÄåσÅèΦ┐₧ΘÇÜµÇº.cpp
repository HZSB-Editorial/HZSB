#include <iostream>
#include <queue>
using namespace std;

int main() {
  int n; // 结点个数
  cin >> n;
  int mat[n][n]; // 邻接矩阵
  int visit[n]; // 访问标记
  int count = 0; // 连通分量个数
  queue<int> q; // 辅助队列
  // 读入邻接矩阵
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      cin >> mat[i][j];
    }
    visit[i] = 0; // 初始化访问标记为0
  }
  // 遍历所有结点
  for (int i = 0; i < n; i++) {
    if (visit[i] == 0) { // 如果未访问过
      count++; // 连通分量加一
      visit[i] = 1; // 标记为已访问
      q.push(i); // 入队
      while (!q.empty()) { // 当队列不为空时
        int cur = q.front(); // 出队一个结点
        q.pop();
        for (int j = 0; j < n; j++) { // 遍历邻接矩阵的一行
          if (mat[cur][j] == 1 && visit[j] == 0) { // 如果邻接且未访问
            visit[j] = 1; // 标记为已访问
            q.push(j); // 入队
          }
        }
      }
    }
  }
  cout << count << endl; // 输出结果
  return 0;
}

