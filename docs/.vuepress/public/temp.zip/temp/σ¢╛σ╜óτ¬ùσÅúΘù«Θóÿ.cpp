#include <iostream>
#include <stdio.h>
using namespace std;

// 定义窗口的结构体
struct Window {
  int id; // 窗口编号
  int x1, y1, x2, y2; // 窗口位置
};

// 定义判断点是否在窗口内的函数
int isInside(int x, int y, struct Window w) {
  if (x >= w.x1 && x <= w.x2 && y >= w.y1 && y <= w.y2) {
    return 1; // 点在窗口内，返回1
  } else {
    return 0; // 点不在窗口内，返回0
  }
}

// 定义将窗口移动到最顶层的函数
void moveToTop(int i, int n, struct Window windows[]) {
  struct Window temp = windows[i]; // 保存要移动的窗口
  for (int j = i; j < n - 1; j++) { // 将后面的窗口依次向前移动一位
    windows[j] = windows[j + 1];
  }
  windows[n - 1] = temp; // 将要移动的窗口放到最后一位
}

int main() {
  int n, m; // 窗口数和点击数
  scanf("%d%d", &n, &m); // 输入窗口数和点击数
  struct Window windows[n]; // 创建窗口数组
  for (int i = 0; i < n; i++) { // 输入每个窗口的信息
    scanf("%d%d%d%d", &windows[i].x1, &windows[i].y1, &windows[i].x2, &windows[i].y2);
    windows[i].id = i + 1; // 设置窗口编号
  }
  for (int i = 0; i < m; i++) { // 对于每次点击
    int x, y; // 点击坐标
    scanf("%d%d", &x, &y); // 输入点击坐标
    int found = 0; // 是否找到包含点击点的窗口的标志，初始为0
    for (int j = n - 1; j >= 0; j--) { // 遍历窗口数组，从后往前查找
      if (isInside(x, y, windows[j])) { // 如果找到第一个包含点击点的窗口
        printf("%d\n", windows[j].id); // 输出其编号
        moveToTop(j, n, windows); // 将其移动到最顶层
        found = 1; // 将找到标志设为1
        break; // 结束循环
      }
    }
    if (found == 0) { // 如果没有找到包含点击点的窗口
      printf("IGNORED\n"); // 输出-1
    }
  }
  return 0;
}

