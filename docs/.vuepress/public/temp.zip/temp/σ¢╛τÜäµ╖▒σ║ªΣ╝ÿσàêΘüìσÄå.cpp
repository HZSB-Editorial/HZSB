#include <iostream>
using namespace std;
const int MAXN = 10; 
int n;

struct ArcNode
{
int adjvex;
ArcNode* nextArc;
};

struct VertexNode 
{
int data;
ArcNode* firstArc;
};

int loc(int x, VertexNode g[], int n)
{
for (int i = 1; i <= n; i++)
{
if (g[i].data == x)
{
return i;
}
}
return 0;
}

void depthFirstSearch(VertexNode g[], int v, int visit[]) 
{
for (ArcNode* x = g[loc(v,g,n)].firstArc; x != NULL; x = x->nextArc) 
{
    if (visit[x->adjvex] == 0)
    {
        cout << g[x->adjvex].data<<" "; 
        visit[x->adjvex] = 1;
        depthFirstSearch(g, g[x->adjvex].data, visit);
    }
}
}

int main()
{
cin >> n;
int j, k;
VertexNode vertex[MAXN]; 
for (int i = 1; i <= n; i++)
{
cin>>vertex[i].data;
vertex[i].firstArc = NULL;
}
cin >> j >> k;
while (j != -1 && k != -1)
{
ArcNode* p = new ArcNode;
p->adjvex = k;
p->nextArc = NULL;
if (vertex[loc(j,vertex,n)].firstArc == NULL)
{
vertex[loc(j, vertex, n)].firstArc = p;
}
else
{
p->nextArc = vertex[loc(j, vertex, n)].firstArc;
vertex[loc(j, vertex, n)].firstArc = p;
}
cin >> j >> k;
}
int visit[MAXN] = { 0 }; 
cout << vertex[1].data<<" ";
visit[vertex[1].data] = 1;
depthFirstSearch(vertex, vertex[1].data, visit);
return 0;
}


