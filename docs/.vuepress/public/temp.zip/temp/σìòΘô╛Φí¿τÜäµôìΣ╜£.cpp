#include <iostream>
using namespace std;
struct Node
{
	int data;
	Node* next;
};
void initList(Node* &head)
{
	head = new Node;
	head->next = NULL;
}
void CreateFromHead(Node* head)
{
	
	int data;
	cin >> data;
	while (data != 0)
	{
		Node* p = new Node;
		p->data = data;
		p->next = head->next;
		head->next = p;
		cin >> data;
	}
}
void Print(Node* head)
{
	while (head->next != NULL)
	{
		head = head->next;
		cout << head->data<<" ";
	}
	cout << endl;
}
void DelList(Node* head)
{
	head = head->next;
	Node* p = head->next;
	while (p != NULL)
	{
		if (head->data == p->data)
		{
			head->next = p->next;
			p = p->next;
		}
		else
		{
			head = head->next;
			p = p->next;
		}
	}
}
int main()
{
	Node* head;
	initList(head);
	CreateFromHead(head);
	Print(head);
	DelList(head);
	Print(head);
	return 0;
}
