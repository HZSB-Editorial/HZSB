#include <iostream>
using namespace std;
#define MaxSize 50 
struct ArcNode
{
ArcNode* nextArc;
int vertex; 
};

struct VertexNode 
{
int data;
ArcNode* firstArc;
};

struct Queue 
{
int data[MaxSize];
int front;
int rear;
};

void initQueue(Queue& que) 
{
que.front = que.rear = 0;
}

void EnterQueue(Queue& que, int x) 
{
que.data[que.rear] = x;
que.rear = (que.rear + 1) % MaxSize;
}

void DelQueue(Queue& que, int* x) 
{
*x = que.data[que.front];
que.front = (que.front + 1) % MaxSize;
}

bool isEmpty(Queue que) 
{
if (que.front == que.rear)
{
return true;
}
else
{
return false;
}
}

void BFS(VertexNode v[], Queue& que, int visit[], int x) 
{
EnterQueue(que, v[x].data);
while (!isEmpty(que))
{
int temp;
DelQueue(que, &temp);
cout << temp << " ";
visit[temp] = 1;
ArcNode* p = v[temp].firstArc;
while (p != NULL)
{
if (visit[p->vertex] == 0) 
{
EnterQueue(que, p->vertex);
visit[p->vertex] = 1;
}
p = p->nextArc;
}
}
}

int main()
{
VertexNode vertex[10];
int n;
cin >> n;
for (int i = 1; i <= n; i++)
{
cin >> vertex[i].data;
vertex[i].firstArc = NULL;
}
int matrix[100][100]; 
for (int i = 1; i <= n; i++)
{
for (int j = 1; j <= n; j++)
{
cin >> matrix[i][j];
}
}
for (int i = 1; i <= n; i++)
{
for (int j = 1; j <= n; j++)
{
if (matrix[i][j] == 1)
{
ArcNode* p = new ArcNode;
p->vertex = j; 
p->nextArc = NULL;
if (vertex[i].firstArc == NULL)
{
vertex[i].firstArc = p;
}
else
{
p->nextArc = vertex[i].firstArc;
vertex[i].firstArc = p;
}
}
}
}
Queue q;
initQueue(q);
int visit[1000] = { 0 };
BFS(vertex, q, visit, 1);
return 0;
}


