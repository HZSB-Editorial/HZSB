#include <iostream>
#include <cstring> 
using namespace std;
typedef struct Node
{
char data; 
Node* lChild;
Node* rChild;
}BiTNode, *BiTree;


void show(BiTree bt, int nLayer);
void createBiTree(BiTree* bt);

int main()
{
BiTree bt ;
createBiTree(&bt); 
show(bt,1);
return 0;
}
void show(BiTree bt, int nLayer)
{
if (bt == NULL)
{
return;
}
show(bt->rChild, nLayer + 1);
for (int i = 0; i < nLayer; i++)
{
cout <<" ";
}
cout << bt->data << endl;
show(bt->lChild, nLayer + 1);
}
void createBiTree(BiTree* bt) 
{
char ch;
cin >> ch; 
if (ch == '.')
{
*bt = NULL;
}
else
{
*bt = new BiTNode;
(*bt)->data = ch;
createBiTree(&((*bt)->lChild));
createBiTree(&((*bt)->rChild));
}
}

