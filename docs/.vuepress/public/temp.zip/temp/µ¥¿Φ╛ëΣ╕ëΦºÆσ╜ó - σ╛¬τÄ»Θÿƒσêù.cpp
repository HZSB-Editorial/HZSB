#include <iostream>
#include <iomanip>
using namespace std;

const int MAXN = 100;
int q[MAXN];
int front = 0, rear = 0;

void initQueue() {
    front = rear = 0;
}

bool isQueueEmpty() {
    return front == rear;
}

void enQueue(int x) {
    q[rear] = x;
    rear = (rear + 1) % MAXN;
}

int deQueue() {
    int x = q[front];
    front = (front + 1) % MAXN;
    return x;
}

int main() {
    int n;
    cin >> n;

    enQueue(1);

    for (int i = 1; i <= n; ++i) {
        int last = 0;
        initQueue();
        for (int j = 1; j <= i; ++j) {
            int x = deQueue();
            cout << left << setw(3) << x ;
            int next = x + last;
            last = x;
            enQueue(next);
        }
        cout << endl;
        enQueue(1);
    }

    return 0;
}

