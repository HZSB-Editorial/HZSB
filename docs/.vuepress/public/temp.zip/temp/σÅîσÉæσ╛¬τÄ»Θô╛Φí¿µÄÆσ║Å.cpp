#include <iostream>
using namespace std;

typedef struct DNode
{
    int data;
    struct DNode *prior,*next;
}DNode,*DoubleList;
void InitList(DoubleList &L)
{
    L=new DNode;
    (*L).next=L;
    (*L).prior=L;
}
void create(DoubleList L)
{
    DNode *r,*s;
    int c;
    while(1)
    {
        cin>>c;
        if(c==0) break;
            s=new DNode;
            r=L->next;
            s->data=c;
            while(r->next!=L&&s->data>r->data)
            {
                r=r->next;
            }
            if(s->data<r->data)
            {
                s->prior=r->prior;
                r->prior->next=s;
                s->next=r;
                r->prior=s;
            }
            else{
               r->next=s;
               s->prior=r;
               s->next=L;
               L->prior=s;
            }
    }
}
void shuchu(DoubleList L)
{
    DNode *p;
    p=L;
    while(p->next!=L)
    {
        p=p->next;
        cout<<p->data<<" ";
    }
}

int main()
{
    DoubleList L;
    InitList(L);
    create(L);
    shuchu(L);
    return 0;
}



