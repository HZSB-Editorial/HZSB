#include<iostream>
using namespace std;
typedef struct
{
	int h;
	int l;
	int data;
	int flag;
}s;
int main()
{
	int m,n,flag2=0,k=0;
	cin>>m>>n;
	s a[m],b[n],c[m+n];
	for(int i=0;i<m;i++)
	{
		cin>>a[i].h>>a[i].l>>a[i].data;
	}
	
	for(int i=0;i<n;i++)
	{
		cin>>b[i].h>>b[i].l>>b[i].data;
	}
	
	for(int j=0;j<n;j++)
	{
		b[j].flag=0;
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			if(a[i].h==b[j].h&&a[i].l==b[j].l&&b[j].flag==0)
			{
				a[i].data+=b[j].data;
				b[j].flag=1;
			}
		}
	}
	for(int i=0;i<m;i++)
	{
		if(a[i].data!=0)
			{
				flag2=1;
			}
	}
	for(int i=0;i<n;i++)
	{
		if(b[i].flag==0&&b[i].data!=0)
				flag2=1;
	}
	if(flag2==0)
	{
		cout<<"-1 -1 -1";
	}
	else{
	
	for(int i=0;i<m;i++)
	{
		if(a[i].data==0)
		continue;
		c[k]=a[i];
		k++;
	}
	
	
	for(int i=0;i<n;i++)
	{
	   if(b[i].data==0||b[i].flag==1)
		continue;
		c[k]=b[i];
		k++;
	}
	
	for(int i=0;i<k-1;i++)
	{
		for(int j=0;j<k-i-1;j++)
		{
			if(c[j+1].h<c[j].h)
			{
				s t=c[j];
				c[j]=c[j+1];
				c[j+1]=t;
			}
		}
	}
	for(int i=0;i<k-1;i++)
	{
		for(int j=0;j<k-i-1;j++)
		{
			if(c[j+1].h==c[j].h&&c[j+1].l<c[j].l)
			{
				s t=c[j];
				c[j]=c[j+1];
				c[j+1]=t;
			}
		}
	}
	for(int i=0;i<k;i++)
	{
	   cout<<c[i].h<<" "<<c[i].l<<" "<<c[i].data<<endl;
	}
	
      }
	return 0;
}
