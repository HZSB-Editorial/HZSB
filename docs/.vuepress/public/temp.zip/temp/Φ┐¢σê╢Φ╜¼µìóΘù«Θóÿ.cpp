#include <iostream>
#include <cstring>
using namespace std;

const int MAXSIZE = 100;

class Stack {
public:
    Stack() { top = -1; }
    bool isEmpty() const { return top == -1; }
    bool isFull() const { return top == MAXSIZE-1; }
    void push(char ch) { 
        if (isFull()) return;
        top++;
        s[top] = ch;
    }
    char pop() { 
        if (isEmpty()) return '\0';
        char ch = s[top];
        top--;
        return ch;
    }
private:
    char s[MAXSIZE];
    int top;
};
string convert_base(int decimal, int base) {
    const char* digits = "0123456789ABCDEF";
    Stack rem_stack;
    while (decimal > 0) {
        int rem = decimal % base;
        rem_stack.push(digits[rem]);
        decimal = decimal / base;
    }
    string new_digits = "";
    while (!rem_stack.isEmpty()) {
        new_digits += rem_stack.pop();
    }
    return new_digits;
}

int main() {
    int decimal, base;
    cin >> decimal >> base;
    string result = convert_base(decimal, base);
    cout << result << endl;
    return 0;
}


