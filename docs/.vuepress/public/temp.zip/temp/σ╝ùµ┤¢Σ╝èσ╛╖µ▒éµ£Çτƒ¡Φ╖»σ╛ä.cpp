#include<iostream>
#define N 50
using namespace std;
int dist[N][N];
int path[N][N];
int nodenum;
void floyd()
{
    int i,j,k;
    for(k=0;k<nodenum;k++)
    {
        for(i=0;i<nodenum;i++)
        {
            for(j=0;j<nodenum;j++)
            {
                if(i==j||k==i||k==j)
                    continue;
                if(dist[i][j]>dist[i][k]+dist[k][j])
                {
                    dist[i][j]=dist[i][k]+dist[k][j];
                    path[i][j]=path[i][k];
                }
            }
        }
    }
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            cout<<"from "<<i<<" to "<<j<<": dist = ";
            if(dist[i][j]==9999)
            cout<<0;
            else
                cout<<dist[i][j];
            cout<<" path:";
            int t=path[i][j];
            cout<<i<<" ";
            if(t==j)
            {
                if(i!=j)
                    cout<<j;
            }
            else
            {
                cout<<path[i][j]<<" ";
                while(t!=j)
                {
                    cout<<path[t][j]<<" ";
                    t=path[t][j];
                }
            }
            cout<<endl;
        }
    }
}
int main()
{
    cin>>nodenum;
    int i,j;
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            cin>>dist[i][j];
            path[i][j]=j;
        }
    }
    floyd();
    return 0;
}


