#include <iostream>
#include <stack>
using namespace std;

int main() {
    int n;
    cin >> n;
    stack<int> s;
    int input[n];
    for (int i = 0; i < n; i++) {
        cin >> input[i];
    }
    int output[n];
    for (int i = 0; i < n; i++) {
        cin >> output[i];
    }
    int i = 0, j = 0, count = 0;
    while (i < n && j < n) {
        s.push(input[i]);
        i++;
        while (!s.empty() && s.top() == output[j]) {
            s.pop();
            j++;
            count++;
        }
    }
    if (count == n) {
        cout << count << endl;
    } else {
        cout << 0 << endl;
    }
    return 0;
}

