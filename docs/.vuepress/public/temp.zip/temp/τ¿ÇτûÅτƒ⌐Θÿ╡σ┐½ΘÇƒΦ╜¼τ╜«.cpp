#include<bits/stdc++.h>
using namespace std;
typedef struct
{
	int h;
	int l;
	int data;
}o;

int main()
{
	int r,c;
	o s[12500];
	cin>>r>>c;
	int a[205][205],data,m=0;
	for(int i=0;i<r;i++)
	{   
		for(int j=0;j<c;j++)
		{ 	
		   a[i][j]=0;
		   cin>>data;
			if(data!=0)
			{	
			   s[m].h=i;
			   s[m].l=j;
			   s[m].data=data;
			   m++;
			}
		}
	}
	for(int i=0;i<m;i++)
	{
		int t=s[i].h;
		s[i].h=s[i].l;
		s[i].l=t;
	}
	/*for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{ 	
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}*/
	
    for(int i=0;i<m;i++)
    {
    	a[s[i].h][s[i].l]=s[i].data;
	}
    
	for(int i=0;i<c;i++)
	{
		for(int j=0;j<r;j++)
		{ 	
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
	return 0;
}
