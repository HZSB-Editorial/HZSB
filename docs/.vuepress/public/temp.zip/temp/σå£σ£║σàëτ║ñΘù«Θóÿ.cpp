#include <iostream>
using namespace std;
struct graph
{
	int vernum;
	int data[30][30];
};

void Prim(graph g, int shortest[], int path[])
{
	
	for (int j = 2; j <= g.vernum; j++)
	{
		int min = 9999;
		int k = 2;
		for (int i = 2; i <= g.vernum; i++)
		{
			if (shortest[i] < min && path[i] == 0)
			{
				min = shortest[i];
				k = i;
			}
		}
		path[k] = min;
		for (int m = 2; m <= g.vernum; m++)
		{
			if (g.data[k][m] < shortest[m] && path[m] == 0)
			{
				shortest[m] = g.data[k][m];
			}
		}

	}
}
int main()
{
	int path[100] = { 0 };
	int shortest[100];
	graph g;
	cin >> g.vernum;
	for (int i = 1; i <= g.vernum; i++)
	{
		for (int j = 1; j <= g.vernum; j++)
		{
			cin >> g.data[i][j];
			if (g.data[i][j] == 0)
			{
				g.data[i][j] = 9999;
			}
		}
	}
	for (int i = 2; i <= g.vernum; i++)
	{
		shortest[i] = g.data[1][i];
	}
	Prim(g, shortest, path);
	int sum = 0;
	for (int i = 2; i <= g.vernum; i++)
	{
		sum = sum + path[i];
	}
	cout << sum;
	return 0;
}
