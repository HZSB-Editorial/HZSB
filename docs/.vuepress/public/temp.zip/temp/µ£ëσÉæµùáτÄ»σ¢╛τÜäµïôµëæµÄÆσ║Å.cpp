#include<iostream>
#include<stdlib.h>
#include<stack>
#define M 50
using namespace std;
typedef struct node
{
    int data;
    struct node*next;
}arcnode;
typedef struct
{
    int in;
    int vertex;
    int instack;
    arcnode *firstedge;
}Mgraph;

Mgraph g[M];
int name[M];

void toposort(int limit)
{
    stack<Mgraph*>s;
    int num=0;
    int i;
    for(i=0;i<limit;i++)
    {
        if(g[i].in==0)
        {
            s.push(&g[i]);
            g[i].instack=0;
        }
    }
    while(!s.empty())
    {
        Mgraph *po=s.top();
        s.pop();
        num++;
        name[num]=po->vertex;
        arcnode*p=po->firstedge;
        while(p!=NULL)
        {
            int n=p->data;
            g[n].in--;
            p=p->next;
        }
        for(i=0;i<limit;i++)
        {
            if(g[i].in==0&&g[i].instack==1)
            {
                s.push(&g[i]);
                g[i].instack=0;
            }
        }
    }
    if(num==limit)
    {
        for(i=1;i<=limit;i++)
        {
            cout<<name[i]<<" ";
        }
    }
    else{cout<<"ERROR";}
}

int main()
{
    int nodenum;
    cin>>nodenum;
    int i,j;
    for(i=0;i<nodenum;i++)
    {
        g[i].in=0;
        g[i].vertex=i;
        g[i].instack=1;
        g[i].firstedge=NULL;
    }
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            int num;
            cin>>num;
            if(num==0) continue;
            else{
                arcnode*temp=new arcnode;
                temp->data=j;
                temp->next=NULL;
                arcnode *po=g[i].firstedge;
            while(1)
            {
                if(po==NULL)break;
                else if(po->next==NULL)break;
                else {po=po->next;}
            }
            if(po==NULL)
            {
                g[i].firstedge=temp;
            }
            else{po->next=temp;}
            g[j].in++;
            }
        }
    }
    toposort(nodenum);
    return 0;
}


