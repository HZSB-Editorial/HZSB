#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <iostream>
#include<string>
#include<iomanip>
using namespace std;
typedef struct Node {
	int no;
	string name;
	int classno;
	int score;
	struct Node* pno;
	struct Node* pclass;
	struct Node* pscore;
}Node;

void create(Node* &l, int no, const string& name, int classno, int score) {
	Node* p = l;
	Node* q = new Node();
	q->pclass = NULL;
	q->pno = NULL;
	q->pscore = NULL;
	q->no = no;
	q->name = name;
	q->classno = classno;
	q->score = score;

	q->pno = p->pno;
	p->pno = q;

	q->pclass = p->pclass;
	p->pclass = q;

	q->pscore = p->pscore;
	p->pscore = q;
}
void output_pno(Node* l) {
	Node* p = l->pno;
	while (p != NULL) {
		cout<< setw(5) << setfill('0')<<p->no<<" "<<p->name<<" "<<p->classno<<" "<<p->score<<endl;
		p = p->pno;
	}
}

void Sort_pno(Node* &L) {
		int i, count = 0, num;
		Node* p, * q, * tail;
		p = L;
		while (p->pno != NULL)
		{
			count++;
			p = p->pno;
		}
		for (i = 0; i < count - 1; i++)
		{
			num = count - i - 1;
			q = L->pno;
			p = q->pno;
			tail = L;
			while (num--)
			{
				if (q->no > p->no)
				{
					q->pno = p->pno;
					p->pno = q;
					tail->pno = p;
				}
				tail = tail->pno;
				q = tail->pno;
				p = q->pno;
			}
		}
}
void output_classno(Node* l) {
	Node* p = l->pclass;
	while (p != NULL) {
		cout << setw(5) << setfill('0')<<p->no << " " << p->name << " " << p->classno << " " << p->score << endl;
		p = p->pclass;
	}
}
void Sort_classno(Node* &L) {
	int i, count = 0, num;
	Node* p, * q, * tail;
	p = L;
	while (p->pclass != NULL)
	{
		count++;
		p = p->pclass;
	}
	for (i = 0; i < count - 1; i++)
	{
		num = count - i - 1;
		q = L->pclass;
		p = q->pclass;
		tail = L;
		while (num--)
		{
			if (q->classno > p->classno)
			{
				q->pclass = p->pclass;
				p->pclass = q;
				tail->pclass = p;
			}
			else if (q->classno == p->classno&&q->no>p->no)
			{
				q->pclass = p->pclass;
				p->pclass = q;
				tail->pclass = p;
			}
			tail = tail->pclass;
			q = tail->pclass;
			p = q->pclass;
		}
	}

}
void output_score(Node* l) {
	Node* p = l->pscore;
	while (p != NULL) {
		cout << setw(5) << setfill('0')<< p->no << " " << p->name << " " << p->classno << " " << p->score << endl;
		p = p->pscore;
	}

}
void Sort_score(Node* &L) {
	int i, count = 0, num;
	Node* p, * q, * tail;
	p = L;
	while (p->pscore != NULL)
	{
		count++;
		p = p->pscore;
	}
	for (i = 0; i < count - 1; i++)
	{
		num = count - i - 1;
		q = L->pscore;
		p = q->pscore;
		tail = L;
		while (num--)
		{
			if (q->score > p->score)
			{
				q->pscore = p->pscore;
				p->pscore = q;
				tail->pscore = p;
			}
			else if (q->score == p->score && q->no > p->no)
			{
				q->pscore = p->pscore;
				p->pscore = q;
				tail->pscore = p;
			}
			tail = tail->pscore;
			q = tail->pscore;
			p = q->pscore;
		}
	}

}

void Delete(Node* &l, int no) {
	Node* pre = l;
	Node* p = l->pno;
	while (p != NULL) {
		if (p->no == no)
		{
			pre->pno = p->pno;
		}
		pre = pre->pno;
		p = p->pno;
	}
	pre = l;
    p = l->pclass;
	while (p!= NULL) {
		if (p->no == no)
		{
			pre->pclass = p->pclass;
		}
		pre = pre->pclass;
		p = p->pclass;
	}
	pre = l;
	p = l->pscore;
	while (p != NULL) {
		if (p->no == no)
		{
			pre->pscore = p->pscore;
		}
		pre = pre->pscore;
		p = p->pscore;
	}
}
void findclassno(Node*& l,int classno)
{
	Sort_score(l);
	Node* p = l->pscore;
	while (p != NULL) {
		if (p->classno == classno) {
			cout << setw(5) << setfill('0')<<p->no << " " << p->name << " " << p->classno << " " << p->score << endl;
		}
		p = p->pscore;
	}

}
void findscore(Node*& l, int score)
{
	Sort_classno(l);
	Node* p = l->pclass;
	while (p != NULL) {
		if (p->score == score) {
			cout << setw(5) << setfill('0')<<p->no << " " << p->name << " " << p->classno << " " << p->score << endl;
		}
		p = p->pclass;
	}

}
void update_score(Node*& l, int no,int score)
{
	Node* p = l->pno;
	while (p != NULL) {
		if (p->no == no)
		{
			p->score = score;
			break;
		}
		p = p->pno;
	}
}
void update_name(Node*& l, int no, string name)
{
	Node* p = l->pno;
	while (p != NULL) {
		if (p->no == no)
		{
			p->name = name;
			break;
		}
		p = p->pno;
	}
}
int main() {
	int select; int no; string name; int classno; int score;
	Node* l = new Node;
	l->pclass = NULL;
	l->pno = NULL;
	l->pscore = NULL;
	l->pno = NULL;
	while (1) {
		cin >> select;
		switch (select)
		{
		case 0:
			exit(0);
		case 1:
			cin>>no>>name>>classno>>score;
			create(l, no, name, classno, score);
			break;
		case 2:
			Sort_pno(l);
			output_pno(l);
			break;
		case 3:
			Sort_classno(l);
			output_classno(l);
			break;
		case 4:
			Sort_score(l);
			output_score(l);
			break;
		case 5:
			cin >> no;
			Delete(l, no);
			break;
		case 6:
			cin >> no >> score;
			update_score(l, no, score);
			break;
		case 7:
			cin >> no >> name;
			update_name(l,no,name);
			break;
		case 8:
			cin >> score;
			findscore(l,score);
			break;
		case 9:
			cin >> classno;
			findclassno(l,classno);
			break;
		case 10:
			exit(0);

		}		
	}

	return 0;
}



