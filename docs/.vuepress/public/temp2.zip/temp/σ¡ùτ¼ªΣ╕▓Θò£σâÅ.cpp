#include <stdio.h>
#include <stdlib.h>
#define Stack_Size 100000

typedef struct
{
	char elem[Stack_Size];
	int top;
	int base;
}SeqStack;
void InitStack(SeqStack *S)
{
	S->top=-1;
	S->base=0;
}
int push(SeqStack *s,char x)
{
    if(s->top==Stack_Size-1)
        return 0;
    else
	{
	    s->top++;
	    s->elem[s->top]=x;
	    return 0;
	}
}
int pop(SeqStack *s,char *e)
{
    if(s->top==Stack_Size-1)
        return 0;
    else
	{
	    *e=s->elem[s->top];
	    s->top--;
	    return 0;
	}
}
int main()
{
    SeqStack s;
	InitStack(&s);
	char ch,n,e=0;
	while(n!='&')
	{
	    scanf("%c",&n);
	    if(n=='&')
            break;
 		push(&s,n);
	}
	int c=s.top+1;
	do{
        ch=getchar();
        pop(&s,&e);
        if(ch!=e)
        {
            printf("no");
            exit(0);
        }
	}while(ch!='@'&&s.top>=0);
	ch=getchar();
	if(ch=='@'&&s.top==-1)
        printf("%d",c);
    return 0;
}



