#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char a[105];
char b[105];
char next[105];
int h1, h2;

void get_Next()
{
        int i;
        int h = strlen(a);
        next[0] = -1;
        int j = -1;
        for(i = 1; i < h; i++)
        {
            while(j != -1 && a[i] != a[j+1])
            {
                j = next[j];
            }
            if(a[i] == a[j+1])
            {
                j++;
            }
            if(j == -1 || a[i+1] != a[j+1])
            {
                next[i] = j;
            }
            else
            {
                next[i] = next[j];
            }

        }
}

int KMP()
{
    int i;
    int j = -1;
    get_Next();
    for(i = 0; i < h2; i++)
    {
        while(j != -1 && b[i] != a[j+1])
        {
            j = next[j];
        }
        if(b[i] == a[j+1])
        {
            j++;
        }
        if(j == h1-1)
        {
            return i+1-h1;
        }
    }
    return -1;

}

int main()
{
    int  i, j, x;
        scanf("%s %s", b, a);
        h1 = strlen(a);
        h2 = strlen(b);
        x = KMP();
        printf("%d\n", x+1);

    return 0;
}



