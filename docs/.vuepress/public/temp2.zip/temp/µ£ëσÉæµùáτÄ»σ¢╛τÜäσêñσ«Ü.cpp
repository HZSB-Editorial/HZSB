#include <iostream>
#include <vector>
#include <queue>
using namespace std;

const int N = 5005; // 结点数的最大值
vector<int> adj[N]; // 邻接表存储图
int vis[N]; // 访问标记数组，0表示未访问，1表示正在访问，2表示已访问
int indeg[N]; // 入度数组，表示每个结点的入边数
bool hasCycle; // 是否有环的标志

// 深度优先搜索函数，参数u表示当前结点
void dfs(int u) {
    vis[u] = 1; // 标记当前结点正在访问
    for (vector<int>::iterator it = adj[u].begin(); it != adj[u].end(); it++) { // 遍历当前结点的所有邻居
        int v = *it; // 取出邻居结点
        if (vis[v] == 0) { // 如果邻居未访问，递归访问它
            dfs(v);
        } else if (vis[v] == 1) { // 如果邻居正在访问，说明有环
            hasCycle = true;
            return;
        }
    }
    vis[u] = 2; // 标记当前结点已访问
}

// 拓扑排序函数，参数n表示结点数
void topo(int n) {
    queue<int> q; // 定义一个队列，存储入度为0的结点
    for (int i = 1; i <= n; i++) { // 遍历所有结点
        if (indeg[i] == 0) { // 如果入度为0，加入队列
            q.push(i);
        }
    }
    int cnt = 0; // 记录已经访问的结点数
    while (!q.empty()) { // 当队列不为空时，循环执行以下操作
        int u = q.front(); // 取出队首元素
        q.pop(); // 弹出队首元素
        cnt++; // 增加已访问的结点数
        for (vector<int>::iterator it = adj[u].begin(); it != adj[u].end(); it++) { // 遍历当前结点的所有邻居
            int v = *it; // 取出邻居结点
            indeg[v]--; // 减少邻居的入度
            if (indeg[v] == 0) { // 如果邻居的入度变为0，加入队列
                q.push(v);
            }
        }
    }
    if (cnt == n) { // 如果已访问的结点数等于总结点数，说明没有环
        cout << "DAG" << endl;
    } else { // 否则，说明有环
        cout << "not DAG" << endl;
    }
}

int main() {
    int n, m; // 结点数和边数
    cin >> n >> m;
    for (int i = 0; i < m; i++) { // 读入边
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v); // 添加一条有向边(u,v)
        indeg[v]++; // 增加v的入度
    }
    hasCycle = false; // 初始化没有环
    for (int i = 1; i <= n; i++) { // 遍历所有结点
        if (vis[i] == 0) { // 如果未访问，从该结点开始深度优先搜索
            dfs(i);
            if (hasCycle) break; // 如果发现有环，提前结束
        }
    }
    if (hasCycle) { // 根据是否有环输出结果
        cout << "not DAG" << endl;
    } else {
        cout << "DAG" << endl;
    }
    topo(n); // 调用拓扑排序函数，再次判断是否有环
    return 0;
}

