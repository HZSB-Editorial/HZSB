#include <iostream>
using namespace std;
typedef struct node
{

    int data;
    struct node *next;
}Node,*LinkList;

void Create(LinkList &head)
{
    int n;
    Node *r;
    head=new Node();
    head->next=NULL;
    r=head;
    Node *p;
    while(1)
    {
        cin>>n;if(n==0)break;
        p=new Node();
        p->data=n;
        p->next=NULL;
        r->next=p;
        r=p;
    }
}
void show(LinkList head)
{
    while(head->next!=NULL)
    {
        cout<<head->next->data<<" ";
        head=head->next;
    }
}
void change(LinkList head)
{ 
    node *head2,*p1=head->next,*p2=head->next->next;
    if(p2==NULL||p2->next==NULL){show(head);return;}
    while(p2!=NULL&&p2->next!=NULL)
    {
        p1=p1->next;
        p2=p2->next->next;
    }
    head2=p1->next;
    p1->next=NULL;
    p2=head2->next;
    if(p2!=NULL)
        p1=p2->next;
    else p1=NULL;
    head2->next=NULL;
    while(p2!=NULL)
    {
        p2->next=head2;
        head2=p2;
        p2=p1;if(p2==NULL)break;
        p1=p1->next;
    }
    p1=head->next;
    p2=head2->next;
    while(head2!=NULL)
    {
        head2->next=p1->next;
        p1->next=head2;
        p1=head2->next;
        head2=p2;
        if(p2!=NULL)p2=p2->next;
    }
        show(head);
}
int main()
{
    LinkList head;
    Create(head);
    change(head);
    return 0;
}


