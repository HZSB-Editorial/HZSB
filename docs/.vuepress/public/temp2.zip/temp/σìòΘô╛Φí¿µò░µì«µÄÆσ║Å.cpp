#include<iostream>
using namespace std;
const int MAXN = 100;
int arr[MAXN]; 

int main() {
    int n = 0;
    cin >> arr[n];
    while (arr[n] != 0) 
    {
        ++n;
        cin >> arr[n];
    }
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; ++j) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
    for (int i = 0; i < n; ++i) 
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}

