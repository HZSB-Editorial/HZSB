#include <iostream>
using namespace std;

// 定义边的结构体
struct ArcNode {
  int adjvex; // 邻接点的编号
  ArcNode *nextarc; // 指向下一条边的指针
};

// 定义顶点的结构体
struct VertexNode {
  char data; // 顶点的数据
  ArcNode *firstarc; // 指向第一条边的指针
};

// 定义邻接表的结构体
struct AdjList {
  VertexNode vertex[1000]; // 顶点数组
  int vexnum, arcnum; // 顶点数和边数
};

// 定义图的结构体
struct Graph {
  AdjList adj; // 邻接表
  int visited[1000]; // 访问标记数组
};

// 创建图的函数，根据输入初始化图的结构
void create(Graph *g) {
  cin >> g->adj.vexnum >> g->adj.arcnum; // 输入顶点数和边数
  for (int i = 1; i <= g->adj.vexnum; i++) {
    g->adj.vertex[i].firstarc = NULL; // 初始化每个顶点的邻接表为空
    g->visited[i] = 0; // 初始化每个顶点的访问标记为0
  }
  for (int k = 0; k < g->adj.arcnum; k++) {
    int i, j; // 边的起点和终点编号
    cin >> i >> j; // 输入边的信息
    ArcNode *e = new ArcNode; // 创建一个新的边对象
    e->adjvex = j; // 设置邻接点编号为j
    e->nextarc = g->adj.vertex[i].firstarc; // 将该边插入到i的邻接表头部
    g->adj.vertex[i].firstarc = e; // 更新i的第一条边为e
    ArcNode *q = new ArcNode; // 创建一个新的边对象
    q->adjvex = i; // 设置邻接点编号为i
    q->nextarc = g->adj.vertex[j].firstarc; // 将该边插入到j的邻接表头部
    g->adj.vertex[j].firstarc = q; // 更新j的第一条边为q
  }
}

// DFS函数，以v为起点进行深度优先遍历
void DFS(Graph *g, int v) {
  g->visited[v] = 1; // 将v标记为已访问
  ArcNode *p = g->adj.vertex[v].firstarc; // 获取v的第一条边
  while (p) { // 当边不为空时，循环以下操作
    int j = p->adjvex; // 获取邻接点的编号
    if (g->visited[j] == 0) { // 如果邻接点未访问过
      DFS(g, j); // 递归调用DFS函数，以邻接点为起点继续遍历
    }
    p = p->nextarc; // 获取下一条边
  }
}

// 求连通分量数的函数，遍历所有顶点并调用DFS函数
int count(Graph *g) {
  int c = 0; // 连通分量数，初始为0
  for (int i = 1; i <= g->adj.vexnum; i++) { // 遍历所有顶点
    if (g->visited[i] == 0) { // 如果顶点未访问过
      c++; // 连通分量数加一
      DFS(g, i); // 调用DFS函数，以该顶点为起点进行遍历
    }
  }
  return c; // 返回连通分量数
}

int main() {
  Graph g; // 创建一个图对象
  create(&g); // 调用create函数，初始化图的结构
  cout << count(&g) << endl; // 调用count函数，输出连通分量数
  return 0;
}

