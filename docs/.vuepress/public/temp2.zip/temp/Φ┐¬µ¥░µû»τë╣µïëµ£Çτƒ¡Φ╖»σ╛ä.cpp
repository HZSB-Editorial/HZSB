#include<iostream>
#define N 50
#define MAX 9999
using namespace std;

int nodenum;
int num;
int r[N][N];
int lowpath[N];
int before[N];
bool tag[N];

void dijikstra()
{
    int i;
    for(i=0;i<nodenum;i++)
    {
        lowpath[i]=r[num][i];
        if(i==num)
        {
            before[i]=-1;
            tag[i]=false;
        }
        else{
            before[i]=num;
            tag[i]=true;
        }
    }
    int cnt=nodenum-1;
    while(cnt--)
    {
        int minw=MAX;
        int id=0;
        for(i=0;i<nodenum;i++)
        {
            if(lowpath[i]<minw &&tag[i]==true)
            {
                minw=lowpath[i];
                id=i;
            }
        }
        tag[id]=false;
        for(i=0;i<nodenum;i++)
        {
            if(i==id || i==num)continue;
            else if(r[id][i]+lowpath[id]<lowpath[i])
            {
                lowpath[i]=r[id][i]+lowpath[id];
                before[i]=id;
            }
        }
    }
    for(i=0;i<nodenum;i++)
    {
        if(i==num)continue;
        else if(lowpath[i]==MAX) cout<<-1<<" ";
        else cout<<lowpath[i]<<" ";
    }
}

int main()
{
    cin>>nodenum>>num;
    int i,j;
    for(i=0;i<nodenum;i++)
    {
        for(j=0;j<nodenum;j++)
        {
            int n;
            cin>>n;
            if(n==0)
                r[i][j]=MAX;
            else
                r[i][j]=n;
        }
    }
    dijikstra();
    return 0;
}


