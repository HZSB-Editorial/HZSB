#include <iostream>
using namespace std;

//交换函数
void Swap(int* pa, int* pb) {
    int tmp = *pa;
    *pa = *pb;
    *pb = tmp;
}

//冒泡排序
void BubbleSort(int* a, int n) {
    for (int j = 0; j < n; ++j) {
        //单趟
        for (int i = 1; i < n - j; ++i) {
            //前一个数大于后一个数，就交换
            if (a[i - 1] > a[i]) {
                Swap(&a[i - 1], &a[i]);
            }
        }
    }
}

//选择排序
void SelectSort(int* a, int n) {
    for (int i = 0; i < n - 1; ++i) {
        //找最小值的下标
        int minIndex = i;
        for (int j = i + 1; j < n; ++j) {
            if (a[j] < a[minIndex]) {
                minIndex = j;
            }
        }
        //交换最小值和当前位置的值
        Swap(&a[i], &a[minIndex]);
    }
}

//快速排序
void QuickSort(int* a, int left, int right) {
    if (left >= right) {
        return;
    }
    //选基准值
    int key = a[left];
    //定义左右指针
    int i = left;
    int j = right;
    while (i < j) {
        //右指针向左移动，找到第一个小于基准值的元素
        while (i < j && a[j] >= key) {
            --j;
        }
        //左指针向右移动，找到第一个大于基准值的元素
        while (i < j && a[i] <= key) {
            ++i;
        }
        //交换左右指针所指的元素
        Swap(&a[i], &a[j]);
    }
    //交换基准值和左指针所指的元素
    Swap(&a[left], &a[i]);
    //递归对左右子区间进行快速排序
    QuickSort(a, left, i - 1);
    QuickSort(a, i + 1, right);
}

//打印数组中的所有元素
void Print(int* a, int n) {
    for (int i = 0; i < n; ++i) {
        cout << a[i] << " ";
    }
    cout << endl;
}

//主函数
int main() {
    //定义一个动态数组，用来存储输入的数据
    int* arr = new int[100];
    //定义一个变量，用来记录输入的数据个数
    int count = 0;

    //输入一组数据，以0作为输入的结束

    while (1) {
        //定义一个临时变量，用来接收输入的数据
        int temp;
        cin >> temp;

        //如果输入的是0，则结束输入循环
        if (temp == 0) {
            break;
        }

        //否则将输入的数据存入动态数组，并更新数据个数
        arr[count++] = temp;

        //如果数据个数超过了动态数组的容量，则扩容一倍，并复制原有数据
        if (count == sizeof(arr)) {
            int* newArr = new int[count * 2];
            for (int i = 0; i < count; ++i) {
                newArr[i] = arr[i];
            }
            delete[] arr;
            arr = newArr;
        }

    }
    
    //使用冒泡排序对数据进行从小到大的排序，并输出排序后的结果
    BubbleSort(arr, count);
    Print(arr, count);

    //使用选择排序对数据进行从小到大的排序，并输出排序后的结果
    SelectSort(arr, count);
    Print(arr, count);

    //使用快速排序对数据进行从小到大的排序，并输出排序后的结果
    QuickSort(arr, 0, count - 1);
    Print(arr, count);

    //释放动态数组的内存空间
    delete[] arr;

    return 0;
}

