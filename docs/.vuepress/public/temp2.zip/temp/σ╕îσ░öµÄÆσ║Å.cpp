#include<iostream>
using namespace std;

void ShellSort(int a[], int ick, int limit)
{
    int i, j;
    for(i = ick; i < limit; i ++)
    {
        int temp = a[i];
        for(j = i - ick; j >= 0 && temp < a[j]; j -= ick)
        {
            a[j + ick] = a[j];
        }
        a[j + ick] = temp;
    }
    for(i = 0; i < limit; i ++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
int main()
{
    int a[50];
    int cnt = 0;
    for(cnt = 0; ;cnt ++)
    {
        cin>>a[cnt];
        if(a[cnt] == 0) break;
    }
    int ick[10];
    int i = 0;
    while(cin>>ick[i])
    {
        i ++;
    }
    int j = 0;
    while(1)
    {
        ShellSort(a, ick[j], cnt); 
        j ++;
        if(j == i) break;
    }
    return 0;
}

