#include <stdio.h>

#define MAXSIZE 100

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    int arr[MAXSIZE];
    int n = 0;
    while (scanf("%d", &arr[n]), arr[n] != 0) {
        n++;
    }

    int left = 0, right = n - 1;

    while (left < right) {
        while (arr[left] % 2 == 1 && left < right) {
            left++;
        }
        while (arr[right] % 2 == 0 && left < right) {
            right--;
        }
        swap(&arr[left], &arr[right]);
    }
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }

    return 0;
}



