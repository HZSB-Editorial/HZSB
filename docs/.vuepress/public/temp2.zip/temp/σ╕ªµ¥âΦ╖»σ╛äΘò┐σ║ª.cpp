#include <iostream>
using namespace std;
typedef struct
{
int weight, lChild, rChild, parent; 
}HTNode, *HuffmanTree;

void select(int& s1, int& s2, int n, HuffmanTree HT);


int main()
{
int n;
cin >> n;
HuffmanTree HT= new HTNode[20];
for (int i = 1; i <= 2 * n - 1; i++)
{
HT[i].lChild = 0;
HT[i].rChild = 0;
HT[i].parent = 0;
}
for (int i = 1; i <= n; i++)
{
cin>>HT[i].weight;
}
for (int i = n + 1; i <= 2 * n - 1; i++)
{
int s1, s2;
select(s1, s2, i-1, HT);
HT[i].weight = HT[s1].weight + HT[s2].weight;
HT[s1].parent = i;
HT[s2].parent = i;
}
int sum = 0;
for (int i = 1; i <= n; i++)
{
int f = i;
int counter = 0;
while (HT[f].parent != 0)
{
f = HT[f].parent;
counter++;
}
sum = sum + HT[i].weight * counter;
}
cout << sum;
}
void select(int& s1, int& s2, int n, HuffmanTree HT) 
{
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0)
{
s1 = i;
break;
}
}
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0 && HT[i].weight <= HT[s1].weight)
{
s1 = i;
}
}
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0 && i != s1)
{
s2 = i;
break;
}
}
for (int i = 1; i <= n; i++)
{
if (HT[i].parent == 0 && i != s1 && HT[i].weight <= HT[s2].weight)
{
s2 = i;
}
}
}

