#include <iostream>
using namespace std;

const int N = 10; // 数组大小

// 冒泡排序函数，参数a表示数组，参数n表示数组大小
void bubbleSort(int a[], int n) {
    for (int i = 0; i < n - 1; i++) { // 外层循环控制排序的趟数
        for (int j = 0; j < n - 1 - i; j++) { // 内层循环控制每趟比较的次数
            if (a[j] > a[j + 1]) { // 如果相邻两个元素逆序，交换它们
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
}

// 非递归二分查找函数，参数a表示数组，参数n表示数组大小，参数x表示要查找的数
bool binarySearch(int a[], int n, int x) {
    int left = 0; // 定义左边界
    int right = n - 1; // 定义右边界
    while (left <= right) { // 当左边界小于等于右边界时，循环执行以下操作
        int mid = (left + right) / 2; // 计算中间位置
        if (a[mid] == x) { // 如果中间位置的元素等于要查找的数，返回true
            return true;
        } else if (a[mid] < x) { // 如果中间位置的元素小于要查找的数，更新左边界为mid+1
            left = mid + 1;
        } else { // 如果中间位置的元素大于要查找的数，更新右边界为mid-1
            right = mid - 1;
        }
    }
    return false; // 如果循环结束还没有找到，返回false
}

// 递归二分查找函数，参数a表示数组，参数left表示左边界，参数right表示右边界，参数x表示要查找的数
bool binarySearch(int a[], int left, int right, int x) {
    if (left > right) { // 如果左边界大于右边界，返回false
        return false;
    }
    int mid = (left + right) / 2; // 计算中间位置
    if (a[mid] == x) { // 如果中间位置的元素等于要查找的数，返回true
        return true;
    } else if (a[mid] < x) { // 如果中间位置的元素小于要查找的数，递归在右半部分查找
        return binarySearch(a, mid + 1, right, x);
    } else { // 如果中间位置的元素大于要查找的数，递归在左半部分查找
        return binarySearch(a, left, mid - 1, x);
    }
}

int main() {
    int a[N]; // 定义数组
    for (int i = 0; i < N; i++) { // 输入数组元素
        cin >> a[i];
    }
    bubbleSort(a, N); // 调用冒泡排序函数，对数组进行排序
    int n; // 定义要查找的数
    cin >> n; // 输入要查找的数
    if (binarySearch(a, N, n)) { // 调用非递归二分查找函数，判断是否存在
        cout << "yes" << endl; // 如果存在，输出yes
    } else {
        cout << "no" << endl; // 如果不存在，输出no
    }
    if (binarySearch(a, 0, N - 1, n)) { // 调用递归二分查找函数，判断是否存在
        cout << "yes" << endl; // 如果存在，输出yes
    } else {
        cout << "no" << endl; // 如果不存在，输出no
    }
    return 0;
}

