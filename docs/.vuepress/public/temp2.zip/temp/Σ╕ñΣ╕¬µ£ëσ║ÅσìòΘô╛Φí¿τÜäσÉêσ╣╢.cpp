#include <iostream>
using namespace std;

struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(NULL) {}
};

ListNode* mergeTwoLists(ListNode* l1, ListNode* l2) {
    ListNode* dummy = new ListNode(-1);
    ListNode* cur = dummy;
    while (l1 != NULL && l2 != NULL) {
        if (l1->val < l2->val) {
            cur->next = l1;
            l1 = l1->next;
        } else if (l1->val > l2->val) {
            cur->next = l2;
            l2 = l2->next;
        } else {
            cur->next = l1;
            l1 = l1->next;
            ListNode* temp = l2;
            l2 = l2->next;
            delete temp;
        }
        cur = cur->next;
    }
    cur->next = l1 != NULL ? l1 : l2;
    ListNode* res = dummy->next;
    delete dummy;
    return res;
}

int main() {
    ListNode* LA = NULL;
    ListNode* LB = NULL;

    int x;
    cin >> x;
    if (x == 0) {
        cout << "LA is empty" << endl;
        return 0;
    }
    LA = new ListNode(x);
    ListNode* cur = LA;
    while (cin >> x && x != 0) {
        cur->next = new ListNode(x);
        cur = cur->next;
    }

    cin >> x;
    if (x == 0) {
        cout << "LB is empty" << endl;
        return 0;
    }
    LB = new ListNode(x);
    cur = LB;
    while (cin >> x && x != 0) {
        cur->next = new ListNode(x);
        cur = cur->next;
    }

    LA = mergeTwoLists(LA, LB);

    cur = LA;
    while (cur != NULL && cur->next != NULL) {
        if (cur->val == cur->next->val) {
            ListNode* temp = cur->next;
            cur->next = cur->next->next;
            delete temp;
        } else {
            cur = cur->next;
        }
    }

    cur = LA;
    while (cur != NULL) {
        cout << cur->val << " ";
        ListNode* temp = cur;
        cur = cur->next;
        delete temp;
    }
    cout << endl;

    return 0;
}

