#include<iostream>
using namespace std;
struct node{
    char data;
    node *next;
};
class stack{
    private:
        node *top;
    public:
        stack(){
            top=NULL;
        }
        void push(char x){
            node *p=new node;
            p->data=x;
            p->next=top;
            top=p;
        }
        char pop(){
            if(top==NULL){
                return -1;
            }
            node *p=top;
            top=top->next;
            char x=p->data;
            delete p;
            return x;
        }
        bool empty(){
            if(top==NULL){
                return true;
            }
            else{
                return false;
            }
        }
        char gettop(){
            if(top==NULL){
                return -1;
            }
            else{
                return top->data;
            }
        }
};
int main(){
    stack s;
    char c;
    while(cin>>c){
        if(c=='#'){
            break;
        }
        if(c=='('||c=='['||c=='{'){
            s.push(c);
        }
        else if(c==')'){
            if(s.gettop()=='('){
                s.pop();
            }
            else{
                cout<<0<<endl;
                return 0;
            }
        }
        else if(c==']'){
            if(s.gettop()=='['){
                s.pop();
            }
            else{
                cout<<0<<endl;
                return 0;
            }
        }
        else if(c=='}'){
            if(s.gettop()=='{'){
                s.pop();
            }
            else{
                cout<<0<<endl;
                return 0;
            }
        }
    }
    if(s.empty()){
        cout<<1<<endl;
    }
    else{
        cout<<0<<endl;
    }
    return 0;
}

