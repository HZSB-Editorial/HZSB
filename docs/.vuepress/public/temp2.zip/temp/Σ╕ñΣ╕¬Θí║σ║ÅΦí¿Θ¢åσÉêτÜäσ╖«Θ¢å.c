#include<stdio.h>
#define Maxsize 200
#define Elemtype int
typedef struct{
    Elemtype elem[Maxsize];
    int last;
}SeqList;

void InitList(SeqList * L){
    L->last = -1; 
}

void Input(SeqList * L){
    int i = -1;
    while(1){
        Elemtype num;
        scanf("%d",&num);
        if(num != 0){
            i++;
            L->elem[i] = num;
            L->last++;
        }
        else break;
    }
}

void Output(SeqList * L){
    int i;
    for(i = 0; i <= L->last; i++){ 
        printf("%d ",L->elem[i]);
    }
    printf("\n");
}

void Difset(SeqList * La,SeqList * Lb,SeqList * Lc){
    int i,j,k;
    k = -1;
    for(i = 0; i <= La->last; i++){
        int flag = 0;
        for(j = 0; j <= Lb->last; j++){
            if(La->elem[i] == Lb->elem[j]){
                flag = 1;
                break;
            }
            if(La->elem[i] != Lb->elem[j]){
                continue;
            }
        }
        if(!flag){
            k++;
            Lc->elem[k] = La->elem[i];
            Lc->last++;
        }
    }
}
int main(){
    SeqList La,Lb,Lc;
    InitList(&La);
    InitList(&Lb);
    InitList(&Lc);
    Input(&La);
    Input(&Lb);
    Difset(&La,&Lb,&Lc);
    Output(&Lc);
    return 0;
}

