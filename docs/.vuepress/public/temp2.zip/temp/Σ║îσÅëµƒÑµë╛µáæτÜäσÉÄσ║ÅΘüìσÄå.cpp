#include <iostream>
#include <vector>
using namespace std;

// 判断一个数组是否是二叉查找树的后序遍历的结果的函数，参数a表示数组，参数left表示左边界，参数right表示右边界
bool isPostOrder(vector<int> &a, int left, int right) {
    if (left >= right) return true; // 如果左边界大于等于右边界，说明只有一个或没有元素，返回true
    int root = a[right]; // 取最后一个元素作为根结点
    int i = left; // 从左边界开始遍历
    while (i < right && a[i] < root) i++; // 找到第一个大于等于根结点的元素的位置
    for (int j = i; j < right; j++) { // 遍历剩余的元素
        if (a[j] < root) return false; // 如果有小于根结点的元素，说明不是二叉查找树的后序遍历，返回false
    }
    return isPostOrder(a, left, i - 1) && isPostOrder(a, i, right - 1); // 递归判断左右子树是否满足条件
}

int main() {
    vector<int> a; // 定义数组
    int x; // 定义输入的元素
    while (cin >> x) { // 输入任意长度的数组，数字之间空格分开
        a.push_back(x); // 将元素加入数组
    }
    if (isPostOrder(a, 0, a.size() - 1)) { // 调用判断函数，传入数组和左右边界
        cout << "true" << endl; // 如果返回true，输出true
    } else {
        cout << "false" << endl; // 如果返回false，输出false
    }
    return 0;
}

