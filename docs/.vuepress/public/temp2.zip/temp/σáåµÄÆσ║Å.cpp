#include<iostream>
using namespace std;
int a[30];
int last=0;

void change(int pos,int edge=last)
{
    while(1)
    {
        if(2*pos+2<=edge)
        {
            if(a[pos]>a[pos*2+1]&&a[pos]>a[pos*2+2])
                break;
            if(a[pos*2+1]<a[pos*2+2])
            {
                swap(a[pos],a[pos*2+2]);
                pos=pos*2+2;
                continue;
            }
            else{
                swap(a[pos],a[pos*2+1]);
                pos=pos*2+1;
                continue;
            }
        }
        else if(2*pos+1<=edge)
        {
            if(a[pos]<a[pos*2+1])
            {
                swap(a[pos],a[pos*2+1]);
                pos=pos*2+1;
                continue;
            }
        }
        if(2*pos+2>edge) break;
    }
}

void heapsort()
{
    int i=0;
    for(i=(last-1)/2;i>=0;i--)
    {
        if(i*2+2<=last)
        {
            if(a[i]<a[i*2+1]||a[i]<a[i*2+2])
            {
                if(a[i*2+1]<a[i*2+2])
                {
                    swap(a[i],a[i*2+2]);
                    change(i*2+2);
                }
                else{
                    swap(a[i],a[i*2+1]);
                    change(i*2+1);
                }
            }
        }
        else if(i*2+1<=last)
        {
            if(a[i]<a[i*2+1])
            {
                swap(a[i],a[i*2+1]);
                change(i*2+1);
            }
        }
    }
    for(i=0;i<=last;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;

    for(i=last;i>0;i--)
    {
        swap(a[i],a[0]);
        change(0,i-1);
        int j;
        for(j=0;j<=last;j++)
        {
            cout<<a[j]<<" ";
        }
        cout<<endl;
    }
}

int main()
{
    int i=0;
    for(i=0;;i++)
    {
        cin>>a[i];
        if(a[i]==0)
            break;
    }
    last=i-1;
    heapsort();
    return 0;
}

