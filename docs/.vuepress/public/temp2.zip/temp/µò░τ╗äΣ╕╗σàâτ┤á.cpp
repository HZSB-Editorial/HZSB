#include<bits/stdc++.h>
using namespace std;

int main()
{
	int a[100],m,len=0,main=-1,count=0;
	while(1)
	{
		cin>>m;
		if(m==0)break;
		a[len]=m;
		len++;
	}
	for(int i=0;i<len;i++)
	{
		if(count==0){
			main=a[i];
			count=1;
		}
		else if(a[i]==main)
		{
		    count++;
		}
		else
		{
		     count--;
		}
    }
		count=0;
		for(int i=0;i<len;i++)
		{
			if(a[i]==main){
				count++;
			}
		}
		if(count>len/2)
		{
		 cout<<main;
		}
		else
		cout<<"-1";
		return 0;

}
