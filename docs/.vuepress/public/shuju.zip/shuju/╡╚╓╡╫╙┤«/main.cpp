#include<bits/stdc++.h>
using namespace std;
int main(){
	string c;
	cin >> c;
	int s = 0, num = 0, stemp = 0, a = 1;
	int len = c.length();
	for(int i = 1; i < len; i++){
		if(c[i] == c[i - 1]) a++;
		else {
			if(a > num) {
				num = a;
				s = stemp;
			}
			stemp = i;
			a = 1;
		}
	}
	if(num > 1)
		for(int i = s; i < s + num; i++){
			cout << c[i];
		}
	else cout << "no";
}

