#include<stdio.h>
#include<stdlib.h>
typedef struct Node{
    int data;
    struct Node* next;
}Node,*Linklist;
void InitList(Linklist* L){
    *L = (Linklist)malloc(sizeof(Node));
    (*L)->next = NULL;
}

void CreatFromTail(Linklist L){
    Node *p,*pr;
    pr = L;
    p = NULL;
    while(1){
        int num;
        scanf("%d",&num);
        if(num == 0){
            break;
        }
        else{
            p = (Linklist)malloc(sizeof(Node));
            p->data = num;
            if(L->next == NULL){
                L->next = p;
                p->next = NULL;
                pr = pr->next;
            }
            else{
                pr->next = p;
                p->next = NULL;
                pr = pr->next;
            }
        }
    }
}

void MergeList(Linklist La,Linklist Lb,Linklist Lc){
    Linklist p,q,t;
    p = La->next;
    q = Lb->next;
    t = Lc;
    while(p != NULL && q != NULL){
        if(p->data < q->data){
            t->next = p;
            t = p;
            p = p->next;
        }
        else if(q->data == p->data){
            if(q->next != NULL){
                q = q->next;
            }
            else{
                p = p->next;
            }
        }
        else{
            t->next = q;
            t = q;
            q = q->next;
        }
    }
        if(p != NULL){
            t->next = p;
        }
        if(q != NULL){
            t->next = q;
        }
}

void Output(Linklist L){
    Linklist p;
    p = L->next;
    while(p->next != NULL){
        printf("%d ",p->data);
        p = p->next;
    }
    printf("%d",p->data);
    printf("\n");
}
int main(){
    struct Node* La = NULL;
    struct Node* Lb = NULL;
    struct Node* Lc = NULL;
    InitList(&La);
    InitList(&Lb);
    InitList(&Lc);
    CreatFromTail(La);
    CreatFromTail(Lb);
    MergeList(La,Lb,Lc);
    Output(Lc);
    return 0;
}

