#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<stdlib.h>
typedef struct tree {
	int data;
	struct tree* lchild;
	struct tree* rchild;
}T;
void insert(T** r, int key)
{
	if ((*r) == NULL)
	{
		(*r) = (T*)malloc(sizeof(T));
		(*r)->data = key;
		(*r)->lchild = NULL; (*r)->rchild = NULL;
	}
	else if (key > (*r)->data)
	{
		insert(&((*r)->rchild), key);
	}
	else if (key < (*r)->data)
	{
		insert(&((*r)->lchild), key);
	}
}
void creat_tree(T** t)
{
	int key;
	*t = NULL;
	scanf("%d", &key);
	while (key != 0)
	{
		insert(t, key);
		scanf("%d", &key);
	}
}
T* del_node(int x, T* r)
{
	T *p,*e,*k,*f;
	p = r; e = NULL;
	while (p->data != x && p != NULL)
	{
		e = p;
		if (x > p->data)
		{
			p = p->rchild;
		}
		else if (x < p->data)
		{
			p = p->lchild;
		}
	}
	if (p == NULL)
		return r;
	if (p->lchild == NULL)
	{
		if (e == NULL)
			r = p->rchild;
		else if (e->lchild == p)
			e->lchild = p->rchild;
		else if (e->rchild == p)
			e->rchild = p->rchild;
		free(p);
	}
	else
	{
		k = p->lchild; f = p;
		while (k->rchild != NULL)
		{
			f = k;
			k = k->rchild;
		}
		if (f == p)
			p->lchild = k->lchild;
		else
		{
			f->rchild = k->lchild;
		}
		p->data = k->data;
		free(k);
	}
	return r;
}
void search_ceng(T* r, int key,int i)
{
	if (r != NULL)
	{
		if (key > r->data)
			search_ceng(r->rchild, key, i + 1);
		else if (key < r->data)
			search_ceng(r->lchild, key, i + 1);
		else
		{
			printf("%d", i);
		}
	}
}
void bianli(T* r)
{
	if (r != NULL)
	{
		printf("%d ", r->data);
		bianli(r->lchild);
		bianli(r->rchild);
	}
	else
	{
		printf("# ");
		return;
	}
}
void bianli2(T* r)
{
	if (r != NULL)
	{
		bianli2(r->lchild);
		printf("%d ", r->data);
		bianli2(r->rchild);
	}
}
int main(void)
{
	T* r;
	int k,y;
	creat_tree(&r);
	scanf("%d", &k);
	scanf("%d", &y);
	bianli(r);
	r = del_node(k, r);
	printf("\n");
	bianli2(r);
	printf("\n");
	search_ceng(r, y, 1);
	return 0;
}

