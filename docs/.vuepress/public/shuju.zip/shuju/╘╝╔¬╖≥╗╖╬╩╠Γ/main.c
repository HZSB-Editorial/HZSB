#include <stdio.h>
#include <stdlib.h>
typedef struct Node
{
	int data;
	struct Node *next;
}Node,*linklist;

Node* creatlist(int n)
{

	Node *r=NULL,*s,*L;
	int count=1;
	L=(Node*)malloc(sizeof(Node));
	L->next =L;
	r=L;
	while (count<=n)
	{
		s=(Node*)malloc(sizeof(Node));
		s->next =NULL;
		s->data=count++;
		r->next =s;
		r=s;
    }
    s->next=L->next;
    free(L);
    return s->next;
}

int main()
{
	int i,m,n;
	scanf("%d",&n);
	scanf("%d",&m);
	linklist L;
	L=(Node*)malloc(sizeof(Node));
	L->next =L;
	L=creatlist(n);
    Node *p;
	m%=n;
	while (L!=L->next)
	{
		if (m>2)
		{

			for (i=1;i<m-1;i++)
			{
				L=L->next ;
			}
			p=L->next;
			L->next =p->next ;
			free(p);
			L=L->next ;
	    }
	    else if (m==2)
	    	{
	    		L=L->next ;
	    		p=L->next;
				L->next =p->next ;
				free(p);
				L=L->next ;
			}
		else
		{
			p=L->next;
			L->next =p->next ;
			free(p);
			L=L->next ;
		}
	}
	printf("%d",L->data);
	return 0;
}

