#include <iostream>
#include <string>
using namespace std;
// �������ṹ�壬ʹ��ָ��������ָ��
struct TreeNode {
    char value;
    TreeNode *left;
    TreeNode *right;
    TreeNode(char c) : value(c), left(NULL), right(NULL) {}
};
// �ݹ鴴��������
void build_tree(TreeNode *&root, string &s, int &index)
{
    if (s[index] == '.') {
        index++;
        return;
    }
    root = new TreeNode(s[index++]);  // �ȼ��� root = (TreeNode *)(malloc(sizeof(TreeNode))); root->value = s[index++];
    build_tree(root->left, s, index);
    build_tree(root->right, s, index);
}
// �ڶ������ϵݹ������ÿ���ڵ��ÿո�ֿ�
void print_tree(TreeNode *root, int depth)
{
    if (!root) {
        return;
    }
    print_tree(root->right, depth + 1);
    for (int i = 0; i < depth; i++) {
        cout << "  ";
    }
    cout << root->value << endl;
    print_tree(root->left, depth + 1);
}
int main()
{
    string s;
    cin >> s;
    TreeNode *root = NULL;
    int index = 0;
    build_tree(root, s, index);
    print_tree(root, 0);
    return 0;}

