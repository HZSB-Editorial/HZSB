#include<bits/stdc++.h>

using namespace std;

void print(int a[], int len)
{
    for( int i = 0 ;i < len ; i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
void bubblesort(int a[],int len)//��������֮����бȽϣ�ȡ����Ԫ�طŵ��ұ�
{
    int i,j,flag;
    for( i = 0 ; i < len - 1 ; i++ )
    {
        flag = 1;
        for( j = 0 ;j <len - 1 - i ; j++)
         {
             if(a[ j ]> a[ j + 1 ])
                {   flag = 0;
                    int temp = a [ j ];
                    a[ j ] = a[j + 1 ];
                    a[j + 1] = temp;
                }
         }
         if(flag == 1)
            break;
    }
    print(a,len);
}
void quicksort(int a[],int begin ,int end)
{
    if(begin>end)
        return ;
        int temp = a[ begin ];
        int i = begin;
        int j = end;
        while( i != j)
        {
            while(a[ j ] >= temp&& j > i)
                j--;
            while(a[ i ] <=temp&&j > i)
                i++;
            if(j > i )
            {
                int tmp = a[ i ];
                a[ i ] = a[ j ];
                a[ j ] = tmp;

            }
        }
        a[begin] = a[ i ];
        a[ i ] = temp;

        quicksort( a ,begin , i - 1 );
        quicksort( a, i + 1 , end  );
}
void selectsort(int a[],int len)
{
    for( int i = 0 ; i < len - 1; i++)
    {
        int Min = i;
        for( int j = i + 1 ;j < len  ; j++ )
        {
            if( a[ Min ] > a[ j ] )
            {
                Min = j;
            }
        }
        if( Min != i  )
        {
             int temp = a[ Min ];
            a[ Min ] = a[ i ] ;
            a[ i ] = temp;

        }
    }
     print(a,len);

}

int main()
{   int a[100];
    int  len = 0;
    while(1)
    {
        cin>>a[ len ];
        if(a[ len ] == 0)
            break;
        len++;
    }
    bubblesort(a,len);
    cout<<endl;
    selectsort(a,len);
    cout<<endl;
    quicksort(a ,0 ,len - 1);
    print(a,len);
}

