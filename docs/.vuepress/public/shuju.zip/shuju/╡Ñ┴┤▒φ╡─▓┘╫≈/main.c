
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<malloc.h>
typedef struct Node
{
	int data;
	struct Node* next;
}Node,*LinkList;
LinkList Init()
{
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->next = NULL;
	return newNode;
}
void CreatList(LinkList s)//��ͷ�ڵ�
{
	Node* p;
	int num;
	scanf("%d", &num);
	while (1)
	{
		if (num != 0)
		{
			p = (Node*)malloc(sizeof(Node));
			p->data = num;
			//ͷ�巨����
			p->next = s->next;
			s->next = p;
			scanf("%d", &num);
		}
		else
			break;
	}
}
void PrintList(LinkList s)
{
	Node *ptr = s->next;
	while (ptr != NULL)
	{
		printf("%d ", ptr->data);
		ptr = ptr->next;
	}
	printf("\n");
}
void DeleteList(LinkList head)
{
	//ð�ݷ�ɾ��
	Node* cur, * q, * p;
	cur = head->next;
	while (cur != NULL)
	{
		q = cur->next;
		p = cur;
		while (q != NULL)
		{
			if (cur->data == q->data)
			{
				p->next = q->next;
				q = q->next;
			}
			else
			{
				p = q;
				q = q->next;
			}
		}
		cur = cur->next;
	}
}
int main()
{
	LinkList head;
	head = Init();
	CreatList(head);
	PrintList(head);
	DeleteList(head);
	PrintList(head);
	return 0;

}

