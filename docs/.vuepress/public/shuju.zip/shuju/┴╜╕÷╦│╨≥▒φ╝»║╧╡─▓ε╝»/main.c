#include <stdio.h>
#include <stdlib.h>
#define Max 100
typedef int ElemType;
typedef struct{
      ElemType data[Max];
    int length;
}SqList;

void display(SqList *L){
    int i;
    for(i=0;i<L->length;i++)
    printf("%d ",L->data[i]);
    printf("\n");
}
void d(SqList *A, SqList *B,SqList *C){
    int i,j,k=0;
    for (i=0;i<A->length;i++)
    {
        j=0;
        while(j< B->length && B->data[j] != A->data[i])
            j++;
        if(j==B->length)
            C->data[k++]=A->data[i];
    }
    C->length=k;
}
int main()
{
    int m,j;
    int n,i;

    SqList *A = (SqList*)malloc(sizeof(SqList));
    A->length=0;
     for(i=0;;i++)
    {
        scanf("%d",&A->data[i]);
        if(A->data[i]==0)
            break;
    }
 A->length=i;



    SqList *B = (SqList*)malloc(sizeof(SqList));
    B->length=0;
      for(j=0;;j++)
    {
        scanf("%d",&B->data[j]);
        if(B->data[j]==0)
            break;
    }
   B->length=j;

    SqList *C = (SqList*)malloc(sizeof(SqList));
    C->length=0;

   d(A,B,C);
    display(C);
    return 0;
}



