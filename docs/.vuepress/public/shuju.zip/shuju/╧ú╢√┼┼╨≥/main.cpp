#include<bits/stdc++.h>

using namespace std;
int a[100],b[10];
int i , j ,k, temp ,len1, len2 , incr ;
void print()
{
    for( i = 0 ;i < len1 ; i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
void shellsort()
{
    for( k = 0 ; k <  len2 ; k++)
    {
        incr = b[ k ];

        for( i = incr  ; i < len1 ; i++ )
        {
            temp = a[ i ];
             j = i - incr ;
             while(j >= 0 && a[j]>temp  )
            {
                a[ j + incr ] = a[ j ];
                j-=incr;
            }
            a[j + incr ] = temp;
        }
         print();
    }
}

int main()
{   len1 = 0 ,len2 = 0 ;
    while(1)
    {
        cin>>a[ len1 ];
        if(a[ len1 ] == 0)
            break;
        len1++;
    }
    while(len2<3)
    {
        cin>>b[ len2 ];
        len2++;

    }
    shellsort();
}

