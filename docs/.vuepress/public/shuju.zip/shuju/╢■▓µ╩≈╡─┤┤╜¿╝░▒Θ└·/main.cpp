#include<iostream>
#include<stack>
#include<cstdlib>
#include<cstring>
using namespace std;

typedef struct Node
{
	char data;
	struct Node* LChild;
	struct Node* RChild;
}BiTNode,*BiTree;
void CreateBT(BiTree* root)
{
	char r;

	cin >> r;
	if (r != '#')
	{
		*root = new BiTNode;
		(*root)->data = r;
		CreateBT(&(*root)->LChild);
		CreateBT(&(*root)->RChild);
	}
	else
		*root = NULL;
}

void PreOrder(BiTree root)
{
	if (root != NULL)
	{
		cout << root->data << " ";
		PreOrder(root->LChild);
		PreOrder(root->RChild);
	}
	else
		return;

}

void InOrder(BiTree root)
{
	if (root == NULL)
	{
		return;
	}

	else
	{
		InOrder(root->LChild);
		cout << root->data << " ";
		InOrder(root->RChild);
	}

}

void PostOrder(BiTree root)
{
	if (root != NULL)
	{
		PostOrder(root->LChild);
		PostOrder(root->RChild);
		cout << root->data << " ";
	}
	else
		return;

}

void Pre(BiTree root)
{
	stack<BiTree>R;
	while (root != NULL)
	{
		cout << root->data << " ";
		R.push(root);
		if (root->LChild != NULL)
		{
			root = root->LChild;
		}
		else if (!R.empty())
		{
			while (!R.empty())
			{
				root = R.top();
				R.pop();
				root = root->RChild;
				if (root != NULL)
					break;
			}
		}
		else
			root = NULL;
	}
}

void Post(BiTree root)
{
	stack<BiTree>R;
	BiTree p = root;
	BiTree q = NULL;
	while (p != NULL || !R.empty())
	{
		while (p != NULL)
		{
			R.push(p);
			p = p->LChild;
		}
		BiTree r = R.top();
		if (r->RChild == NULL || r->RChild == q)
		{
			cout << r->data << " ";
			R.pop();
			q = r;
		}
		else
			p = r->RChild;
	}
}
void In(BiTree root)
{
	stack<BiTree>R;
	while (root != NULL)
	{
		R.push(root);
		if (root->LChild != NULL)
		{
			root = root->LChild;
		}
		else if (!R.empty())
		{
			while (!R.empty())
			{
				root = R.top();
				R.pop();
				cout << root->data << " ";
				root = root->RChild;
				if (root != NULL)
					break;
			}
		}
		else
			root = NULL;
	}
}
int main()
{
	BiTree root = NULL;
	CreateBT(&root);

	PreOrder(root);
	cout << endl;
	InOrder(root);
	cout << endl;
	PostOrder(root);
	cout << endl;

	Pre(root);
	cout << endl;
	In(root);
	cout << endl;
	Post(root);
	cout << endl;
	return 0;
}

