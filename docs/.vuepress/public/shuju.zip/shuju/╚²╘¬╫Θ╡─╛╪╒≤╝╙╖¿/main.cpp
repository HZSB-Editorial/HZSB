#include <iostream>
using namespace std;
struct ccc
{
    int ii, jj, data;
} flag[12500], temp[12500];
int main()
{
    int m, n;
    cin >> m >> n;
    for (int i = 0; i < m + n; i++)
        cin >> flag[i].ii >> flag[i].jj >> flag[i].data;
    for (int i = 0; i < m + n; i++)
    {
        for (int j = 0; j < m + n; j++)
            if (flag[i].ii == flag[j].ii && j != i && flag[i].jj == flag[j].jj)
            {
                flag[i].data += flag[j].data;
                flag[j].ii = flag[j].jj = flag[j].data = 0x7fffffff;
            }
    }
    for (int i = 0; i < n + m - 1; i++)
    {
        for (int j = 0; j < m + n - 1; j++)
        {
            if (flag[j].ii > flag[j + 1].ii)
            {
                swap(flag[j].ii, flag[j + 1].ii);
                swap(flag[j].jj, flag[j + 1].jj);
                swap(flag[j].data, flag[j + 1].data);
            }
        }
    }
    for (int i = 0; i < n + m - 1; i++)
    {
        for (int j = 0; j < m + n - 1; j++)
        {
            if (flag[j].jj > flag[j + 1].jj && flag[j].ii == flag[j + 1].ii)
            {
                swap(flag[j].jj, flag[j + 1].jj);
                swap(flag[j].data, flag[j + 1].data);
            }
        }
    }
    int i = 0, dd = 0;
    while (flag[i].data != 0x7fffffff)
    {
        if (flag[i++].data != 0)
        {
            dd = 1;
            break;
        }
    }
    if (dd == 0)
    {
        cout << "-1 -1 -1";
        return 0;
    }
    i = 0;
    while (flag[i].data != 0x7fffffff)
    {
        if (flag[i].ii && flag[i].data != 0)
            cout << flag[i].ii << " " << flag[i].jj << " " << flag[i].data << endl;
        i++;
    }
}

