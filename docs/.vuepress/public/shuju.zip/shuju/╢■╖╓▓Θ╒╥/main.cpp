#include <iostream>
#include <algorithm>
using namespace std;

int a[10];

int binary_search(int x) {
    int left = 0, right = 9;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (a[mid] == x) {
            return mid;
        } else if (a[mid] < x) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1;
}

int binary_search_recursively(int x, int left, int right) {
    if (left > right) {
        return -1;
    }
    int mid = (left + right) / 2;
    if (a[mid] == x) {
        return mid;
    } else if (a[mid] < x) {
        return binary_search_recursively(x, mid + 1, right);
    } else {
        return binary_search_recursively(x, left, mid - 1);
    }
}

int main() {
    for (int i = 0; i < 10; i++) {
        cin >> a[i];
    }
    sort(a, a + 10);
    int n;
    cin >> n;
    int pos = binary_search(n);
    if (pos != -1) {
        cout << "yes" << endl;
    } else {
        cout << "no" << endl;
    }

    pos = binary_search_recursively(n, 0, 9);
    if (pos != -1) {
        cout << "yes" << endl;
    } else {
        cout << "no" << endl;
    }
    return 0;
}
