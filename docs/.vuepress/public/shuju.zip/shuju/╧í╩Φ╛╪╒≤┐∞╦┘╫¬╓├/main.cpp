#include <iostream>
using namespace std;
struct ccc
{
    int ii, jj, data;
} flag[12500];
int main()
{
    int a[205][205];
    int r, c;
    cin >> r >> c;
    int data, q = 0;
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
        {
            a[i][j] = 0;
            cin >> data;
            if (data != 0)
            {
                flag[q].ii = i;
                flag[q].jj = j;
                flag[q++].data = data;
            }
        }
    for (int i = 0; i < q; i++)
    {
        swap(flag[i].ii, flag[i].jj);
    }
    for (int i = 0; i < q; i++)
    {
        a[flag[i].ii][flag[i].jj] = flag[i].data;
    }
    for (int i = 0; i < c; i++)
    {
        for (int j = 0; j < r; j++)
            cout << a[i][j] << " ";
        cout << endl;
    }
}

