#include<stdio.h>
#include<stdlib.h>
typedef struct Polynode{
    float coef;
    int exp;
    struct Polynode* next;
}Polynode,*Polylist;
void InitList(Polylist* L){
    *L = (Polylist)malloc(sizeof(Polynode));
    (*L)->next = NULL;
}
void PolyCreat(Polynode* L){
    int f;
    scanf("%d",&f);
    Polynode* pr = L;
    while(f--){
        float c;
        int e;
        scanf("%f %d",&c,&e);
        Polynode* p = NULL;
        p = (Polylist)malloc(sizeof(Polynode));
        p->coef = c;
        p->exp = e;
        pr->next = p;
        pr = p;
        pr->next = NULL;
    }
}
void PolyAdd(Polynode* La,Polynode* Lb){
    Polynode* p = La->next;
    Polynode* q = Lb->next;
    Polynode* t = La;
    Polynode* temp = NULL;
    while(p != NULL && q != NULL){
        if(p->exp < q->exp){
            t->next= p;
            t = p;
            p = p->next;
            t->next = NULL;
        }
        else if(p->exp == q->exp){
            float sum = p->coef + q->coef;
            if(sum == 0.0){
                temp = p;
                p = p->next;
                free(temp);
                temp = q;
                q = q->next;
                free(temp);
            }
            else{
                p->coef = sum;
                t->next = p;
                t = p;
                p = p->next;
                temp = q;
                q = q->next;
                free(temp);
                t->next = NULL;
            }
        }
        else{
            t->next = q;
            t = q;
            q = q->next;
            t->next = NULL;
        }
    }
    if(p != NULL){
        t->next = p;
    }
    else{
        t->next = q;
    }
}
void Reverselist(Polylist L){
    Polynode* p = L->next;
    L->next = NULL;
    while(p != NULL){
        Polynode* q = p->next;
        p->next = L->next;
        L->next = p;
        p = q;
    }
}

void Sortlist(Polylist p_head)
{
    Polynode *pb, *pf, temp;
    pf = p_head;
    while(pf->next != NULL) {
        pb = pf->next;
        while(pb != NULL) {
            if(pf->exp > pb->exp) {
                temp = *pf;
                *pf = *pb;
                *pb = temp;
                temp.next = pf->next;
                pf->next = pb->next;
                pb->next = temp.next;
            }
            pb = pb->next;
        }
        pf = pf->next;
    }
    return ;
}
void Display(Polynode* L,int num){
    Polynode* p = L;
    int i = 0;
    while(i != num){
        i++;
        p = p->next;
    }
    printf("%0.1f %d",p->coef,p->exp);
}
int main(){
    Polylist La,Lb;
    int num;
    InitList(&La);
    InitList(&Lb);
    PolyCreat(La);
    PolyCreat(Lb);
    PolyAdd(La,Lb);
    Sortlist(La);
    Reverselist(La);
    scanf("%d",&num);
    Display(La,num);
    return 0;
}

