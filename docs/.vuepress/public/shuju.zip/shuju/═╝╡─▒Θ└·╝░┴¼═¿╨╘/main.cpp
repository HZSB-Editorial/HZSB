#include <iostream>
#include <queue>
#include <vector>

using namespace std;

const int MAXN = 100;
int n;
vector<int> adj_list[MAXN];
bool visited[MAXN];

// BFS����
void bfs(int node) {
    queue<int> q;
    q.push(node);
    visited[node] = true;
    while (!q.empty()) {
        int cur_node = q.front();
        q.pop();
        for (int i = 0; i < adj_list[cur_node].size(); i++) {
            int next_node = adj_list[cur_node][i];
            if (!visited[next_node]) {
                visited[next_node] = true;
                q.push(next_node);
            }
        }
    }
}

int main() {
    cin >> n;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int num;
            cin >> num;
            if (num == 1) {
                adj_list[i].push_back(j);
                adj_list[j].push_back(i);
            }
        }
    }
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            bfs(i);
            count++;
        }
    }
    cout << count << endl;

    return 0;
}

