#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

int n, m;
vector<int> g[5001];
int in_degree[5001];

bool topo_sort() {
    queue<int> q;
    for (int i = 1; i <= n; i++) {
        if (in_degree[i] == 0) {
            q.push(i);
        }
    }
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int i = 0; i < g[u].size(); i++) {
            int v = g[u][i];
            in_degree[v]--;
            if (in_degree[v] == 0) {
                q.push(v);
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        if (in_degree[i] > 0) {
            return false;
        }
    }
    return true;
}

bool dfs(int u, bool* visited, bool* in_stack) {
    in_stack[u] = true;
    visited[u] = true;
    for (int i = 0; i < g[u].size(); i++) {
        int v = g[u][i];
        if (!visited[v]) {
            if (dfs(v, visited, in_stack)) {
                return true;
            }
        } else if (in_stack[v]) {
            return true;
        }
    }
    in_stack[u] = false;
    return false;
}

int main() {
    // �������ݵ��������
    while (cin >> n >> m) {
        // ��ʼ��
        memset(in_degree, 0, sizeof(in_degree));
        for (int i = 1; i <= n; i++) {
            g[i].clear();
        }

        // ����ͼ
        for (int i = 1; i <= m; i++) {
            int u, v;
            cin >> u >> v;
            g[u].push_back(v);
            in_degree[v]++;
        }

        // ���������ж�DAG
        if (topo_sort()) {
            cout << "DAG" << endl;
        } else {
            cout << "not DAG" << endl;
        }

        // DFS�ж�DAG
        bool has_cycle = false;
        bool visited[5001] = {false};
        bool in_stack[5001] = {false};
        for (int i = 1; i <= n; i++) {
            if (!visited[i]) {
                has_cycle = dfs(i, visited, in_stack);
                if (has_cycle) {
                    break;
                }
            }
        }
        if (has_cycle) {
            cout << "not DAG" << endl;
        } else {
            cout << "DAG" << endl;
        }
        cout << endl;  // ÿ�������������
    }
    return 0;
}
