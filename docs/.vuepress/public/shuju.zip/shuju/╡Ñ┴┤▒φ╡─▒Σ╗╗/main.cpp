#include <iostream>
#include <stdlib.h>

using namespace std;

typedef struct LNode {
	int data;
	struct LNode *next;
}LNode, *LinkList;


void TailInsert(LinkList &L);

void print(LinkList L);

void operate(LinkList &L);

void invert(LinkList &L);

int main(void) {
	LinkList L;
	L = (LNode *)malloc(sizeof(LNode));
	L->next = NULL;

	TailInsert(L);
	operate(L);

	print(L);
}

void print(LinkList L) {
	if (L->next == NULL) return;

	LNode *t = L->next;
	while(t!= NULL) {
		cout<<t->data;
		cout<<" ";
		t = t->next;
	}
}

void TailInsert(LinkList &L) {
	LNode *tail, *t;

	tail = L;

	int x;
	cin>>x;
	while (x != 0) {
		t = (LNode*)malloc(sizeof(LNode));
		t->data = x;
		t->next = NULL;
		tail->next = t;
		tail = t;
		cin>>x;
	}
}
void operate(LinkList &L) {
	if (L->next == NULL ||
		L->next->next == NULL ||
		L->next->next->next == NULL) return;

	int length = 0;
	LNode *p = L, *q;
	while (p->next) {
		length++;
		p = p->next;
	}

	int m = (1 + length) / 2;

	p = L;
	while (m--) {
		p = p->next;
	}
	q = p->next;
	p->next = NULL;

	invert(q);
	m = (1 + length) >> 1;
	if (length % 2 != 0) m = m - 1;
	p = L;

	for (int i = 0; i < m; i++) {
		p = p->next;
		LNode *t = q;
		q = q->next;

		t->next = p->next;
		p->next = t;

		p = p->next;
	}

}

void invert(LinkList &L) {

	LinkList Head;
	Head = (LNode *)malloc(sizeof(LNode));
	Head->next = NULL;


	LNode *p = L;
	while (p) {
		LNode *t = p;
		p = p->next;


		t->next = Head->next;
		Head->next = t;
	}
	L = Head->next;
	free(Head);
}


