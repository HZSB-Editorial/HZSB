#include<iostream>
#include<cstring>
using namespace std;

typedef struct Node
{
	char data;
	struct Node* LChild;
	struct Node* RChild;
}BiTNode,*BiTree;




void Create(BiTree* root, string Pre, string In, int PreLeft, int PreRight, int InLeft, int InRight)
{
	if (InLeft > InRight)
	{
		*root = NULL;
	}
	else
	{
		*root = new BiTNode;
		(*root)->data = Pre[PreLeft];
		int MidR = 0;
		while (In[MidR] != Pre[PreLeft])
		{
			MidR++;
		}
		Create(&(*root)->LChild, Pre, In, PreLeft + 1, PreLeft + MidR - InLeft, InLeft, MidR - 1);
		Create(&(*root)->RChild, Pre, In, PreLeft + MidR - InLeft + 1, PreRight, MidR + 1, InRight);
	}
}


void PreOrder(BiTree root)
{
	if (root != NULL)
	{
		cout << root->data;
		PreOrder(root->LChild);
		PreOrder(root->RChild);
	}
	else
		return;
}


BiTree Search(BiTree root, BiTree p, BiTree q)
{
	if (root == NULL)
		return NULL;
	if (root->data == p->data || root->data == q->data)
		return root;
	BiTree left = Search(root->LChild, p, q);
	BiTree right = Search(root->RChild, p, q);
	if (!left && !right)
		return NULL;
	else if (!left && right)
		return right;
	else if (left && !right)
		return left;
	else
		return root;
}





int main()
{


	string Pre;
	string In;
	cin >> Pre;
	cin >> In;
	BiTree root = NULL;
	int len = Pre.length();
	Create(&root, Pre, In, 0, len - 1, 0, len - 1);
	BiTree p = new BiTNode;
	BiTree q = new BiTNode;
	cout << endl;
	string r;
	cin >> r;
	p->data = r[0];
	q->data = r[1];
	BiTree result = Search(root, p, q);
	if (result == NULL || result->data == root->data)
		cout << "NULL";
	else

		cout << result->data;

	return 0;
}

