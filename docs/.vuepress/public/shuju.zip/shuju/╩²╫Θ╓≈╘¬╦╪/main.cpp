#include <iostream>
#define Maxsize 1000
using namespace std;

int a[Maxsize],len;

void Input()
{
    int i=0;
    while(1)
    {
        cin>>a[i];
        if(a[i]==0) break;
        i++;
    }
    len=i;
}

void Majority()
{
    int cur=a[0],Count=1;
    for(int i=1;i<len;i++)
    {
        if(a[i]==cur) Count++;
        else
        {
            if(Count!=0) Count--;
            else
            {
                cur=a[i];
                Count=1;
            }
        }
    }
    if(Count!=0)
    {
    	int sum=0;
    	for(int i=0;i<len;i++)
    	if(a[i]==cur)
    	sum++;
    	if(sum>len/2) cout<<cur;
    	else cout<<"-1";
    }
    else
        cout<<"-1";
}
int main()
{
    Input();
    Majority();
    return 0;
}
