
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<malloc.h>
#include<stdbool.h>
#define MAX 1000
typedef struct
{
	int data[MAX];
	int top;
}SeqStack;
void InitSeq(SeqStack* s)
{
	s->top = -1;
}
void push(SeqStack* s,int x)
{
	if (s->top == MAX)return 0;
	else
		s->data[++s->top] = x;
}
void pop(SeqStack* s, int* x)
{
	*x=s->data[s->top];
	if (s->top >= 0)
		s->top--;
	else
	{
		printf("ջ��Ϊ��");
		return 0;
	}
}
int isSeq(SeqStack s, int temp[], int p[],int n)
{
	int i;
	int x;
	int count = 0;
    for (i = 0;i < n;i++)
	{
		push(&s, temp[i]);
		while (s.data[s.top] == p[count]&&count<n)
		{
			count++;
			pop(&s, &x);
		}
	}
	if (s.top == -1)
		return count;
	else
		return 0;
}
int main()
{
	SeqStack s;
	InitSeq(&s);
	int n;
	int arr[MAX], arr1[MAX];
	scanf("%d", &n);
	int i;
	for (i = 0;i < n;i++)
	{
		scanf("%d",&arr[i]);
	}
	for (i = 0;i < n;i++)
	{
		scanf("%d", &arr1[i]);
	}
	printf("%d",isSeq(s, arr, arr1, n));
}


