#include<stdio.h>
#include<stdlib.h>
#include<iomanip>
#include <iostream>
using namespace std;
#define MAXSIZE 50
#define TRUE 1
#define FALSE 0
typedef int QueueElementType;
typedef struct
{
    QueueElementType element[MAXSIZE];
    int front;
    int rear;
}SeqQueue;

void InitQueue(SeqQueue*Q)
{
    Q->front=Q->rear=0;
}
int EnterQueue(SeqQueue*Q,QueueElementType x)
{
       if((Q->rear+1)%MAXSIZE==Q->front)
        return FALSE;
       Q->element[Q->rear]=x;
       Q->rear=(Q->rear+1)%MAXSIZE;
       return TRUE;
}
int DeleteQueue(SeqQueue*Q,QueueElementType *x)
{
    if(Q->front==Q->rear)
        return FALSE;
    *x=Q->element[Q->front];
    Q->front=(Q->front+1)%MAXSIZE;
    return TRUE;
}
int GetHead(SeqQueue *Q,int*x)
{
    if(Q->front==Q->rear)
        return FALSE;
    else
        {
            *x=Q->element[Q->front];
            return TRUE;
        }
}
int isEmpty(SeqQueue *Q)
{
    if(Q->front==Q->rear)
        return TRUE;
    else return FALSE;
}
void YangHuiTriangle(int N)
{
    SeqQueue Q;
    InitQueue(&Q);
    EnterQueue(&Q,1);
    int n,i;
    int temp=0,x=0;
    for(n=2;n<=N;n++)
    {
        EnterQueue(&Q,1);
        for(i=1;i<=n-2;i++)
        {
            DeleteQueue(&Q,&temp);
            cout<<setw(3)<<temp;

            GetHead(&Q,&x);//
            temp=temp+x;
            EnterQueue(&Q,temp);
        }
        DeleteQueue(&Q,&x);
        cout<<setw(3)<<x;
        EnterQueue(&Q,1);
        cout<<endl;
    }
    while(!isEmpty(&Q))//
    {
        DeleteQueue(&Q,&x);
        cout<<setw(3)<<x;
    }

}
int main()
{
    int n;
    scanf("%d",&n);
    YangHuiTriangle(n);

    return 0;
}

