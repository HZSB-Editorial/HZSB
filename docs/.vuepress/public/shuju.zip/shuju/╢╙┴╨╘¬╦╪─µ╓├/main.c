#include<stdio.h>
#include<stdlib.h>
typedef struct SNode{
    int data;
    struct SNode * next;
}LinkStackNode;
typedef LinkStackNode* LinkStack;

typedef struct QNode{
    int data;
    struct QNode * next;
}LinkQueueNode;
typedef struct{
    LinkQueueNode * front;
    LinkQueueNode * rear;
}LinkQueue;

void InitStack(LinkStack * S){
    *S = (LinkStack)malloc(sizeof(LinkStackNode));
    (*S)->next = NULL;
}

int PushStack(LinkStack top,int e){
    LinkStackNode * temp;
    temp = (LinkStack)malloc(sizeof(LinkStackNode));
    if(temp == NULL){
        return 0;
    }
    else{
        temp->data = e;
        temp->next = top->next;
        top->next = temp;
        return 0;
    }
    return 0;
}

int PopStack(LinkStack top,int * e){
    if(top->next == NULL){
        return 0;
    }
    else{
        LinkStackNode * temp;
        temp = top->next;
        top->next = temp->next;
        *e = temp->data;
        free(temp);
        return 0;
    }
    return 0;
}

void InitQueue(LinkQueue * Q){
    Q->front = (LinkQueueNode*)malloc(sizeof(LinkQueueNode));
    if(Q->front != NULL){
        Q->rear = Q->front;
        Q->front->next = NULL;
    }
}

int EnterQueue(LinkQueue * Q,int e){
    LinkQueueNode * temp;
    temp = (LinkQueueNode*)malloc(sizeof(LinkQueueNode));
    if(temp != NULL){
        temp->data = e;
        temp->next = NULL;
        Q->rear->next = temp;
        Q->rear = temp;
        return 0;
    }
    return 0;
}

int DeleteQueue(LinkQueue * Q,int * e){
    LinkQueueNode * temp;
    if(Q->rear != Q->front){
        temp = Q->front->next;
        *e = temp->data;
        Q->front->next = temp->next;
        free(temp);
    }
    return 0;
}

int main(){
    LinkStack top = NULL;
    InitStack(&top);
    LinkQueue Q;
    InitQueue(&Q);
    int QueLen;
    scanf("%d",&QueLen);
    int flag;
    flag = QueLen;
    while(flag--){
        int QueData;
        scanf("%d",&QueData);
        EnterQueue(&Q,QueData);
    }
    flag = QueLen;
    while(flag--){
        int temp;
        DeleteQueue(&Q,&temp);
        PushStack(top,temp);
    }
    flag = QueLen;
    while(flag--){
        int temp = 0;
        PopStack(top,&temp);
        EnterQueue(&Q,temp);
        printf("%d ",temp);
    }
    return 0;
}

